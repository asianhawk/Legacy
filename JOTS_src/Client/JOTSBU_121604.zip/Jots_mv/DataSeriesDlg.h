#if !defined(AFX_DATASERIESDLG_H__0B40362A_2C4A_46EC_A9E5_D2805A651AD1__INCLUDED_)
#define AFX_DATASERIESDLG_H__0B40362A_2C4A_46EC_A9E5_D2805A651AD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataSeriesDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

#include "Utilities.h"

//#include "JoTS.h"

/////////////////////////////////////////////////////////////////////////////
// CDataSeriesDlg dialog

class CDataSeriesDlg : public CDialog
{
// Construction
public:
	CDataSeriesDlg(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CDataSeriesDlg)
	enum { IDD = IDD_DATA_SERIES };
	CShadeButtonST	m_btnUpdate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataSeriesDlg)
	public:
	virtual void OnFinalRelease();
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	
	CGridCtrl			m_Grid;
	void				InitGrid();
	JobInfo				*m_pJobInfo;
	void				UpdateGrid();
	void				VerifyGrid();
	NumberBases			*m_pNumberBases;	
	BOOL				IsColSelected(int nCol);
	BOOL				IsModified();
	void				SetCheckBox(int nRow, int nColumn, CString csValue );
	void				ProcessScanCheck (int nRowID, int nColID);
	void				GetCheckDigits();
	void				GetBaseNumberSchemas();
	void				ProcessBaseNumbers(int nRowID);
	HWND				m_hwndParent;
private:
	CStringArray		m_csaChkDigitName;
	CStringArray		m_csaBaseSchema;
	int					m_nCurrentRow;


protected:

	// Generated message map functions
	//{{AFX_MSG(CDataSeriesDlg)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/);
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnDataseriesCopy();
	afx_msg void OnDataseriesDelete();
	afx_msg void OnBtnUpdate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CDataSeriesDlg)
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATASERIESDLG_H__0B40362A_2C4A_46EC_A9E5_D2805A651AD1__INCLUDED_)
