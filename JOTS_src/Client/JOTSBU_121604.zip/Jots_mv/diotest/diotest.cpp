// diotest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <math.h>
unsigned short GetBitEquivalent(int nID);

void main( void )
{
   char buffer[81];
   int i, ch;

   printf( "Enter a line: " );

   /* Read in single line from "stdin": */
   for( i = 0; (i < 80) &&  ((ch = getchar()) != EOF) 
                        && (ch != '\n'); i++ )
      buffer[i] = (char)ch;

   /* Terminate string with null character: */
   buffer[i] = '\0';
  
  
   i=atoi(buffer);
   i = GetBitEquivalent(i);
	printf( "0x%04x\n", i );
}
unsigned short GetBitEquivalent(int nID)
{

unsigned short nConvertedValue;
	nConvertedValue=pow(2,nID - 1);


	return nConvertedValue;

}

