// Document.h : Declaration of the CDocument

#ifndef __DOCUMENT_H_
#define __DOCUMENT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDocument
class ATL_NO_VTABLE CDocument : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDocument, &CLSID_Document>,
	public IConnectionPointContainerImpl<CDocument>,
	public IDispatchImpl<IDocument, &IID_IDocument, &LIBID_JoTSLib>
{
public:
	CDocument()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DOCUMENT)
DECLARE_NOT_AGGREGATABLE(CDocument)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDocument)
	COM_INTERFACE_ENTRY(IDocument)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CDocument)
END_CONNECTION_POINT_MAP()


// IDocument
public:
};

#endif //__DOCUMENT_H_
