#include "stdafx.h"
#include "ProcessJob.h"
#include "Utilities.h"
#include "SequenceGen.h"

#include "CheckDgt.h"

#define	  PRINTCOMPLETE		1




CProcessJob::CProcessJob(CString csJobName, CLMorphor3 *pLMorphor3)
{
CUtilities *pUtil;
NumberBases *pNumberBase;
int nBaseIndex=0;
CXMLFile *pXML;
	
	pUtil = new CUtilities();
	m_blnUseNewSerialNumber = TRUE;

	m_pLMorphor3=pLMorphor3;
	pXML = new CXMLFile ();

	pXML->LoadFile(csJobName);
	m_nMaxLabels=pXML->GetLabelInformation();

	pNumberBase=pUtil->GetNumberBases();
	while(!pNumberBase[nBaseIndex].BaseName.IsEmpty())
	{
		m_udfNumberBases[nBaseIndex].BaseName=pNumberBase[nBaseIndex].BaseName;
		m_udfNumberBases[nBaseIndex].Table=pNumberBase[nBaseIndex].Table;
		nBaseIndex++;

	}
	Init();
	delete pXML;
	delete pUtil;
	m_nLabelsCount=0;
	m_nJobLabelCount=0;

}
CProcessJob::~CProcessJob()
{
	
	if (m_pScannerInfo)
		delete m_pScannerInfo;
//	if (m_pXML)
//		delete m_pXML;

}

CProcessJob::CProcessJob(CJoTSDoc	*pDoc, CLMorphor3 *pLMorphor3)
{
CUtilities *pUtil;
NumberBases *pNumberBase;
int nBaseIndex=0;

	m_blnUseNewSerialNumber = TRUE;
	pUtil = new CUtilities();
	m_pLMorphor3=pLMorphor3;
	m_pDoc=pDoc;
	m_nMaxLabels=pDoc->GetLabelInformation(); 
	m_pJobInfo = pDoc->GetJobInfo();
	

	pNumberBase=pUtil->GetNumberBases();
	while(!pNumberBase[nBaseIndex].BaseName.IsEmpty())
	{
		m_udfNumberBases[nBaseIndex].BaseName=pNumberBase[nBaseIndex].BaseName;
		m_udfNumberBases[nBaseIndex].Table=pNumberBase[nBaseIndex].Table;
		nBaseIndex++;

	}
	m_nMaxItems=-1;
	Init();
	delete pUtil;

}

BOOL CProcessJob::InitTimeOuts()
{
CUtilities *pUtils = new CUtilities();
CString csTemp;

	// Get Printer Time out
	csTemp=pUtils->GetConfigValue(PRINT_TIMEOUT);
	if (csTemp.IsEmpty())
	{
		pUtils->ErrorMessage("Printer TimeOut Not Defined");
		delete pUtils;
		return FALSE;
	}
	m_nPrinterTimeOut=atoi(csTemp);		// seconds
	if (!pUtils->IsValidInteger(m_nPrinterTimeOut,0,60,"Printer Time out"))
		return FALSE;


	// Get Scanner Time out
	csTemp=pUtils->GetConfigValue(SCANNER_TIMEOUT);
	if (csTemp.IsEmpty())
	{
		pUtils->ErrorMessage("Scanner Time Out Not Defined");
		delete pUtils;
		return FALSE;
	}
	m_nScannerTimeOut=atoi(csTemp);		// seconds
	if (!pUtils->IsValidInteger(m_nPrinterTimeOut,0,60,"Printer Time out"))
		return FALSE;

	return TRUE;
}

BOOL CProcessJob::Init()
{
CUtilities *pUtils = new CUtilities();
CString csTemp;
	m_pRunDlg = NULL;
	if (!InitTimeOuts())
		return FALSE;

//	int nCount=0;
//	while(!m_pJobInfo->LabelInfo[nCount].PrintOrder.IsEmpty())
//	{
//		nCount++;
//
//	}


	m_pScannerInfo = new Scanner();
	if(!pUtils->GetScannerInfo(MORPHOR_BC_SCANNER_ID, m_pScannerInfo))
		return FALSE;
	return TRUE;
}

CString CProcessJob::ProcessTemplate(CString csRawTemplate)
{
int nCount=0;
int nMaxTemplates=MAXTEMPLATES;
CString csTemplate;
CUtilities *pUtil = new CUtilities();

	csTemplate = csRawTemplate;
	for(nCount=0;nCount<nMaxTemplates;nCount++)
	{
		
	//	GetTemplatePath(nCount);
		if (m_pJobInfo->Templates[nCount].Name ==  m_csCurrentTemplate)
		{
			ProcessBCVars(&csTemplate,m_pJobInfo->Templates[nCount].BCVars);
			ProcessHCVars(&csTemplate,m_pJobInfo->Templates[nCount].HRVars);
			
			break;
		}

	}
	return csTemplate;
}

void  CProcessJob::ProcessBCVars(CString *csTemplate, BC_Vars *BCVars)
{
int nCount=0;


CString csVarName;
CString csSerialVar;
CString csSerialNumber,
		csKeyWordValue,
		csBuffer;
	
	csBuffer=*csTemplate;
	m_csaBarCodeValues.RemoveAll(); 
	while (!BCVars[nCount].Name.IsEmpty())
	{
		csKeyWordValue.Empty();		// purge any residual data
		
		csVarName = BCVars[nCount].Name;
		csSerialVar = BCVars[nCount].Data; 
		csSerialNumber=BuildSerialNumber(csSerialVar);
		
		if (!BCVars[nCount].Prefix.IsEmpty())
			csKeyWordValue=BCVars[nCount].Prefix;
		
		if (!csSerialNumber.IsEmpty())
			csKeyWordValue+=csSerialNumber;
		
		if (!BCVars[nCount].Suffix.IsEmpty())
			csKeyWordValue+=BCVars[nCount].Suffix;

	
		
		while (csBuffer.Find(csVarName)!=-1)
		{
			if(csBuffer.Replace(CString("[")+csVarName+CString("]"),csKeyWordValue)==0)
			{
				csBuffer.Replace(csVarName,csKeyWordValue);
			}
			// only add if keyword found
			m_csaBarCodeValues.Add(csKeyWordValue); 
			if (!csKeyWordValue.IsEmpty()) 
			SetCurrentSerialNumber(csKeyWordValue);

		}
		nCount++;

		

	}
	*csTemplate=csBuffer;
}


void  CProcessJob::ProcessHCVars(CString *csTemplate, HR_Vars *HRVars)
{
int nCount=0;
CString csVarName;
CString csSerialVar;
CString csSerialNumber,
		csKeyWordValue,
		csBuffer;
	
	csBuffer=*csTemplate;

	while (!HRVars[nCount].Name.IsEmpty())
	{
		csKeyWordValue.Empty();		// purge any residual data
		
		csVarName = HRVars[nCount].Name;
		csSerialVar = HRVars[nCount].Data; 
		csSerialNumber=BuildSerialNumber(csSerialVar);
		
		if (!HRVars[nCount].Prefix.IsEmpty())
			csKeyWordValue=HRVars[nCount].Prefix;
		
		if (!csSerialNumber.IsEmpty())
			csKeyWordValue+=csSerialNumber;
		
		if (!HRVars[nCount].Suffix.IsEmpty())
			csKeyWordValue+=HRVars[nCount].Suffix;

		while (csBuffer.Find(csVarName)!=-1)
		{
			if(csBuffer.Replace(CString("[")+csVarName+CString("]"),csKeyWordValue)==0)
			{
				csBuffer.Replace(csVarName,csKeyWordValue);
			}

		}
		nCount++;

	}
	*csTemplate=csBuffer;
}








CString CProcessJob::BuildSerialNumber(CString csSerialVar)
{
int nCount=0,
	nStepSize=0;

CString csDataSerialName,
		csSerialNumber,
		csTemp,
		csMaxValue,
		csRollOver;

char	cChkDigit[3];
CUtilities *pUtil;
CSequenceGen *pSequenceGen;

CString csBaseTable,
		csFormat;

	memset(cChkDigit,'\0',3);
	pUtil = new CUtilities();


	
	
	
	pSequenceGen = new CSequenceGen();

	while (!m_pJobInfo->SerialData[nCount].Name.IsEmpty())
	{
		csDataSerialName=m_pJobInfo->SerialData[nCount].Name;
		if (csDataSerialName.Find(csSerialVar)!=-1)
		{
			
			
			
			
			csTemp=m_pJobInfo->SerialData[nCount].Static;
			csTemp.MakeUpper(); 
			if (csTemp=="YES")
			{
				csSerialNumber=pUtil->GetSerialNumber(m_pJobInfo->Name,m_pJobInfo->SerialData[nCount].Name);

				m_csPreviousSerialNumber = csSerialNumber;

			}
			else
			{
			
				csBaseTable = pUtil->GetBaseNumberTable(m_udfNumberBases, 
														m_pJobInfo->SerialData[nCount].BaseNumberSchema ); 
			

				
				
				if (!csBaseTable.IsEmpty())
				{
				

					pSequenceGen->InitSeqGenerator(csBaseTable,
													   m_pJobInfo->SerialData[nCount].FieldWidth, atoi(m_pJobInfo->SerialData[nCount].StepSize) );
					
					
					if (GetUseNewSerialNumber()||m_csPreviousSerialNumber.IsEmpty()) 
					{
						
						if(m_pJobInfo->SerialData[nCount].StepSize.IsEmpty())
							nStepSize=1;
						else
							nStepSize=atoi(m_pJobInfo->SerialData[nCount].StepSize);

						m_csStepSize.Format("%d",nStepSize);
						csSerialNumber=pUtil->GetSerialNumber(m_pJobInfo->Name,m_pJobInfo->SerialData[nCount].Name);
	//					csSerialNumber= m_pJobInfo->SerialData[nCount].StartingSequencNumber;					
						
					    CheckMaxAndRollOverValues(nCount, csSerialNumber);												
						

						
						if ((m_csPreviousSerialNumber.IsEmpty())&&(!m_pJobInfo->SerialData[nCount].AllowDuplicates.Find("YES")))
						{
							int nTemp= atoi(m_pJobInfo->SerialData[nCount].FieldWidth);
							if (nTemp<0) nTemp=0;
							pSequenceGen->PadString(&csSerialNumber,nTemp);
							m_csPreviousSerialNumber = csSerialNumber;
					
						}
						else
						{
							if (nStepSize>0)
							{
								for (int nCount2=0;nCount2<nStepSize;nCount2++)
								{
									csSerialNumber = pSequenceGen->GetNextSerialNumber(csSerialNumber);  
								}
							   
								if (csSerialNumber>m_pJobInfo->SerialData[nCount].MaxSequenceNumber)
										csSerialNumber=m_pJobInfo->SerialData[nCount].RollOverValue;  
						 		   m_csPreviousSerialNumber = csSerialNumber;

							}
							else
							{
								for (int nCount2=0;nCount2<abs(nStepSize);nCount2++)
								{
									csSerialNumber = pSequenceGen->GetNextSerialNumber(csSerialNumber);  
								}

							   if (csSerialNumber<m_pJobInfo->SerialData[nCount].RollOverValue)
						 			csSerialNumber=m_pJobInfo->SerialData[nCount].MaxSequenceNumber;  
 								 m_csPreviousSerialNumber = csSerialNumber;
 
							}


						}
						if ((m_pJobInfo->SerialData[nCount].MaxSequenceNumber.IsEmpty())||
							(m_pJobInfo->SerialData[nCount].RollOverValue.IsEmpty())) 
						{

							m_csPreviousSerialNumber="Error";
							return "";

						}

                        

						
					}
					else
						csSerialNumber = m_csPreviousSerialNumber;

				}
			}
			// Determine Checkdigit

			if (m_pJobInfo->SerialData[nCount].CheckDigit.Find("NONE")==-1)
			{
				GetCheckDigit(csSerialNumber.GetBuffer(csSerialNumber.GetLength()),
							  m_pJobInfo->SerialData[nCount].CheckDigit.GetBuffer(m_pJobInfo->SerialData[nCount].CheckDigit.GetLength())
							  ,cChkDigit);

		
				csSerialNumber+=cChkDigit;
			}
			pUtil->UpdateSerialNumber(m_pJobInfo->Name,m_pJobInfo->SerialData[nCount].Name,m_csPreviousSerialNumber);
			m_pJobInfo->SerialData[nCount].StartingSequencNumber = m_csPreviousSerialNumber;

		
		}
		nCount++;
	}
	


	delete pUtil;
	delete pSequenceGen;
	return csSerialNumber;
}

void CProcessJob::CheckMaxAndRollOverValues(int nCount, CString csSerialNumber)
{
int nWidth=0;
CString csTemp;

		nWidth = csSerialNumber.GetLength();
		
		if (nWidth>m_pJobInfo->SerialData[nCount].MaxSequenceNumber.GetLength() )
		{
			csTemp=	m_pJobInfo->SerialData[nCount].MaxSequenceNumber;
			while (csTemp.GetLength()<csSerialNumber.GetLength())
			{
				csTemp="0"+csTemp;
		
			}
			m_pJobInfo->SerialData[nCount].MaxSequenceNumber=csTemp;						   	
		}
		
		if (nWidth>m_pJobInfo->SerialData[nCount].RollOverValue.GetLength() )
		{
			csTemp=	m_pJobInfo->SerialData[nCount].RollOverValue ;
			while (csTemp.GetLength()<csSerialNumber.GetLength())
			{
				csTemp="0"+csTemp;
		
			}
			m_pJobInfo->SerialData[nCount].RollOverValue=csTemp;						   	
		}



}

BOOL CProcessJob::BuildTemplate(int nLabelIndex, CString *csTemplate)
{
CString csBuffer;
CString csRawTemplate,
		csProcessedTemplate;
CString csTemplatePath;
CUtilities *pUtil;

	pUtil = new CUtilities();

	csTemplatePath=GetTemplatePath(nLabelIndex);
	if (csTemplatePath.IsEmpty()) return FALSE;

	if (!pUtil->ReadPrinterTemplate(csTemplatePath,&csRawTemplate))
	{
		delete pUtil;
		return FALSE;
	}

	csProcessedTemplate=ProcessTemplate(csRawTemplate);
//	pUtil->UpdateSerialNumber(m_pJobInfo->Name,m_pJobInfo->SerialData[nLabelIndex].Name,m_csPreviousSerialNumber);
//	m_pJobInfo->SerialData[nLabelIndex].StartingSequencNumber = m_csPreviousSerialNumber;


	if (csProcessedTemplate.IsEmpty()) return FALSE;
	
	*csTemplate=csProcessedTemplate;

	delete pUtil;
	return TRUE;

}


CString CProcessJob::GetTemplatePath(int nLabelIndex)
{
CUtilities *pUtil;
CString csPath;
	
	pUtil = new CUtilities();
	if (!pUtil->GetZebraPrinterTemplateDirectory(&csPath))
	{
		pUtil->ErrorMessage("Zebra Templates Directory Not Found");
		delete pUtil;
		return "";

	}
	if (m_pJobInfo->LabelInfo[nLabelIndex].TemplateName.IsEmpty())
	{
		pUtil->ErrorMessage("Template Name Not Defined For Label");
		delete pUtil;
		return "";
		
	}
	m_csCurrentTemplate=m_pJobInfo->LabelInfo[nLabelIndex].TemplateName;

	delete pUtil;
    return csPath+m_pJobInfo->LabelInfo[nLabelIndex].TemplateName;

}




void CProcessJob::Run()
{
int	nLabelIndex=0,
	nStatus=0,
	nMaxRePrints=0,
	nCurrentPrintAttempts=0;

int nTemp=0;
CString csBuffer,
		csTemp;;
BOOL blnError=FALSE;
BOOL blnState=FALSE;
CUtilities oUtil;
BOOL blnLogData;
CPerfTimer oTimer;
BOOL blnRePrint=FALSE;
BOOL blnSameSerialNumber=FALSE;;

	if(m_nMaxItems==-1)		// User defined label counter
	{
		m_nMaxItems=99999;

	}



	m_csCurrentTemplate.Empty(); 
	
	m_pRunDlg->Init();
	
	if(GetLabelsPerUnit()>1)
	{
		if ((GetTemplatesPerUnit()==1)&&(GetDataFactories()==1))
			blnSameSerialNumber=TRUE;
	}
	m_nLabelsCount=0;		// Initialize Total Labels Printed Counter

	
	nMaxRePrints = atoi(m_pJobInfo->Reprints);
	if ((nMaxRePrints<0)||(nMaxRePrints>10))
		nMaxRePrints=1;


	ResetApplicator();
	SetEStop(FALSE);
	StartApplicator(TRUE);
	StartApplicator(FALSE);
	StartApplicator(TRUE);
	blnLogData=oUtil.IsLogDataFileName(); 
	for (nTemp=0;(nTemp<m_nMaxItems) && (!blnError);nTemp++)
	{
		nLabelIndex=0;
		csBuffer.Empty(); 

		while (!IsApplicatorReady())
		{
			CUtilities *pUtil = new CUtilities();
			csTemp.LoadString(IDS_ERR_CONNECTING_TO_APPLICATOR);
			blnState=pUtil->UserResponse("Applicator Error",csTemp);
			delete pUtil;
			if (!blnState)
			{
				ResetApplicator();
				SetEStop(FALSE);

				return;
			}

		}
		while (nLabelIndex<m_nLabelsPerUnit&&(!blnError))
		{
			blnError=FALSE;
			m_pRunDlg->SetStatus("Waiting For Part Present");
			m_pRunDlg->UpdateDisplay();

			while (!IsPartPresent())
			{
				if (HoldOrExit()) return;

			}
			SetScannedLabel("");
			do 
			{

				if (HoldOrExit()) return;


				m_pRunDlg->m_btnHold.EnableWindow(FALSE);
//				m_pRunDlg->UpdateData(FALSE); 
				
				if (!blnRePrint)
				{
					if ((blnSameSerialNumber)&&(nLabelIndex>0))
						nStatus=RePrintLabel();
					else
						nStatus=PrintLabel(nLabelIndex);
					// record data
					if ((blnLogData)&&(m_pJobInfo->LogData)) 
						oUtil.LogData(m_csPreviousSerialNumber);
				}
				else
				{
					nStatus=RePrintLabel();
					// record data
					if ((blnLogData)&&(m_pJobInfo->LogData)) 
						oUtil.LogData(m_csPreviousSerialNumber);
				

				}
				m_nLabelsCount++;
				UpdateDisplay(m_pRunDlg, nLabelIndex);



			} while (nStatus!=PRINTCOMPLETE);

			// Send Demand Signal
//			ApplyLabel(TRUE);

			m_pRunDlg->SetStatus("Waiting For Print Complete Signal");
			m_pRunDlg->UpdateDisplay();

			m_pLMorphor3->SetErrorMessage(""); 
			oTimer.Start(); 
			while (!IsPrintCycleComplete()) // timeout in secs
			{
				if (HoldOrExit()) return;
				if (oTimer.Elapsed()>m_nPrinterTimeOut) 
				{
					ResetApplicator();
					csBuffer.LoadString(IDS_ERR_LABELAPPLYERROR);
					oUtil.ErrorMessage(csBuffer);
					return;

				}

				if(m_pLMorphor3->GetErrorMessage().Find("A")!=-1)
				{
					ResetApplicator();
					csBuffer.LoadString(IDS_ERR_APPLICATOR_ERROR);
					oUtil.ErrorMessage(csBuffer);
					return;


				}
			}
			m_pRunDlg->m_btnHold.EnableWindow(TRUE);

		
			ApplyLabel(FALSE);


			csBuffer=m_pJobInfo->LabelInfo[nLabelIndex].VerifyLabel;
			csBuffer.MakeUpper(); 
			if(csBuffer.Find("YES")!=-1) 
			{
				m_pRunDlg->SetStatus("Waiting For Scan Complete Signal");
				m_pRunDlg->UpdateDisplay();
				
				if(!ScanLabel(m_pRunDlg))
				{
					if (HoldOrExit()) return;

					// Auto Reprint
					if(nCurrentPrintAttempts<nMaxRePrints)
					{
						blnRePrint=TRUE;
						nCurrentPrintAttempts++;
					}
					else
						return;
				}
				else
				{
					blnRePrint=FALSE;
					nCurrentPrintAttempts=0;
				}
			}

			if (!blnRePrint)
			{
				UpdateDisplay(m_pRunDlg, nLabelIndex);
				m_pRunDlg->SetStatus("Waiting For Part To Be Removed");
				m_pRunDlg->UpdateDisplay();

				while (!IsPartRemoved())
				{
					if (HoldOrExit()) return;

				}

	//			m_pRunDlg->UpdateDisplay();


				if (nStatus==PRINTCOMPLETE)
				{
						nLabelIndex++;

				}
			}
			else
			{
				csBuffer.Format("Reprint Attempt # %d Of %d",nCurrentPrintAttempts+1,nMaxRePrints); 
				m_pRunDlg->SetStatus(csBuffer);
				m_pRunDlg->UpdateDisplay();

			}
		}
	}
}

BOOL CProcessJob::HoldOrExit()
{
BOOL blnResetFromHold=FALSE;	
static CString csPreviousStatus;

	m_pRunDlg->YieldToWindows();
	if (m_pRunDlg->ExitRun())
	{
		ResetApplicator();
		return TRUE;
	}

	while (m_pRunDlg->GetHoldStatus()) 
	{
		
		m_pRunDlg->UpdateDisplay();
		if (m_pRunDlg->ExitRun())
		{
			ResetApplicator();
//			m_pRunDlg->YieldToWindows();

			return TRUE;
		}
		if (!blnResetFromHold)
		{
			csPreviousStatus=m_pRunDlg->GetStatus(); 
			m_pRunDlg->SetStatus("Application Has Been Paused");

			StopApplicator(TRUE);
			blnResetFromHold = TRUE;

		}
	}
	if (blnResetFromHold)
	{
		StopApplicator(FALSE);
		m_pRunDlg->SetStatus(csPreviousStatus);
		m_pRunDlg->UpdateDisplay(); 

	}
	return FALSE;

}

void  CProcessJob::UpdateDisplay(CRunDlg *pRunDlg, int nLabelID)
{
CString csBuffer;
	if (pRunDlg)
	{
		csBuffer.Format(" Printing Label %d of %d",nLabelID,m_nLabelsPerUnit); 
		
		if (m_csaBarCodeValues.GetSize()>0)
		{
			pRunDlg->SetStatus(csBuffer);
					csBuffer = m_csaBarCodeValues.GetAt(0);
		}
		else
		{
			pRunDlg->SetStatus(csBuffer);
					csBuffer = "No Bar Code Variable Defined";


		}
		pRunDlg->m_csCurrentIndex.Format("Printing %d Of %d",nLabelID+1,m_nLabelsPerUnit);  

		pRunDlg->m_csBarCodeValue.Format("%s",csBuffer);  
		pRunDlg->m_csStepSize=m_csStepSize;  

		pRunDlg->m_csLabelCount.Format("%d",m_nLabelsCount);  

		if(m_pJobInfo->LabelInfo[nLabelID].ScanLabel.Find("Y")!=-1)
		{
			pRunDlg->m_csScannedBarcode=GetScannedLabel(); 
		}
		else
		{
			pRunDlg->m_csScannedBarcode="Scan Label = NO"; 

		}

		
		pRunDlg->UpdateDisplay();


	
		

	}

}
int  CProcessJob::PrintLabel(int nLabelIndex)
{
CString csTemplate,
		csOutputBuffer,
		csTemp;

	BuildTemplate(nLabelIndex, &csTemplate);

	
	csOutputBuffer=m_pLMorphor3->PrintAndApply()+CString("\"")+csTemplate+CString("\"\n");
	OutputDebugString(csOutputBuffer);

	m_pLMorphor3->Print(csOutputBuffer); 
	m_csLastPrintedLabel=csOutputBuffer;
	return PRINTCOMPLETE;
}



int  CProcessJob::RePrintLabel()
{
	if (!m_csLastPrintedLabel.IsEmpty())
	{
		m_pLMorphor3->Print(m_csLastPrintedLabel); 

	
	}
	

	return PRINTCOMPLETE;
}





BOOL CProcessJob::GetUseNewSerialNumber()
{
	return m_blnUseNewSerialNumber;

}

void CProcessJob::SetUseNewSerialNumber(BOOL blnState)
{
	m_blnUseNewSerialNumber=blnState;

}

BOOL CProcessJob::WaitForResponse(int nTimeOut)
{
BOOL blnState=FALSE;
CString csTemp;

	if (m_pLMorphor3->GetSimulatorMode())
	{
		Sleep(m_pLMorphor3->GetSimulatorDelay()); 
		return TRUE;

	}
	if(m_pLMorphor3->Listen(nTimeOut))
	{
		
		csTemp=m_pLMorphor3->GetReceiveBuffer();
		csTemp.MakeUpper(); 
		if (csTemp.Find("OK")!=-1)
		{
			return TRUE;
		}
//		else if (!csTemp.IsEmpty())
//		{
//			return WaitForResponse(nTimeOut);
//
//		}



	}
	return blnState;
}


BOOL CProcessJob::ScanLabel()
{
int nCount=0,
	nLabelIndex=0,		// need routine for mult-labelled microplates
	nMaxRescans=0;

CString csBuffer;
CString csTemplate,
		csOutputBuffer,
		csTemp;
CString csScannerID="1";
CString csTimeout="500";
BOOL blnError=FALSE;
CUtilities oUtil;

	SetScannedLabel("");

	if(m_pJobInfo->LabelInfo[nLabelIndex].ScanLabel.Find("YES")==-1)
	{
		SetState(LABELNOTCONFIGUREDFORSCANNING);
		return TRUE;
	}

	if (m_pLMorphor3->GetSimulatorMode())
	{
		Sleep(m_pLMorphor3->GetSimulatorDelay()); 
		SetScannedLabel("SIM Mode");
		return TRUE;

	}

	for(nCount=0;nCount<1/*nCount<m_csaBarCodeValues.GetSize()*/;nCount++)
	{
		if (m_csaBarCodeValues.GetSize()>0)
			csBuffer = m_csaBarCodeValues.GetAt(nCount);
		else
			csBuffer ="";
			

	


		csOutputBuffer=m_pLMorphor3->ReadScanner()+ CString(",") + 
						m_pScannerInfo->ID  + CString(",") + m_pScannerInfo->PreTriggerDelay + CString(",") +
						m_pScannerInfo->PostScanMaxTimeout  + CString(",") +
						csBuffer+CString(",")+
						m_pJobInfo->Rescans +"\n";
		

	
		m_pLMorphor3->Scan(csOutputBuffer);
		Sleep(atoi(m_pScannerInfo->PostScanMaxTimeout));
		if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
		{		
			csTemp=m_pLMorphor3->GetReceiveBuffer();
			if (csTemp==csBuffer)
			{
				SetScannedLabel(csTemp);
				SetState(GOODSCAN);
				return TRUE;
			}
		}
		
		blnError=TRUE;
		nMaxRescans=GetMaxRescans(); 
		if (blnError)
		{
			// Auto rescans
			for (int nScans=0;nScans<nMaxRescans;nScans++)
			{
				SetScannedLabel("");
				csTemp.Format("Rescanning Attempt %d Of %d",nScans+1,nMaxRescans); 
				m_pLMorphor3->Scan(csOutputBuffer); 
				if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
				{		
					csTemp=m_pLMorphor3->GetReceiveBuffer();
					if (csTemp==csBuffer)
					{
						SetScannedLabel(csTemp);
						return TRUE;
					}
				}

			}

		}
		else
		{
			m_csErrorMessage.Format("Expected Value [%s] Not The Same As Scanned Value[%s]",csBuffer,csTemp);
//			SetState(BARCODENOTMATCHEDTOPRINTEDVALUE);
			SetScannedLabel("Failed Scanned");

			return FALSE;
		}


//		while (blnError)
//		{
//		//	if (oUtil.UserResponse("Scanner Read Error. Try Again?"))
//			if (AfxMessageBox("Scanner Read Error. Try Again?",MB_YESNO)==IDYES)
//			{
//				m_pLMorphor3->Scan(csOutputBuffer); 
//				Sleep(atoi(m_pScannerInfo->PostScanMaxTimeout));
//				if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
//				{		
//					csTemp=m_pLMorphor3->GetReceiveBuffer();
//					if (csTemp==csBuffer)
//					{
//						SetState(GOODSCAN);
//						SetScannedLabel(csTemp);
//						return TRUE;
//					}
//				}
//			}
//			else
//			{
//				m_csErrorMessage.Format("Expected Value [%s] Not The Same As Scanned Value[%s]",csBuffer,csTemp);
//				SetState(BARCODENOTMATCHEDTOPRINTEDVALUE);
//				SetScannedLabel("Failed Scanned");
//
//				return FALSE;
//			}
//
//		}


	}
	SetState(LABELNOTCONFIGUREDFORSCANNING);
	m_csErrorMessage.Format("Scanner Not Setup");
	SetScannedLabel("Scanner Not Setup");

	return FALSE;
}





BOOL CProcessJob::ScanLabel(CRunDlg *pRunDlg)
{
int nCount=0,
	nMaxRescans=0;
CString csBuffer;
CString csTemplate,
		csOutputBuffer,
		csTemp;
CString csScannerID="1";
CString csTimeout="500";
BOOL blnError=FALSE;
CUtilities oUtil;

	SetScannedLabel("");
	if (m_pLMorphor3->GetSimulatorMode())
	{
		Sleep(m_pLMorphor3->GetSimulatorDelay()); 
		return TRUE;

	}


	for(nCount=0;nCount<1/*nCount<m_csaBarCodeValues.GetSize()*/;nCount++)
	{
		if (m_csaBarCodeValues.GetSize()>0)
			csBuffer = m_csaBarCodeValues.GetAt(nCount);
		else
			csBuffer ="";
			


	


		csOutputBuffer=m_pLMorphor3->ReadScanner()+ CString(",") + 
						m_pScannerInfo->ID  + CString(",") + m_pScannerInfo->PreTriggerDelay + CString(",") +
						m_pScannerInfo->PostScanMaxTimeout  + CString(",") +
						csBuffer+CString(",")+
						m_pJobInfo->Rescans +"\n";
		

		nMaxRescans=GetMaxRescans();
		m_pLMorphor3->Scan(csOutputBuffer); 

		if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
		{		
			csTemp=m_pLMorphor3->GetReceiveBuffer();
			if (csTemp==csBuffer)
			{
				SetScannedLabel(csTemp);
				return TRUE;
			}
		}
		
		blnError=TRUE;
		if (blnError)
		{
			// Auto rescans
			for (int nScans=0;nScans<nMaxRescans;nScans++)
			{
				SetScannedLabel("");
				csTemp.Format("Rescanning Attempt %d Of %d",nScans+1,nMaxRescans); 
				m_pRunDlg->SetStatus(csTemp);
				m_pRunDlg->UpdateDisplay();
				m_pLMorphor3->Scan(csOutputBuffer); 
				if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
				{		
					csTemp=m_pLMorphor3->GetReceiveBuffer();
					if (csTemp==csBuffer)
					{
						SetScannedLabel(csTemp);
						return TRUE;
					}
				}

			}

		}

		while (blnError)
		{
			if(pRunDlg->ExitRun()) return FALSE;
			if (oUtil.UserResponse("Scanner Read Error. Try Again?"))
			{
				pRunDlg->RedrawWindow();
				pRunDlg->YieldToWindows(); 
				m_pLMorphor3->Scan(csOutputBuffer); 
				if(m_pLMorphor3->ListenWithMaxTimeOut(5000))
				{		
					csTemp=m_pLMorphor3->GetReceiveBuffer();
					if (csTemp==csBuffer)
					{
						SetScannedLabel(csTemp);
						return TRUE;
					}
				}
			}
			else
			{
				SetScannedLabel("Scanned Failed");
				return FALSE;
			}
		}
		

	}
	SetScannedLabel("");
	return FALSE;
}



int CProcessJob::GetMaxRescans()
{
int nMaxRescans=0;
	if (!m_pJobInfo->Rescans.IsEmpty()) 
		nMaxRescans=atoi(m_pJobInfo->Rescans);  
	else
		nMaxRescans=1;

	if ((nMaxRescans<0)||(nMaxRescans>10))
		nMaxRescans=1;

	return nMaxRescans;

}


int CProcessJob::GetMaxRePrints()
{
int nMaxRePrints=0;
	if (!m_pJobInfo->Reprints.IsEmpty()) 
		nMaxRePrints=atoi(m_pJobInfo->Reprints);  
	else
		nMaxRePrints=1;

	if ((nMaxRePrints<0)||(nMaxRePrints>10))
		nMaxRePrints=1;

	return nMaxRePrints;

}






void CProcessJob::SetMaxItems(int nMaxItems)
{
	m_nMaxItems =nMaxItems;

}

int	CProcessJob::GetMaxItems()
{
	return m_nMaxItems;

}


int CProcessJob::GetLabelsPerUnit()
{
int nCount=0;
	m_nLabelsPerUnit=0;
	while (!m_pJobInfo->LabelInfo[nCount].PrintOrder.IsEmpty())   	
	{
		nCount++;
	}
	m_nLabelsPerUnit=nCount;
	return m_nLabelsPerUnit;

}


int CProcessJob::GetTemplatesPerUnit()
{
int nCount=0,
	nDistinctTemplates=0;

BOOL blnDuplicate=FALSE;

CStringArray csTemplateNames;

	while (!m_pJobInfo->LabelInfo[nCount].PrintOrder.IsEmpty())   	
	{
		blnDuplicate=FALSE;
		for (nDistinctTemplates=0;nDistinctTemplates<csTemplateNames.GetSize();nDistinctTemplates++)
		{
			if(m_pJobInfo->LabelInfo[nCount].TemplateName==csTemplateNames.GetAt(nDistinctTemplates))
				blnDuplicate=TRUE;

		}
		if (!blnDuplicate)
			csTemplateNames.Add(m_pJobInfo->LabelInfo[nCount].TemplateName);

		nCount++;
	}
	return csTemplateNames.GetSize();
}


int CProcessJob::GetDataFactories()
{
int nCount=0,
	nDistinctDataFactories=0,
	nBCVars=0,
	nHRVars=0,
	nVarCntr=0;

BOOL blnDuplicate=FALSE;

CStringArray csBCVars,
			 csHRVars,
			 csVars;

	while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())   	
	{
		blnDuplicate=FALSE;
		// first for BC Variables
		nBCVars=0;
		for (nBCVars=0;nBCVars<MAXVARS;nBCVars++)
		{
			if (m_pJobInfo->Templates[nCount].BCVars[nBCVars].Data.IsEmpty()) break;
			if (csVars.GetSize()==0) break; 
			for(nVarCntr=0;nVarCntr<csVars.GetSize();nVarCntr++ )
			{
				if(m_pJobInfo->Templates[nCount].BCVars[nBCVars].Data==csVars.GetAt(nVarCntr))
					blnDuplicate=TRUE;
				else
				{
					break;
				}
			}
			if (!blnDuplicate) break;
				
			nBCVars++;
		}
		if (!blnDuplicate)
		{
			if (!m_pJobInfo->Templates[nCount].BCVars[nBCVars].Data.IsEmpty())
			{
				csVars.Add(m_pJobInfo->Templates[nCount].BCVars[nBCVars].Data);
			}
		}

		nCount++;
	}

	nCount=0;
//	nDistinctDataFactories=0;
	while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())   	
	{
		blnDuplicate=FALSE;
		// first for BC Variables
		nHRVars=0;
		for (nHRVars=0;nHRVars<MAXVARS;nHRVars++)
		{
			if (m_pJobInfo->Templates[nCount].HRVars[nHRVars].Data.IsEmpty()) break;
			if (csVars.GetSize()==0) break; 
			
			for(nVarCntr=0;nVarCntr<csVars.GetSize();nVarCntr++ )
			{
				if(m_pJobInfo->Templates[nCount].HRVars[nHRVars].Data==csVars.GetAt(nVarCntr))
					blnDuplicate=TRUE;
				else
				{
					break;
				}
			}
			if (!blnDuplicate) break;

			
			
			
			nHRVars++;
		}
		if (!blnDuplicate)
		{

			if (!m_pJobInfo->Templates[nCount].HRVars[nHRVars].Data.IsEmpty())
			{
				csVars.Add(m_pJobInfo->Templates[nCount].HRVars[nHRVars].Data);
//				nDistinctDataFactories++;
			}

		}
		nCount++;
	}
	
	
	
	
	
	return csVars.GetSize();
}




void CProcessJob::SetRunDlg(CRunDlg *pDlg)
{
	m_pRunDlg = pDlg;
}

BOOL  CProcessJob::IsPartPresent()
{
	return m_pLMorphor3->IsPartPresent();
	
}

BOOL  CProcessJob::IsPartRemoved()
{
	return m_pLMorphor3->IsPartRemoved();
	
}




BOOL  CProcessJob::IsApplicatorReady()
{
	
	return m_pLMorphor3->IsApplicatorReady();
	
}


void CProcessJob::StartApplicator(BOOL blnState)
{
	m_pLMorphor3->StartApplicator(blnState); 


}

void CProcessJob::StopApplicator(BOOL blnState)
{
	m_pLMorphor3->StopApplicator(blnState); 


}

void CProcessJob::ResetApplicator()
{
	m_pLMorphor3->ResetApplicator(); 


}

void CProcessJob::ApplyLabel(BOOL blnState)
{
	m_pLMorphor3->ApplyLabel(blnState); 


}

BOOL CProcessJob::IsPrintCycleComplete()
{
	return m_pLMorphor3->IsCycleComplete();


}


void CProcessJob::SetEStop(BOOL blnState)
{
	m_pLMorphor3->SetEStop(blnState);
	Sleep(500);

}





DWORD WINAPI CProcessJob::AutoPrint()
{
int	nLabelIndex=0,
	nStatus=0,
	nCurrentPrintAttempts=0;

int nTemp=0;
CString csBuffer;
BOOL blnError=FALSE;
BOOL blnState=FALSE;
CUtilities oUtil;
BOOL blnLogData;
BOOL blnRePrint=FALSE;
CPerfTimer oTimer;
BOOL blnSameSerialNumber=FALSE;

	
	blnLogData=oUtil.IsLogDataFileName(); 
	m_csCurrentTemplate.Empty(); 
	
	m_nLabelsCount=0;		// Initialize Total Labels Printed Counter

	if (m_nJobLabelCount>=GetLabelsPerUnit())
		m_nJobLabelCount=0;
	else if (m_nJobLabelCount<0)
		m_nJobLabelCount=0;


	if(GetLabelsPerUnit()>1)
	{
		if ((GetTemplatesPerUnit()==1)&&(GetDataFactories()==1))
			blnSameSerialNumber=TRUE;
	}
	


	while(IsApplicatorReady())
	{

		if(!IsApplicatorReady())
		{
			m_csErrorMessage="Applicator Not Ready";
			SetState(APPLICATORREADYERROR);
			return FALSE;

		}
		
		

		if (m_pLMorphor3->GetSimulatorMode())
		{
			SetState(JOBWAITINGFORPARTPRESENT);
			Sleep(m_pLMorphor3->GetSimulatorDelay()); 

		}		
		
		Sleep(100);
		while (!IsPartPresent())
		{
			oUtil.YieldToWindows ();
			SetState(JOBWAITINGFORPARTPRESENT);
		}
		Sleep(100);

		nStatus=0;
		do 
		{
		


			if (blnRePrint)
				nStatus=RePrintLabel();
			else
			{

				if ((blnSameSerialNumber)&&(m_nJobLabelCount>0))
					nStatus=RePrintLabel();
				else
					nStatus=PrintLabel(m_nJobLabelCount);
				
				
			}
			m_nLabelsCount++;			
			
			
			// record data
			if (m_pJobInfo->LogData) 
				oUtil.LogData(m_pJobInfo->Name, 
							  m_pJobInfo->LabelInfo[m_nJobLabelCount].TemplateName,
							  m_csPreviousSerialNumber);



		} while (nStatus!=PRINTCOMPLETE);
		oTimer.Start();
		
		Sleep(100);
		SetState(JOBWAITINGFORCYCLECOMPLETE);
		while (!IsPrintCycleComplete()) // timeout in secs
		{
			if (oTimer.Elapsed()>m_nPrinterTimeOut) 
			{
				ResetApplicator();
				SetState(LABELAPPLYERROR);
				return FALSE;

			}

			if(m_pLMorphor3->GetErrorMessage().Find("A")!=-1)
			{
				ResetApplicator();
				SetState(LABELAPPLYERROR);
				return FALSE;


			}
		}
		ApplyLabel(FALSE);


		csBuffer=m_pJobInfo->LabelInfo[m_nJobLabelCount].VerifyLabel;
		csBuffer.MakeUpper(); 
		if(csBuffer.Find("YES")!=-1) 
		{

			if(!ScanLabel())
			{
					// Auto Reprint
				if(nCurrentPrintAttempts < GetMaxRePrints())
				{
					blnRePrint=TRUE;
					nCurrentPrintAttempts++;
				}
				else
				{
					SetState(BARCODENOTMATCHEDTOPRINTEDVALUE);
					return FALSE;
				}
			}
			else
				blnRePrint=FALSE;

		}
		else
			blnRePrint = FALSE;

		if(!blnRePrint)
		{
		
			SetState(JOBWAITINGFORPART2BREMOVED);
			while (!IsPartRemoved())
			{
				oUtil.YieldToWindows ();

			}
			SetState(JOBPRINTCOMPLETED);
			break;
		}
	}
	SetState(JOBPRINTCOMPLETED);
	if (m_pLMorphor3->GetSimulatorMode())
	{
		Sleep(m_pLMorphor3->GetSimulatorDelay()); 

	}		
	else
	{
		Sleep(1000);
	}
	
	
	SetState(JOBWAITINGFORPARTPRESENT);
	m_nJobLabelCount++;
	return TRUE;
}

void CProcessJob::AutoInit()
{

	ResetApplicator();
	SetEStop(TRUE);
	StartApplicator(TRUE);
	StartApplicator(FALSE);
	StartApplicator(TRUE);

	SetState(IDLE);


}

CString CProcessJob::GetErrorMessage()
{
	
	return m_csErrorMessage;
}


int	CProcessJob::GetState()
{
	return m_nState;
}

void CProcessJob::SetState(int nState)
{
   m_nState = nState;
}

CString CProcessJob::GetCurrentSerialNumber()
{
	return m_csCurrentSerialNumber;

}
void CProcessJob::SetCurrentSerialNumber(CString csCurrentSerialNumber)
{
	m_csCurrentSerialNumber=csCurrentSerialNumber;

}

CString	CProcessJob::GetScannedLabel()
{

	return m_csScannedLabel;

}
void CProcessJob::SetScannedLabel(CString csScannedLabel)
{
	m_csScannedLabel = csScannedLabel;

}



