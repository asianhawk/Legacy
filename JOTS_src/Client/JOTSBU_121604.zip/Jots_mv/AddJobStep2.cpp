// AddJobStep2.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep2.h"
#include "PropertyEx.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//const char *JobNameTip = _T("<table><tr><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Job Name:</font><br><t>� must be unique;<br><t>� longer than six characters in length;<br></td></tr>");
//const char *CustomerTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Company:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");
const char *ProductTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Product:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");
const char *NumberOfLabels = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Product:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");
const char *AutoReprints = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Product:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");
const char *AutoRescans = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Product:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");
const char *LogData = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Product:</font><br><t>� maxium 80 characters in length;<br><t>� optional field ;<br></td></tr></table>");


const char *Header = _T("<table><tr><td><center><h2>Job Wizard</h2></center><br><hr color=green><br>");
const char *SubHeader = "<font color=red size=12pt style=b>%s:</font><br>";
const char *JobNameTip = _T("<t>must be unique;<br><t>longer than six characters in length;<br>");
const char *CustomerTip = _T("<t>maximum 80 characters in length<br><t>optional field<br>");

const char *Footer = _T("</td></tr><tr><td><h3>Additional Info:</h3><br><hr color=green><br><font color=red size=12pt style=b>Select And Press F1 For More Help</font></td></tr></table>");


/////////////////////////////////////////////////////////////////////////////
// CAddJobStep2 property page

IMPLEMENT_DYNCREATE(CAddJobStep2, CPropertyPage)

CAddJobStep2::CAddJobStep2() : CPropertyPage(CAddJobStep2::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep2)
	m_blnLogData = FALSE;
	m_csCustomer = _T("");
	m_csJobName = _T("");
	m_csNoOfLabels = _T("1");
	m_csNoOfReprints = _T("1");
	m_csNoOfRescans = _T("1");
	m_csProductDescription = _T("");
	m_csLabelCustomer = _T("");
	m_csProduct = _T("");
	//}}AFX_DATA_INIT
}

CAddJobStep2::~CAddJobStep2()
{
}

void CAddJobStep2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep2)
	DDX_Control(pDX, IDC_CHK_EXTERNAL_LOG_DATA, m_chkLogData);
	DDX_Control(pDX, IDC_SPIN_AUTO_RESCANS, m_spnAutoRescans);
	DDX_Control(pDX, IDC_SPIN_AUTO_REPRINTS, m_spnAutoReprints);
	DDX_Control(pDX, IDC_SPIN_LABELS, m_spnNumberOfLabels);
	DDX_Control(pDX, IDC_TXB_NOOFRESCANS, m_txbNoOfRescans);
	DDX_Control(pDX, IDC_TXB_NOOFREPRINTS, m_txbNoOfReprints);
	DDX_Control(pDX, IDC_TXB_NOOFLABELS, m_txbNoOfLabels);
	DDX_Control(pDX, IDC_TXB_PRODUCT, m_txbProduct);
	DDX_Control(pDX, IDC_TXB_CUSTOMER, m_txbCustomer);
	DDX_Control(pDX, IDC_TXB_JOBNAME, m_txbJobName);
	DDX_Check(pDX, IDC_CHK_EXTERNAL_LOG_DATA, m_blnLogData);
	DDX_Text(pDX, IDC_TXB_CUSTOMER, m_csCustomer);
	DDX_Text(pDX, IDC_TXB_JOBNAME, m_csJobName);
	DDX_Text(pDX, IDC_TXB_NOOFLABELS, m_csNoOfLabels);
	DDX_Text(pDX, IDC_TXB_NOOFREPRINTS, m_csNoOfReprints);
	DDX_Text(pDX, IDC_TXB_NOOFRESCANS, m_csNoOfRescans);
	DDX_Text(pDX, IDC_TXB_PRODUCT, m_csProductDescription);
	DDX_Text(pDX, IDC_LBL_CUSTOMER, m_csLabelCustomer);
	DDX_Text(pDX, IDC_LBL_PRODUCT, m_csProduct);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep2, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep2)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep2 message handlers

BOOL CAddJobStep2::OnSetActive() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	
	return CPropertyPage::OnSetActive();
}


void CAddJobStep2::InitControls()
{

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	GetDlgItem(IDC_LBL_JOB_NAME)->SetFont(&font);
	GetDlgItem(IDC_LBL_CUSTOMER)->SetFont(&font);
	GetDlgItem(IDC_LBL_PRODUCT)->SetFont(&font);
	GetDlgItem(IDC_LBL_NUMBER_OF_LABELS)->SetFont(&font);
	GetDlgItem(IDC_LBL_MAX_REPRINTS)->SetFont(&font);
	GetDlgItem(IDC_LBL_MAX_RESCANS)->SetFont(&font);
	GetDlgItem(IDC_LBL_LOG)->SetFont(&font);


	
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_LIGHT); 

	
	
	m_txbJobName.SetFont(&font);
	m_txbCustomer.SetFont(&font);
	m_txbProduct.SetFont(&font);
	m_txbNoOfLabels.SetFont(&font);
	m_txbNoOfReprints.SetFont(&font);
	m_txbNoOfRescans.SetFont(&font);

	m_spnNumberOfLabels.SetBuddy(&m_txbNoOfLabels);
    m_spnNumberOfLabels.SetRange( 1, 10 );
    m_spnNumberOfLabels.SetPos( 1 );

	m_spnAutoReprints.SetBuddy(&m_txbNoOfReprints);
    m_spnAutoReprints.SetRange( 0, 5 );
    m_spnAutoReprints.SetPos( 1 );

	m_spnAutoRescans.SetBuddy(&m_txbNoOfRescans);
    m_spnAutoRescans.SetRange( 0, 5);
    m_spnAutoRescans.SetPos( 1 );



	





//	m_Tip.AddTool(GetDlgItem(IDC_EDIT1), _T("This is an edit control!"), m_hIcon3);
//	m_Tip.AddTool(GetDlgItem(IDOK), _T("This is the OK button!\nPress it to close the dialog..."), NULL);
//	m_Tip.AddTool(GetDlgItem(IDCANCEL), _T("This is the Cancel button!\nPress it to close the dialog..."), NULL);




}

LRESULT CAddJobStep2::OnWizardNext() 
{
	if (!VerifyData()) return -1;

	if (atoi(m_csNoOfLabels)==1)
	{

		return IDD_ADDJOB_STEP5;	
	}
	return CPropertyPage::OnWizardNext();
}

BOOL CAddJobStep2::VerifyData()
{
CUtilities oUtils;
	UpdateData(TRUE);

	
	if (oUtils.IsStringEmpty("Job Wizard Step 2", "Job Name", m_csJobName)) return FALSE;
	
	if (m_csJobName.GetLength()<3 ) 
	{
		return oUtils.ErrorMessage("Job Name File Length Less Than 3");
		
	}
	
	
	if (!oUtils.IsUniqueJobFile(m_csJobName)) 
	{
		return oUtils.ErrorMessage("Job Name Entered Is Not Unique");
		
	}

	if (!oUtils.IsValueAllowed("Job Wizard Step 2", "Number Of Labels", m_csNoOfLabels,1, MAXLABELS)) return FALSE;
	if (!oUtils.IsValueAllowed("Job Wizard Step 2", "Number Of Reprints", m_csNoOfReprints ,0, MAXREPRINTS)) return FALSE;
	if (!oUtils.IsValueAllowed("Job Wizard Step 2", "Number Of Rescans", m_csNoOfRescans  ,0, MAXREPRINTS)) return FALSE;
	
	

	CPropertyEx* parent = (CPropertyEx*)GetParent();
	parent->m_nNumberOfLabels= atoi(m_csNoOfLabels); 

	
	return TRUE;
}

BOOL CAddJobStep2::OnHelpInfo(HELPINFO* pHelpInfo) 
{
HWND hwnd;
	UINT iContextId = pHelpInfo->iCtrlId ;
    hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
        HH_HELP_CONTEXT,iContextId);	

	if (hwnd==NULL)
	{
		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_DISPLAY_TOPIC,0);	
	}
	return TRUE;

}

BOOL CAddJobStep2::PreTranslateMessage(MSG* pMsg) 
{
	m_Tip.RelayEvent(pMsg);	
	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CAddJobStep2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	InitControls();

	CUtilities *pUtil = new CUtilities();
char *OptionField1="//Config/DialogBoxes/JobWizardStep2/OptionalField1/Name";
char *OptionField2="//Config/DialogBoxes/JobWizardStep2/OptionalField2/Name";

	
	m_csLabelCustomer.Empty();
	m_csLabelCustomer=pUtil->GetConfigValue(OptionField1, FALSE); 
	if (m_csLabelCustomer.IsEmpty())
	{
		m_csLabelCustomer = "Company";
	}
	m_csProduct=pUtil->GetConfigValue(OptionField2, FALSE); 
	if (m_csProduct.IsEmpty())
	{
		m_csProduct = "Product";
	}


	// Create the tool tip
	m_Tip.Create(this);
	SetToolTipsProperties();

	CreateToolTips();



	
	
	UpdateData(FALSE);
	delete pUtil;
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void  CAddJobStep2::CreateToolTips()
{
CUtilities *pUtil = new CUtilities();
CString csTemp,csHeader, csSubHeader;


	/*********************** Job Name **************************************************/
	csHeader=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/JobName",FALSE); 
	csHeader.TrimLeft();
	csHeader.TrimRight();
	csSubHeader.Format(SubHeader,"Job Name");
	if (csHeader.IsEmpty())
		csTemp.Format("%s%s%s%s",Header,csSubHeader,JobNameTip,Footer);
	else
		csTemp.Format("%s%s%s%s",Header,csSubHeader,csHeader,Footer);

	m_Tip.AddTool(&m_txbJobName, _T(csTemp), m_hIcon1);
	
	/****************************************************************/


	/*********************** User Defined Fields ********************************/
	csHeader=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/Company",FALSE); 
	csHeader.TrimLeft();
	csHeader.TrimRight();
	csSubHeader.Format(SubHeader,"Company:");
	if (csHeader.IsEmpty())
		csTemp.Format("%s%s%s%s",Header,csSubHeader,CustomerTip,Footer);
	else
		csTemp.Format("%s%s%s%s",Header,csSubHeader,csHeader,Footer);

	m_Tip.AddTool(&m_txbCustomer, _T(csTemp), m_hIcon1);
	
	/****************************************************************/
	


	// User Defined Fields
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/Product",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",ProductTip);
	else
	{
		csTemp.Replace("Product:",m_csProduct);

	}
	m_Tip.AddTool(&m_txbProduct, _T(csTemp), m_hIcon1);

	// Static Field - Number Of Labels
	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/NumberOfLabels",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",NumberOfLabels);

	m_Tip.AddTool(&m_txbNoOfLabels, _T(csTemp), m_hIcon1);
	
	// Static Field - Autoreprints
	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/AutoReprints",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",AutoReprints);

	m_Tip.AddTool(&m_txbNoOfReprints, _T(csTemp), m_hIcon1);

	
	// Static Field - AutoRescans
	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/AutoRescans",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",AutoRescans);

	m_Tip.AddTool(&m_txbNoOfRescans, _T(csTemp), m_hIcon1);


	// Static Field - LogData
	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard1/LogData",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",LogData);

	m_Tip.AddTool(&m_chkLogData, _T(csTemp), m_hIcon1);



	delete pUtil;

}
void  CAddJobStep2::SetToolTipsProperties()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;

char *conGradient1 =  "//Config/ToolTips/Gradient1";
char *conGradient2 =  "//Config/ToolTips/Gradient2";
char *conGradient3 =  "//Config/ToolTips/Gradient3";

	
	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);


	csTemp=pUtil->GetConfigValue("//ToolTips/StyleSheet",FALSE); 
	if (csTemp.IsEmpty())
	{
		csTemp.LoadString(IDS_TIP_HTML_STYLE); 
		m_Tip.SetCssStyles(csTemp);
	}
	else
	{
		m_Tip.SetCssStyles(csTemp);
	}






	csTemp=pUtil->GetConfigValue(conGradient1,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad1=BEGINTIPCOLOR;
	}
	else
	{
		m_lngColorGrad1 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient2,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad2=MIDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad2 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient3,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad3=ENDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad3 = atol(csTemp);
	}



//	m_Tip.SetColorBk(m_lngColorGrad1,m_lngColorGrad2,m_lngColorGrad3);
	m_Tip.SetColorBk(DEFCOLOR);

//	m_Tip.SetEffectBk(CPPDrawManager::EFFECT_3HGRADIENT,10);
	m_Tip.SetDelayTime(PPTOOLTIP_TIME_FADEOUT,TOOLTIP_FADEOUT);

	
	delete pUtil;

}


BOOL  CAddJobStep2::GetInitStatus()
{

	return m_blnErrorIniting;
}

void  CAddJobStep2::SetInitStatus(BOOL blnStatus)
{
    m_blnErrorIniting=blnStatus;

}
