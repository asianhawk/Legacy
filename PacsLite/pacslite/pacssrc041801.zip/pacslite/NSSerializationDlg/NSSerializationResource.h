//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NSSerializationDlg.rc
//
#define IDD_SETUP_SERIALIZATION_DLG     191
#define IDC_LABEL1                      1012
#define IDC_USE_SERIALIZATION           1064
#define IDC_SETUP_SERIALIZATION         1065
#define IDC_LABEL2                      1066
#define IDC_LABEL3                      1067
#define IDC_SN_TYPE                     1068
#define IDC_SN_LENGTH                   1069
#define IDC_OK                          1099
#define IDC_STARTING_SN                 1138
#define IDC_CANCEL                      1174
#define IDC_RESET_JULIAN                1183
#define IDC_CHK_USE_CHECKDIGIT          1184
#define IDC_OPT_PRINTER                 1185
#define IDC_OPT_COMPUTER                1186
#define IDC_CMB_FORMULA                 1187
#define IDC_FRM_CHKDIGITSOURCE          1188



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        210
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1189
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
