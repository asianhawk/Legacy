// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__FDD3309E_1C01_48E3_9127_88B0351842C0__INCLUDED_)
#define AFX_DLGPROXY_H__FDD3309E_1C01_48E3_9127_88B0351842C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJoTS_ComSimDlg;

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlgAutoProxy command target

class CJoTS_ComSimDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CJoTS_ComSimDlgAutoProxy)

	CJoTS_ComSimDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CJoTS_ComSimDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJoTS_ComSimDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CJoTS_ComSimDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CJoTS_ComSimDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CJoTS_ComSimDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CJoTS_ComSimDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__FDD3309E_1C01_48E3_9127_88B0351842C0__INCLUDED_)
