// JoTSView.h : interface of the CJoTSView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_JOTSVIEW_H__7311FBDC_02B0_4A85_9D76_6713FCB0EC27__INCLUDED_)
#define AFX_JOTSVIEW_H__7311FBDC_02B0_4A85_9D76_6713FCB0EC27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>


class CJoTSView : public CView,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CJoTSView, &CLSID_View>,
	public IConnectionPointContainerImpl<CJoTSView>,
	public IDispatchImpl<IView, &IID_IView, &LIBID_JoTS>
{
protected: // create from serialization only
	CJoTSView();
	DECLARE_DYNCREATE_ATL(CJoTSView)
	DECLARE_REGISTRY_RESOURCEID(IDR_VIEW)
	DECLARE_NOT_AGGREGATABLE(CJoTSView)

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CJoTSView)
		COM_INTERFACE_ENTRY(IView)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY(IConnectionPointContainer)
	END_COM_MAP()
	BEGIN_CONNECTION_POINT_MAP(CJoTSView)
	END_CONNECTION_POINT_MAP()


// Attributes
public:
	CJoTSDoc* GetDocument();
	// Tab control is a child of tab view window.
	CTabCtrl*	m_TabCtrl;

	// Array of all the property-page dialogs
	CTypedPtrArray<CObArray, CDialog*> m_DlgArray;

	void 	CreatePages();
	void OnTabSelChange(NMHDR* pnmhdr, LRESULT* pResult);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJoTSView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	STDMETHOD(Edit_Job_Information)();
	virtual ~CJoTSView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	CDC m_MemDC; 
	CBitmap m_bmpView; 
	int m_nBmpWidth,m_nBmpHeight; 


// Generated message map functions
protected:
	//{{AFX_MSG(CJoTSView)
	afx_msg void OnFileJobsNew();
	afx_msg void OnFileJobsOpen();
	afx_msg void OnRunBatch();
	afx_msg void OnRunSingle();
	afx_msg void OnSetupCustomBasenumber();
	afx_msg void OnFileExport();
	afx_msg void OnFileImport();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileSendMail();
	afx_msg void OnSetupDatasourcesFlatFile();
	afx_msg void OnSetupDatasourcesOdbc();
	afx_msg void OnSetupKeywords();
	afx_msg void OnSetupLogging();
	afx_msg void OnSetupMorphorNetwork();
	afx_msg void OnSetupMorphorSerial();
	afx_msg void OnSetupPrinter();
	afx_msg void OnSetupPrinterLoad();
	afx_msg void OnSetupPrinterSave();
	afx_msg void OnSetupPrinterTest();
	afx_msg void OnSetupPrinterView();
	afx_msg void OnSetupScannerDiagnostic();
	afx_msg void OnSetupScannerEdit();
	afx_msg void OnSetupSecurityAccessRights();
	afx_msg void OnSetupSecurityUser();
	afx_msg void OnSetupSerialization();
	afx_msg void OnSetupSystem();
	afx_msg void OnSetupTemplate();
	afx_msg void OnSetupTemplatesEditor();
	afx_msg void OnEditJobLabels();
	afx_msg void OnEditJobName();
	afx_msg void OnEditJobRun();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnFileClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in JoTSView.cpp
inline CJoTSDoc* CJoTSView::GetDocument()
   { return (CJoTSDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOTSVIEW_H__7311FBDC_02B0_4A85_9D76_6713FCB0EC27__INCLUDED_)
