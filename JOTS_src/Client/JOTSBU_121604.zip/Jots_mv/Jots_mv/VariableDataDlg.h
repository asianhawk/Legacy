#if !defined(AFX_VARIABLEDATADLG_H__84927EF6_DCE2_43ED_843A_5FDBB81E58D0__INCLUDED_)
#define AFX_VARIABLEDATADLG_H__84927EF6_DCE2_43ED_843A_5FDBB81E58D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VariableDataDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

/////////////////////////////////////////////////////////////////////////////
// CVariableDataDlg dialog

class CVariableDataDlg : public CDialog
{
// Construction
public:
	CVariableDataDlg(CWnd* pParent = NULL);   // standard constructor
	~CVariableDataDlg();

// Dialog Data
	//{{AFX_DATA(CVariableDataDlg)
	enum { IDD = IDD_VARIABLE_DATA };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVariableDataDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	CGridCtrl			m_Grid_BC;
	CGridCtrl			m_Grid_HR;
	CGridCtrl			m_Grid_Templates;
	

	void				InitBC_Grid();
	void				InitHR_Grid();
	void				InitTemplates_Grid();
	BOOL				IsModified();


	JobInfo				*m_pJobInfo;

	void				UpdateBCGrid();
	void				UpdateHRGrid();
	void				UpdateTemplateGrid();
	void				UpdateGrids();
	BOOL				VerifyGrids();
	BOOL				VerifyBCGrid();
	BOOL				VerifyHRGrid();
	void				GetDataSeries();
	void				ProcessDataFactoriesCell(int nRowID, int nCount);


protected:

	// Generated message map functions
	//{{AFX_MSG(CVariableDataDlg)
	afx_msg void OnBC_GridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnHR_GridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnTemplates_GridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nTemplateIndex;
	BOOL ScanForChanges();
	CString m_csCurrentName;
	BOOL m_blnModified;
	CStringArray m_csaDataSeries;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VARIABLEDATADLG_H__84927EF6_DCE2_43ED_843A_5FDBB81E58D0__INCLUDED_)
