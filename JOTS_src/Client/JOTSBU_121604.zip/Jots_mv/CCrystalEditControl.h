////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
// MODIFIED for use with CrystalEditView. CMF 2004/08/13



#include "text editor/CCrystalTextBuffer.h"
#include "text editor/CCrystalEditView.h"


class CCrystalEditControl : public CCrystalEditView {
public:
CCrystalEditControl() { }
~CCrystalEditControl() { }

BOOL CreateFromControl(UINT nID, CWnd* pParent);

// Normally, CHtmlView destroys itself in PostNcDestroy,
// but we don't want to do that for a control since a control
// is usually implemented as a stack object in a dialog.
//
virtual void PostNcDestroy() { }

// overrides to bypass MFC doc/view frame dependencies
afx_msg void OnDestroy();
afx_msg int OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT msg);

// Override to get messages since Dialogs normally suck them up.
afx_msg UINT OnGetDlgCode();

DECLARE_MESSAGE_MAP();
DECLARE_DYNAMIC(CCrystalEditControl)
};
