#if !defined(AFX_COMPORTDLG_H__18D19FAB_8C76_4C32_9B37_9A5EDE6E6673__INCLUDED_)
#define AFX_COMPORTDLG_H__18D19FAB_8C76_4C32_9B37_9A5EDE6E6673__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ComPortDlg.h : header file
//

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

/////////////////////////////////////////////////////////////////////////////
// CComPortDlg dialog

class CComPortDlg : public CDialog
{
// Construction
public:
	CComPortDlg(CWnd* pParent = NULL);   // standard constructor
	void InitControls();
	void GetComPortData();
	void SetComPortData();
// Dialog Data
	//{{AFX_DATA(CComPortDlg)
	enum { IDD = IDD_COM_PORT_SETUP };
	CShadeButtonST	m_btnCancel;
	CShadeButtonST	m_btnOK;
	CComboBox	m_cmbStopBits;
	CComboBox	m_cmbParity;
	CComboBox	m_cmbDataBits;
	CComboBox	m_cmbBaudRate;
	CComboBox	m_cmbComPortID;
	CString	m_csBaudRate;
	CString	m_csComPortID;
	CString	m_csDataBits;
	CString	m_csParity;
	CString	m_csStopBits;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComPortDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CComPortDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMPORTDLG_H__18D19FAB_8C76_4C32_9B37_9A5EDE6E6673__INCLUDED_)
