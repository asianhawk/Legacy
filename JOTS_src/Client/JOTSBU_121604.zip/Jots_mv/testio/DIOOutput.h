#ifndef __DIOOUTPUT_H
#define __DIOOUTPUT_H

extern void SetOutputOn(unsigned int nValue);
extern void SetOutputOff(unsigned int nValue);
unsigned int GetOutputValue();


#endif