#if !defined(AFX_DISPLAYTEMPLATESDLG_H__03BFB2B0_FAB5_46F0_BDA9_D70242562F74__INCLUDED_)
#define AFX_DISPLAYTEMPLATESDLG_H__03BFB2B0_FAB5_46F0_BDA9_D70242562F74__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplayTemplatesDlg.h : header file
//
#include "textsrc\ColorEditWnd.h"
#include "textsrc\SampleColorizer.h"
/////////////////////////////////////////////////////////////////////////////
// CDisplayTemplatesDlg dialog

class CDisplayTemplatesDlg : public CDialog
{
// Construction
public:
	CDisplayTemplatesDlg(CWnd* pParent = NULL);   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CDisplayTemplatesDlg)
	enum { IDD = IDD_MAIN_TEMPLATES };
	CComboBox	m_cmbTemplates;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayTemplatesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	JobInfo				*m_pJobInfo;
	void UpdateCombo();
	BOOL UpdateDataSeries(CString csOutput);
	BOOL UpdateBCVars(CString csTemplate);
	BOOL UpdateHRVars(CString csTemplate);
	BOOL IsModified();
	void SetModified(BOOL blnState);
	HWND m_hwndParent;
protected:

   ColorEditWnd * m_pColorWnd;
   CSampleColorizer m_colorizer;
   void InitControls();

   void OnLoad();
   void OnSave();

	// Generated message map functions
	//{{AFX_MSG(CDisplayTemplatesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnLoad();
	afx_msg void OnBtnSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL	m_blnIsModified;
	CString m_csFileName;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPLAYTEMPLATESDLG_H__03BFB2B0_FAB5_46F0_BDA9_D70242562F74__INCLUDED_)
