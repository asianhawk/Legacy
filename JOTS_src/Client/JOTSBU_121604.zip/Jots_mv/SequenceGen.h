#if(!defined __SEQUENCE_GEN_)
#define __SEQUENCE_GEN_



#define AFX_MFC_IMP_TYPE __declspec( dllimport )


extern "C" void AFX_MFC_IMP_TYPE Sequence_Generator(	long tx, char tx_id[], long *tx_status, long *process_status,
											long base, long type, char table[], char begin_samp[],
											char end_samp[], char start[], char end[], char quantity[],
											char start10[], char end10[], char omit[], long msglen, char error[],
											char btypefile[]);


class CSequenceGen
{
public:	
	CSequenceGen();
	CSequenceGen(CString csBaseTypePath);
	void InitSeqGenerator(CString csTable, long lngFieldWidth, int nStepSize);
	void InitSeqGenerator(CString csTable, CString csFieldWidth, int nStepSize);
	void InitSeqGenerator(CString csBaseName,int nStepSize);

	CString GetNextSerialNumber(CString csCurrentValue);
	BOOL GetNextSerialNumber(CString csCurrentValue, CString *csNextValue);
	CString GetStatusMessage();
	BOOL IsError();
	void SetBasePath(CString csBasePath);
	char *GetBasePath();
	void PadString(CString *csValue, int nWidth);


	long	GetFieldWidth();
	void SetFieldWidth(CString csFieldWidth);
	void SetFieldWidth(long lngFieldWidth);
	BOOL GetBase10Equivalent(CString csNumber, long &lngConvertedValue, CString *csErrMessage);

private:

	long	m_lng_tx,
			m_lng_tx_status,
			m_lng_process_status,
			m_lng_base,
			m_lng_type,
			m_lng_msglen;

	char	m_cs_tx_id[13],
			m_cs_table[51],
			m_cs_begin_samp[21],
			m_cs_end_samp[21],
			m_cs_start[21],
			m_cs_end[21],
			m_cs_Seed[21];
	
	char	m_cs_quantity[20],
			m_cs_start10[21],
			m_cs_end10[21],
			m_cs_omit[51],
			m_cs_error[50],
			m_cs_btypefile[255];
	CString m_csBaseTypePath;

	BOOL	m_blnInitComplete;

		

};





#endif