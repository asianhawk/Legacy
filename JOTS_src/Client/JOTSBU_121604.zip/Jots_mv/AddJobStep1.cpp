// AddJobStep1.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep1.h"
#include "PropertyEx.h"
#include "AutoFont.h"
#include "CopyJobDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep1 property page

IMPLEMENT_DYNCREATE(CAddJobStep1, CPropertyPage)

CAddJobStep1::CAddJobStep1() : CPropertyPage(CAddJobStep1::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep1)
	m_csInformation = _T("Information Copy vs. New Job");
	m_optCopyJob = -1;
	//}}AFX_DATA_INIT
}

CAddJobStep1::~CAddJobStep1()
{
}

void CAddJobStep1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep1)
	DDX_Control(pDX, IDC_LBL_INFORMATION, m_lblInformation);
	DDX_Text(pDX, IDC_LBL_INFORMATION, m_csInformation);
	DDX_Radio(pDX, IDC_OPTION, m_optCopyJob);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep1, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep1)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep1 message handlers

BOOL CAddJobStep1::OnSetActive() 
{
	
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_NEXT);
	m_optCopyJob=1;
	UpdateData(FALSE);
	return CPropertyPage::OnSetActive();
}

LRESULT CAddJobStep1::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	
	UpdateData(TRUE);
	if(m_optCopyJob==0)
	{
//		ShowWindow(SW_HIDE);
		parent->ShowWindow(SW_HIDE);  
		parent->m_lastPageID=0;
		CCopyJobDlg *pDlg = new CCopyJobDlg();
		if(pDlg->DoModal()==IDOK)
		{
			parent->ShowWindow(SW_NORMAL);  
			parent->SetJobName(pDlg->GetJobName()); 
			delete pDlg;
			return  IDD_ADDJOB_STEP8;
		}
		delete pDlg;
		parent->ShowWindow(SW_NORMAL);  
		return IDD_ADDJOB_STEP1;
	}
	parent->m_lastPageID=1;
	return CPropertyPage::OnWizardNext();
}

BOOL CAddJobStep1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	InitControls();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CAddJobStep1::InitControls()
{
	m_csInformation.LoadString(IDS_JW_STEP1);

	CAutoFont font("Arial");
	font.SetHeight(36);



	GetDlgItem(IDC_OPTION)->SetFont(&font);
	GetDlgItem(IDC_OPTION_NEW_JOB)->SetFont(&font);





	m_lblInformation.SetFont(&font,TRUE); 
	UpdateData(FALSE);




}

BOOL CAddJobStep1::OnHelpInfo(HELPINFO* pHelpInfo) 
{



	
	return CPropertyPage::OnHelpInfo(pHelpInfo);
}
