// DisplayLabelsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "DisplayLabelsDlg.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define	  PRINTORDER	0
#define	  TEMPLATENAME	1	
#define   SCANCOLUMN	2
#define	  VERIFYSCANCOL 3 
#define   ROTATIONANGLE	4	
#define    COLUMNCOUNT	5





/////////////////////////////////////////////////////////////////////////////
// CDisplayLabelsDlg dialog


CDisplayLabelsDlg::CDisplayLabelsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDisplayLabelsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDisplayLabelsDlg)
	//}}AFX_DATA_INIT

	m_csCurrentTemplate.Empty(); 
}


void CDisplayLabelsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDisplayLabelsDlg)
	DDX_Control(pDX, IDC_UPDATE_JOB_RECORD, m_btnUpdate);
	DDX_Control(pDX, IDC_SPIN1, m_spnMoveLabels);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDisplayLabelsDlg, CDialog)
	//{{AFX_MSG_MAP(CDisplayLabelsDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	ON_NOTIFY(NM_RCLICK,IDC_GRID, OnRMClick)
	ON_WM_HELPINFO()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_LABELS_COPY, OnLabelsCopy)
	ON_COMMAND(ID_LABELS_DELETELABEL, OnLabelsDeletelabel)
	ON_BN_CLICKED(IDC_UPDATE_JOB_RECORD, OnUpdateJobRecord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayLabelsDlg message handlers

void CDisplayLabelsDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
	if ((pItem->iRow>1)&&(pItem->iColumn==SCANCOLUMN))
	{
			ProcessScanCheck(pItem->iRow,SCANCOLUMN);

	}
	else if ((pItem->iRow>1)&&(pItem->iColumn==VERIFYSCANCOL ))
	{
			ProcessScanCheck(pItem->iRow,VERIFYSCANCOL);
	}
	else if ((pItem->iRow>1)&&(pItem->iColumn==TEMPLATENAME ))
	{
		int nDataRow = pItem->iRow - m_Grid.GetFixedRowCount(); 
		ProcessTemplateCell(nDataRow,TEMPLATENAME);	
		SetCurrentSelectedTemplate(m_Grid.GetItemText(nDataRow+2,TEMPLATENAME)); 

	}
	else if ((pItem->iRow>1)&&(pItem->iColumn==ROTATIONANGLE ))
	{
		int nDataRow = pItem->iRow - m_Grid.GetFixedRowCount(); 
		ProcessRotationAngle(nDataRow,ROTATIONANGLE);	

	}

	m_btnUpdate.EnableWindow(TRUE); 		


}

void CDisplayLabelsDlg::OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
 
CRect rect;

	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;


	if (pItem->iRow>m_Grid.GetFixedRowCount()-1)
	{
		m_nCurrentRow=pItem->iRow;//-(m_Grid.GetFixedRowCount()-1);

		m_Grid.GetCellRect(pItem->iRow,pItem->iColumn,&rect );
	


		ClientToScreen(&rect);
      
		CMenu menuTreePopupMaster;
		menuTreePopupMaster.LoadMenu(IDR_POPUP_LABELS);

		//pDefCell->GetEditWnd()
		CMenu* pMenuTreePopup = menuTreePopupMaster.GetSubMenu(0);
		pMenuTreePopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_CENTERALIGN, rect.right   ,rect.bottom , this , NULL);
	}


}


void CDisplayLabelsDlg::InitGrid() 
{

int	nCount;


	m_Grid.SetFixedRowCount(2);
	m_Grid.SetRowCount(MAXLABELS + m_Grid.GetFixedRowCount());		//Data Rows

	m_Grid.SetColumnCount(5);
	m_Grid.SetFixedColumnCount(0);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE); 

    m_Grid.SetItemText(0,PRINTORDER,"Print");
    m_Grid.SetItemText(1,PRINTORDER,"Order");

    m_Grid.SetItemText(1,TEMPLATENAME,"Template Name");
	

    m_Grid.SetItemText(1,SCANCOLUMN,"Scan");

    m_Grid.SetItemText(0,VERIFYSCANCOL,"Verify");
    m_Grid.SetItemText(1,VERIFYSCANCOL,"Scan");

    m_Grid.SetItemText(0,ROTATIONANGLE,"Rotation");
    m_Grid.SetItemText(1,ROTATIONANGLE,"Angle");




	m_Grid.ExpandColumnsToFit(TRUE); 
	m_Grid.m_TitleTip.Create(this);

	

	for (nCount=0;nCount<MAXLABELS;nCount++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			m_Grid.SetItemFormat(nCount,nColumn,DT_CENTER|DT_VCENTER);
		
		}
		m_Grid.SetRowHeight(nCount,25); 
	}

	
	GetAllTemplates();
	DefineRotationAngles();


	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);

	
	m_btnUpdate.EnableWindow(FALSE);
	m_btnUpdate.SetFont(&font);

	m_btnUpdate.SetFont(&font);
	m_btnUpdate.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnUpdate.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnUpdate.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));



}

void CDisplayLabelsDlg::GetAllTemplates()
{
CUtilities *pUtil;

	// Get Printer Templates
	m_csaTemplates.RemoveAll(); 
	pUtil = new CUtilities();
	pUtil->GetTemplates(&m_csaTemplates);
	delete pUtil;


}


void CDisplayLabelsDlg::DefineRotationAngles()
{
CStringArray options;
	m_csaRotationAngles.RemoveAll();
	

	m_csaRotationAngles.Add( _T("0"));
	m_csaRotationAngles.Add( _T("90"));
	m_csaRotationAngles.Add( _T("180"));
	m_csaRotationAngles.Add( _T("-90"));
	m_csaRotationAngles.Add( _T("-180"));


}




BOOL CDisplayLabelsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	InitGrid();	

	// Create the tool tip
	m_Tip.Create(this);
	m_spnMoveLabels.SetBuddy(&m_Grid);
	m_spnMoveLabels.SetRange(0,100); 
	
	// Add the tools
	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);

	CString csTip;
	csTip.LoadString(IDS_TIP_JOB_NAME); 
	m_Tip.AddTool(&m_spnMoveLabels , _T(csTip), m_hIcon1);
	m_Tip.AddTool(&m_Grid, _T(csTip), m_hIcon1);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDisplayLabelsDlg::UpdateGrid()
{

CGridDefaultCell *pDefCell;
int nColumn;

			
	GV_ITEM Item;
	Item.mask = GVIF_TEXT;
	Item.col = SCANCOLUMN;
	Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);
	Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);


	// Define Rotation Angle


	
	for (int nID=0;nID<MAXLABELS;nID++)
	{
		if (!m_pJobInfo->LabelInfo[nID].TemplateName.IsEmpty())	// No need for a combo if only one data definition
		{
			
			for (nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
			{
				pDefCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nColumn);
				if (pDefCell->IsSelected())
					pDefCell->EndEdit(); 
			}

			
			
			m_Grid.SetItemText(nID+2,0, _T(m_pJobInfo->LabelInfo[nID].PrintOrder ));

			// Templates
			ProcessTemplateCell(nID, TEMPLATENAME);
			m_Grid.SetItemText(nID+2,1, _T(m_pJobInfo->LabelInfo[nID].TemplateName));
		

			SetCheckBox(nID,SCANCOLUMN,m_pJobInfo->LabelInfo[nID].ScanLabel);
			SetCheckBox(nID,VERIFYSCANCOL,m_pJobInfo->LabelInfo[nID].VerifyLabel);

			// Rotation Angle
			ProcessRotationAngle(nID,ROTATIONANGLE);
			
			if (!m_pJobInfo->LabelInfo[nID].RotationAngle.IsEmpty()) 
				SetRotationAngle(nID,ROTATIONANGLE,m_pJobInfo->LabelInfo[nID].RotationAngle); 
			else
				SetRotationAngle(nID,ROTATIONANGLE,"0"); 


		
		}
		else
			break;

	}
	m_Grid.SetModified(FALSE);
}

void CDisplayLabelsDlg::ProcessTemplateCell(int nRowID, int nColID)
{

CGridCellCombo *pCell;


	// Templates
	if (!m_Grid.SetCellType(nRowID+2,TEMPLATENAME, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(nRowID+2,TEMPLATENAME);
	pCell->SetOptions(m_csaTemplates);
	pCell->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


}

void CDisplayLabelsDlg::ProcessRotationAngle(int nRowID, int nColID)
{

CGridCellCombo *pCell;


	// Templates
	if (!m_Grid.SetCellType(nRowID+2,ROTATIONANGLE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(nRowID+2,ROTATIONANGLE);
	pCell->SetOptions(m_csaRotationAngles);
	pCell->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


}



void CDisplayLabelsDlg::ProcessScanCheck (int nRowID, int nColID)
{


	if (nRowID<m_Grid.GetFixedRowCount())return;
	if (m_Grid.GetItemText(nRowID,0).IsEmpty())
	{
		SetCheckBox(nRowID-m_Grid.GetFixedRowCount(), nColID, "NO" );	
		return;    
	}	
	
	GV_ITEM Item;
    Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);

	CGridCellCheck* pCell = (CGridCellCheck*) m_Grid.GetCell(nRowID,nColID);
	
	

    Item.mask = GVIF_TEXT;
	Item.row = nRowID;
	Item.col = nColID;



	if(pCell->GetCheck()==1)
	{
		Item.strText = "YES";
        Item.crFgClr = RGB(0,0,255);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    

	}
	else
	{

        Item.strText = "N0";
        Item.crFgClr = RGB(255,0,0);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    
	}
    Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
    m_Grid.SetItem(&Item);
	m_Grid.Refresh(); 
	   	 

}


BOOL CDisplayLabelsDlg::VerifyGrid()
{
CString csTemplate;
CString csPrintOrder;	
CString csReprints;
CString csRescans,
		csRotationAngle;
CString csTemp;

	for (int nID=0;nID<MAXLABELS;nID++)
	{
		  


		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			if( m_Grid.IsCellSelected(nID+2,nColumn) )
			{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nColumn);
				pCell->EndEdit();  
			
			}
		}
		csPrintOrder=m_Grid.GetItemText(nID+2,0);
		csPrintOrder.TrimLeft();
		csPrintOrder.TrimRight(); 
		
		csTemplate= m_Grid.GetItemText(nID+2,1);

		if (csPrintOrder.IsEmpty()&&(!csTemplate.IsEmpty()) )
		{
			CUtilities *pUtil = new CUtilities();
			pUtil->ErrorMessage("Print Order Can Not Be Blank");
			delete pUtil;
			return FALSE;

		}
		else if (csPrintOrder.IsEmpty() && csTemplate.IsEmpty())
		{
			// Need to purge deleted records
			for (int nPurge=nID;nPurge<MAXLABELS;nPurge++)
			{
				m_pJobInfo->LabelInfo[nID].PrintOrder.Empty();
				m_pJobInfo->LabelInfo[nID].TemplateName.Empty();
				m_pJobInfo->LabelInfo[nID].ScanLabel.Empty();  
				m_pJobInfo->LabelInfo[nID].VerifyLabel.Empty();
				m_pJobInfo->LabelInfo[nID].RotationAngle.Empty();
	

			}
			break;
		}
		CUtilities *pUtil = new CUtilities();
		if (csTemplate.IsEmpty())
		{
			pUtil->ErrorMessage("Template Name Can Not Be Blank");
			return FALSE;

		}
		else if (!pUtil->IsValidTemplate(csTemplate)) 
		{
			csTemp.Format("Template [%s] Not Found",csTemplate);
			pUtil->ErrorMessage(csTemp);
			return FALSE;
		}
		delete pUtil;

		m_pJobInfo->LabelInfo[nID].PrintOrder = csPrintOrder;
		m_pJobInfo->LabelInfo[nID].TemplateName=csTemplate;
	
		CGridCellCheck *pCell = (CGridCellCheck*) m_Grid.GetCell(nID+2,SCANCOLUMN);
		if (pCell->GetCheck())
		{
			m_pJobInfo->LabelInfo[nID].ScanLabel="YES"; 
		}
		else
		{
			m_pJobInfo->LabelInfo[nID].ScanLabel="NO"; 
		}
	
	
		pCell = (CGridCellCheck*) m_Grid.GetCell(nID+2,VERIFYSCANCOL);

		
		if (pCell->GetCheck())
		{
			m_pJobInfo->LabelInfo[nID].VerifyLabel ="YES"; 
	
		}
		else
		{
			m_pJobInfo->LabelInfo[nID].VerifyLabel ="NO"; 
		}

		CGridCellCombo *pCellCol = (CGridCellCombo*) m_Grid.GetCell(nID+2,ROTATIONANGLE);

		m_pJobInfo->LabelInfo[nID].RotationAngle  = pCellCol->GetText(); 
		
		

	}
	m_Grid.SetModified(FALSE); 
	return TRUE;
}


BOOL CDisplayLabelsDlg::VerifyTemplates()
{
CString csTemplate,
		csPrintOrder;

	for (int nID=0;nID<MAXLABELS;nID++)
	{
		
		csPrintOrder=m_Grid.GetItemText(nID+2,0);
		csTemplate= m_Grid.GetItemText(nID+2,1);
				
		if (csPrintOrder.IsEmpty() && csTemplate.IsEmpty())
		{
			return TRUE;
		}
		
		

		if (csPrintOrder.IsEmpty()&&(!csTemplate.IsEmpty()) )
		{
			return FALSE;
		}

		if (csTemplate.IsEmpty())
		{
			return FALSE;

		}
		CUtilities *pUtil = new CUtilities();

		if (!pUtil->IsValidTemplate(csTemplate)) 
		{
			delete pUtil;
			return FALSE;
		}
	}
	return TRUE;
}



void CDisplayLabelsDlg::SetCheckBox(int nRow, int nColumn, CString csValue )
{
int nGridRow=0;
 GV_ITEM Item;
	
   Item.crBkClr = RGB(255,255,255);             

	nGridRow = nRow+m_Grid.GetFixedRowCount();
	
	m_Grid.SetCellType(nGridRow,nColumn, RUNTIME_CLASS(CGridCellCheck));
	CGridCellCheck *pCell = (CGridCellCheck*) m_Grid.GetCell(nGridRow/*+2*/,nColumn);


    Item.mask = GVIF_TEXT;
	Item.row = nGridRow;
	Item.col = nColumn;
	
	csValue.MakeUpper(); 
	if (csValue.Find("Y")!=-1)
	{
		Item.strText = "YES";
		Item.crFgClr = RGB(0,0,255);    
		pCell->SetCheck(TRUE);

	}
	else
	{
		Item.strText = "NO";
		Item.crFgClr = RGB(255,0,0);    
		pCell->SetCheck(FALSE); 


	}
    Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
	m_Grid.SetItem(&Item);
	m_Grid.Refresh();  
	

}


void CDisplayLabelsDlg::SetRotationAngle(int  nRow, int nCol, CString csAngle)
{

int nGridRow=0;
 GV_ITEM Item;
	
   Item.crBkClr = RGB(255,255,255);             

	nGridRow = nRow+m_Grid.GetFixedRowCount();
	


	CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(nGridRow,ROTATIONANGLE);



    Item.mask = GVIF_TEXT;
	Item.row = nGridRow;
	Item.col = nCol;
	

	if (!csAngle.IsEmpty())
	{
		Item.strText = csAngle;
		Item.crFgClr = RGB(0,0,0); 
//		pCell->SetText(csAngle); 

	}
    Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
	m_Grid.SetItem(&Item);
	m_Grid.Refresh();  


}
BOOL CDisplayLabelsDlg::IsModified()
{
CString csTemp;

	if(m_Grid.GetModified()) return TRUE;
	
	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nColumn);
				csTemp.Empty(); 
				csTemp=pCell->GetText();
				if (csTemp.IsEmpty()) return FALSE; 

				if (pCell->IsModified())
					return TRUE;
				if( pCell->IsSelected() )
				{
					pCell->EndEdit();
					if (pCell->IsModified())
						return TRUE;
				}

		}
	}
	return FALSE;
}

BOOL CDisplayLabelsDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
HWND hwnd=NULL;
	

	if (IsColSelected(PRINTORDER))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_GRID_PRINT_ORDER);	

		return TRUE;	

	}

	if (IsColSelected(TEMPLATENAME))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TEMPLATE_NAME);	

		return TRUE;	

	}


	if (IsColSelected(SCANCOLUMN))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_SCAN_LABEL);	

		return TRUE;	

	}


	if (IsColSelected(VERIFYSCANCOL))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_VERIFY_LABEL);	

		return TRUE;	

	}


	if (IsColSelected(ROTATIONANGLE))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_ROTATION_ANGLE);	

		return TRUE;	

	}


	if (hwnd==NULL)
	{
		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_DISPLAY_TOPIC,0);	
			return TRUE;
	}
	
	
	return CDialog::OnHelpInfo(pHelpInfo);
}

BOOL CDisplayLabelsDlg::IsColSelected(int nCol)
{
CString csTemp;

	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nCol);
		csTemp.Empty(); 
		csTemp=pCell->GetText();
		if (csTemp.IsEmpty()) return FALSE; 

		if( pCell->IsSelected() )
		{
		//	delete pCell;	
			return TRUE;
		}
	//	delete pCell;
	}
		
	return FALSE;
}


void CDisplayLabelsDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnRButtonDown(nFlags, point);
}

void CDisplayLabelsDlg::OnLabelsCopy() 
{
int nCount=0;
int nRow;
CString csTemp;
BOOL blnFoundBlankRow=FALSE;
	for (nCount=0;nCount<MAXLABELS;nCount++)
	{
		nRow=nCount+m_Grid.GetFixedRowCount(); 
		if (m_Grid.GetItemText(nRow,0).IsEmpty()) 
		{
			blnFoundBlankRow=TRUE;
			break;
		}

	}
	nCount=m_Grid.GetRowCount();
	if (nRow>=m_Grid.GetRowCount()) 
	{
		nCount=m_Grid.InsertRow(NULL,-1); 
		for (int nCol=0;nCol<COLUMNCOUNT;nCol++)
		{
			m_Grid.SetItemFormat(nCount,nCol,DT_CENTER|DT_VCENTER);
		}
		m_Grid.SetRowHeight(nCount,25); 

	}
	
	
	if ((blnFoundBlankRow)&&(nRow<MAXLABELS))
	{
		csTemp=m_Grid.GetItemText(m_nCurrentRow,PRINTORDER); 
		m_Grid.SetItemText(nRow,PRINTORDER,csTemp);

		csTemp=m_Grid.GetItemText(m_nCurrentRow,TEMPLATENAME); 
		ProcessTemplateCell(nRow-m_Grid.GetFixedRowCount() ,TEMPLATENAME);
		m_Grid.SetItemText(nRow,TEMPLATENAME,csTemp);
		
		ProcessScanCheck (nRow-m_Grid.GetFixedRowCount(), SCANCOLUMN);
		csTemp=m_Grid.GetItemText(m_nCurrentRow,SCANCOLUMN); 
		SetCheckBox(nRow-2,SCANCOLUMN,csTemp);


		ProcessScanCheck (nRow-m_Grid.GetFixedRowCount(), VERIFYSCANCOL);
		csTemp=m_Grid.GetItemText(m_nCurrentRow,VERIFYSCANCOL); 
		SetCheckBox(nRow-2,VERIFYSCANCOL,csTemp);

		ProcessRotationAngle(nRow-m_Grid.GetFixedRowCount(), ROTATIONANGLE);
		csTemp=m_Grid.GetItemText(m_nCurrentRow,ROTATIONANGLE); 
		m_Grid.SetItemText(nRow,ROTATIONANGLE,csTemp);

	}
	m_Grid.Refresh();
	m_Grid.ExpandColumnsToFit(TRUE);
}

void CDisplayLabelsDlg::OnLabelsDeletelabel() 
{
	// Do not delete first row
	if (m_nCurrentRow>m_Grid.GetFixedRowCount())
	{
		m_Grid.DeleteRow(m_nCurrentRow);
		m_Grid.Refresh();
		m_Grid.ExpandColumnsToFit(TRUE);
		m_Grid.SetModified(TRUE); 
	}

}

BOOL CDisplayLabelsDlg::PreTranslateMessage(MSG* pMsg) 
{
//	MSG msg = *pMsg;

		MSG msg = *pMsg;
		msg.hwnd = (HWND)m_Tip.SendMessage(TTM_WINDOWFROMPOINT, 0, (LPARAM)&msg.pt);
		CPoint pt = pMsg->pt;
		if (msg.message >= WM_MOUSEFIRST && msg.message <= WM_MOUSELAST)
			::ScreenToClient(msg.hwnd, &pt);
		msg.lParam = MAKELONG(pt.x, pt.y);
		m_Tip.RelayEvent(&msg); 
	
	return CDialog::PreTranslateMessage(pMsg);
}

CString	CDisplayLabelsDlg::GetCurrentSelectedTemplate()
{
	return m_csCurrentTemplate;

}

void CDisplayLabelsDlg::SetCurrentSelectedTemplate(CString csTemplate)
{
	m_csCurrentTemplate=csTemplate;

}


void CDisplayLabelsDlg::OnUpdateJobRecord() 
{

	
	if (!VerifyGrid())return;

	::SendMessage(m_hwndParent,UWM_UPDATE_TEMPLATE,0,0); 


}
