// SequenceInfoDlg.h : header file
//
//	$History: SequenceInfoDlg.h $
//
//*****************  Version 3  *****************
//User: Neil.vaneps  Date: 12/04/01   Time: 4:13p
//Updated in $/C++ Code/Label System/LabelData
//Added extern "C" modifier to externally accessible DLL calls.
//
//*****************  Version 2  *****************
//User: Neil.vaneps  Date: 10/10/01   Time: 11:24a
//Updated in $/C++ Code/Label System/LabelData
//
//*****************  Version 1  *****************
//User: Neil.vaneps  Date: 10/10/01   Time: 10:58a
//Created in $/C++ Code/Label System/LabelData
//Added some shared dialogs to the DLL.
//

#if !defined(AFX_SEQUENCEINFODLG_H__D1778FE8_8E38_11D4_868E_00104B2B0208__INCLUDED_)
#define AFX_SEQUENCEINFODLG_H__D1778FE8_8E38_11D4_868E_00104B2B0208__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CSequenceInfoDlg dialog

//extern "C" void Sequence_Generator(long tx, char tx_id[], long *tx_status,
//							   long *process_status, long base, long type,
//							   char table[], char begin_samp[], char end_samp[],
//							   char start[], char end[], char quantity[],
//							   char start10[], char end10[], char omit[],
//							   long msglen, char error[], char btypefile[]);

enum numbering_type
{
	BASE_NUMBERING,
	IBM_NUMBERING,
	SPECIAL_NUMBERING
};

extern "C" int AFX_MFC_IMP_TYPE GetLabelDataBuildNumber();

class AFX_MFC_IMP_TYPE CSequenceInfoDlg : public CDialog
{
// Construction
public:
	CSequenceInfoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSequenceInfoDlg)
	enum { IDD = 2304 };//IDD_SEQUENCE_INFO };
	CButton	m_btnExit;
	CStatic	m_lblValidCharacters;
	CStatic	m_lblType;
	CButton	m_grpSequenceInformation;
	CStatic	m_lblQuantity;
	CStatic	m_lblOmitCharacters;
	CButton	m_grpNumberingInformation;
	CStatic	m_lblMinimumMessage;
	CStatic	m_lblMessageLength;
	CStatic	m_lblMaximumMessage;
	CStatic	m_lblEndingNumber;
	CButton	m_btnClear;
	CButton	m_btnCalculate;
	CStatic	m_lblBeginningNumber;
	CStatic	m_lblBase2;
	CStatic	m_lblBase10EndingNumber;
	CStatic	m_lblBase10BeginningNumber;
	CStatic	m_lblBase1;
	CButton	m_btnHelp;
	CEdit	m_edtSpecialType;
	CEdit	m_edtOmitCharacters;
	CButton	m_chkBase;
	CButton	m_chkSpecial;
	CButton	m_chkIBM;
	CButton	m_chkCharacterSet;
	CButton	m_chkUseStandard;
	CEdit	m_edtCustomCharacters;
	CEdit	m_edtIBMBase;
	CEdit	m_edtBase;
	CString	m_csBase;
	CString	m_csBegin;
	CString	m_csEnd;
	CString	m_csQuantity;
	CString	m_csBeginBase10;
	CString	m_csEndBase10;
	CString	m_csCustomCharacters;
	CString	m_csSpecialType;
	CString	m_csOmitCharacters;
	CString	m_csMessageLength;
	CString	m_csBeginSample;
	CString	m_csEndSample;
	CString	m_csTable;
	CString	m_csIBMBase;
	CString	m_csInfo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSequenceInfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSequenceInfoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBaseCheck();
	afx_msg void OnCharacterSetCheck();
	afx_msg void OnIbmCheck();
	afx_msg void OnSpecialCheck();
	afx_msg void OnUseStandardCheck();
	afx_msg void OnCalculate();
	afx_msg void OnChangeBase();
	afx_msg void OnChangeOmitCharacters();
	afx_msg void OnChangeCustomCharacterSet();
	afx_msg void OnChangeSpecialNumberingType();
	afx_msg void OnClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void LoadCaptions();
	CString m_csBaseTypePath;
	void EnableIBMNumbering();
	void EnableSpecialNumbering();
	void EnableBaseNumbering();
	void DisableIBMNumbering();
	void DisableSpecialNumbering();
	void DisableBaseNumbering();
	BOOL IsValidInputSet();
	BOOL IsNumeric(CString csNumber);
	void ClearSequenceInformation();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEQUENCEINFODLG_H__D1778FE8_8E38_11D4_868E_00104B2B0208__INCLUDED_)
