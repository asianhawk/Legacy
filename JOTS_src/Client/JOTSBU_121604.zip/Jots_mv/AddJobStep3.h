#if !defined(AFX_ADDJOBSTEP3_H__4C7D25A1_FFBC_4263_B380_C042F45E3AB7__INCLUDED_)
#define AFX_ADDJOBSTEP3_H__4C7D25A1_FFBC_4263_B380_C042F45E3AB7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep3.h : header file
//

#include "Edit Class Ex/amsEdit.h"
#include "tooltip/PPTooltip.h"
/////////////////////////////////////////////////////////////////////////////
// CAddJobStep3 dialog

class CAddJobStep3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep3)

// Construction
public:
	CAddJobStep3();
	~CAddJobStep3();
	void					InitControls();

// Dialog Data
	//{{AFX_DATA(CAddJobStep3)
	enum { IDD = IDD_ADDJOB_STEP3 };
	CButton	m_chkIsStatic;
	CButton	m_chkAllowDuplicates;
	CSpinButtonCtrl	m_spnStepSize;
	CSpinButtonCtrl	m_spnFieldWidth;
	CAMSNumericEdit	m_edtStepSize;
	CAMSAlphanumericEdit	m_edtRollOverValue;
	CAMSAlphanumericEdit	m_edtSSN;
	CAMSAlphanumericEdit	m_edtMSN;
	CAMSNumericEdit	m_edtMaxWidth;
	CAMSAlphanumericEdit	m_editSequenceName;
	CComboBox	m_cmbBaseNumber;
	CComboBox	m_cmbChkDigit;
	CString	m_csSequenceName;
	CString	m_csMaxFieldWidth;
	CString	m_csMaxSequenceNumber;
	CString	m_csStartingSerialNumber;
	BOOL	m_blnAllowDuplicates;
	CString	m_csRollOverValue;
	CString	m_txbStepSize;
	BOOL	m_blnStatic;
	CString	m_csSequenceLabel;
	CString	m_csIndexName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep3)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardBack();
	virtual LRESULT OnWizardNext();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep3)
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnChkStaticVar();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL VerifyData();
	CString m_csErrorMessage;
	void LoadCheckDigits();
	
	// toop tip vars and functions
	void						CreateToolTips();
	void						SetToolTipsProperties();
	
	CPPToolTip 		m_Tip;
	HICON			m_hIcon1;
	long			m_lngColorGrad1;
	long			m_lngColorGrad2;
	long			m_lngColorGrad3;


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP3_H__4C7D25A1_FFBC_4263_B380_C042F45E3AB7__INCLUDED_)
