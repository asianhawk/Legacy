#ifndef _PRINTANDAPPLY_H
#define _PRINTANDAPPLY_H

extern int PrintAndApplyLabel(int filedes, char* status, char* bytes);

#endif /* _PRINTANDAPPLY_H */
