/////////////////////////////////////////////////////////////////////////////
// StaticEx.cpp : implementation file
//
// Copyright (C) 1996 Bill Berry
// All rights reserved.
//
// This class is freely distributable as long as the copyright accompanies 
// the header and implementaion sources.
//
// Modification History:
//
// Bill Berry	November 1996		Created
//              March    1998           Update
// Ted Sarma    September 2002		Cleanup and defect fixes
//
// Description:
//
//  Extended CStatic class. Allows easy customization of the following:
//
//      1. COLORREF bkColor( COLORREF crColor )
//         - Sets back ground color of the control
//
//      2. COLORREF textColor( COLORREF crColor )
//         - Sets text or foreground color of the control
//
//      3. COLORREF bkColor() const
//         - Returns back ground color of control
//
//      4. COLORREF textColor() const
//         - Returns text (or foreground) color of control
//
//      5. void setFont( const LOGFONT* lpLogFont )
//         - Sets the font of the static control.
//
//      *** Set new font for this control ***
//  
//      6. void setFont( LONG fontHeight      = -8, 
//                       LONG fontWeight      = FW_NORMAL,
//                       UCHAR pitchAndFamily = DEFAULT_PITCH | FF_DONTCARE,
//                       LPCSTR faceName      = _T("MS Sans Serif")
//                     );
//
#include "stdafx.h"
//#include "resource.h"
#include "LogFont.h"
#include "StaticEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStaticEx

IMPLEMENT_DYNCREATE( CStaticEx, CStatic )

BEGIN_MESSAGE_MAP(CStaticEx, CStatic)
	//{{AFX_MSG_MAP(CStaticEx)
	//}}AFX_MSG_MAP
    ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()

CStaticEx::CStaticEx() 
{
    // Use system colors for defaults
    //
    m_crTextColor = ::GetSysColor( COLOR_WINDOWTEXT );
    m_crBkColor   = ::GetSysColor( COLOR_3DFACE     );

    // The default brush type; SOLID
    //
    CreateBrushType();

    // Uses default font
    //
    m_pCFont = 0;
}

CStaticEx::~CStaticEx()
{
    if ( m_pCFont ) delete m_pCFont;
}


// Note: Copy construction is blocked for this class.
//       This is because there would be no defined
//       m_hWnd during the construction of the object.
//
// CStaticEx::CStaticEx( const CStaticEx& o )
//

// Allow = operator to be used for copying basics.
//
CStaticEx& CStaticEx::operator = ( const CStaticEx& o )
{

    _ASSERT( o != *this ); // You probably did not mean to do this...

    if ( o == *this ) return *this; // copying self...
    
    bkColor( o.m_crBkColor );
    textColor( o.m_crTextColor );

    if ( o.m_pCFont ) {
         CLogFont pLogFont;
         o.m_pCFont->GetLogFont( &pLogFont );
         setFont( &pLogFont );
    }

    m_msg_flags         = o.m_msg_flags;
    m_wm_message        = o.m_wm_message;

    return *this;
}

/////////////////////////////////////////////////////////////////////////////
// CStaticEx message handlers

void CStaticEx::setFont( const LOGFONT* lpLogFont )
{
    _ASSERT( lpLogFont ); // logfont is not defined!!!

    if ( !lpLogFont ) return;

    if ( m_pCFont ) delete m_pCFont;
    
    m_pCFont = new CFont;
    m_pCFont->CreateFontIndirect( lpLogFont );

    SetFont( m_pCFont );
}

void CStaticEx::setFont( LONG fontHeight      /* = -8                         */, 
                         LONG fontWeight      /* = FW_NORMAL                  */,
                         UCHAR pitchAndFamily /* = DEFAULT_PITCH | FF_DONTCARE*/,
                         LPCSTR faceName      /* = _T("MS Sans Serif")        */ )
{
    if ( m_pCFont ) 
    {
        delete m_pCFont;
    }
    m_pCFont = new CFont;

    const CLogFont lf( fontHeight, 
                       fontWeight,
                       pitchAndFamily,
                       faceName
                     );

    m_pCFont->CreateFontIndirect( &lf );

    SetFont( m_pCFont );
}

COLORREF CStaticEx::bkColor( COLORREF crColor )
{
    _ASSERT(::IsWindow(m_hWnd)); 

    COLORREF cr = m_crBkColor;
    
    m_crBkColor = crColor;
    
    m_brBkGround.DeleteObject();
    
    CreateBrushType();
    
    Invalidate();

    return cr;
}

COLORREF CStaticEx::textColor( COLORREF crColor )
{
    _ASSERT(::IsWindow(m_hWnd)); 
    
    COLORREF cr = m_crTextColor;
    
    m_crTextColor = crColor;
    
    Invalidate();
    
    return cr;
}


BOOL CStaticEx::CreateBrushType()
{
    return m_brBkGround.CreateSolidBrush( m_crBkColor );
}


HBRUSH CStaticEx::CtlColor(CDC* pDC, UINT nCtlColor) 
{
    pDC->SetTextColor( m_crTextColor );
    pDC->SetBkColor  ( m_crBkColor );

    return (HBRUSH)m_brBkGround;
}
