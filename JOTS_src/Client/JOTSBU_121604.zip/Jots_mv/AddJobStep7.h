#if !defined(AFX_ADDJOBSTEP7_H__28F27E98_DB7B_48BF_BDB4_D8EAFFA66BE1__INCLUDED_)
#define AFX_ADDJOBSTEP7_H__28F27E98_DB7B_48BF_BDB4_D8EAFFA66BE1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep7.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep7 dialog

class CAddJobStep7 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep7)

// Construction
public:
	CAddJobStep7();
	~CAddJobStep7();
	CGridCtrl				m_Grid;
	void					InitGrid();
	void					GetHRTemplateInfo(CString csTemplate);
	int						m_nNumberOfHR_vars;
	CStringArray			m_csaHRVars;
	BOOL					VerifyData();

	int m_nTemplateCount;
	CStringArray m_csaTemplatesProcessed;
	void PreProcessTemplates();
	void PopulateTemplateDataIntoJobRecord();


// Dialog Data
	//{{AFX_DATA(CAddJobStep7)
	enum { IDD = IDD_ADDJOB_STEP7 };
	CString	m_csTemplatePath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep7)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep7)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void	InitControls();


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP7_H__28F27E98_DB7B_48BF_BDB4_D8EAFFA66BE1__INCLUDED_)
