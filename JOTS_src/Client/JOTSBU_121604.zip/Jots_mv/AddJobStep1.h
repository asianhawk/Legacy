#if !defined(AFX_ADDJOBSTEP1_H__19AED4B7_5532_4DF0_A566_5F59A45A6583__INCLUDED_)
#define AFX_ADDJOBSTEP1_H__19AED4B7_5532_4DF0_A566_5F59A45A6583__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep1.h : header file
//

#include "staticctrlex/StaticEx.h"

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep1 dialog

class CAddJobStep1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep1)

// Construction
public:
	CAddJobStep1();
	~CAddJobStep1();
	void InitControls();

// Dialog Data
	//{{AFX_DATA(CAddJobStep1)
	enum { IDD = IDD_ADDJOB_STEP1 };
	CStatic m_lblInformation;
	CString	m_csInformation;
	int		m_optCopyJob;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep1)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep1)
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP1_H__19AED4B7_5532_4DF0_A566_5F59A45A6583__INCLUDED_)
