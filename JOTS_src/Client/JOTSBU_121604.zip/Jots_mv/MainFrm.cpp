// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "JoTS.h"

#include "MainFrm.h"
#include "JoTSDoc.h"
#include "JobWizard.h"
#include "MorphorTCPSetupDlg.h"
#include "ComPortDlg.h"
#include "Utilities.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_SETUP_MORPHOR_NETWORK, OnSetupMorphorNetwork)
	ON_COMMAND(ID_SETUP_MORPHOR_SERIAL, OnSetupMorphorSerial)
	ON_WM_MEASUREITEM()
	ON_WM_MENUCHAR()
	ON_WM_INITMENUPOPUP()
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_blnToolsflag=FALSE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnFileNew() 
{
CString csTemp,
		csJobsDirectory;
CJobWizard objWizard;


	objWizard.CreateNewJob(); 
	csTemp=objWizard.GetJobName();
	if (!csTemp.IsEmpty()) 
	{
	   CUtilities *pUtil = new CUtilities();
	   if (!pUtil->GetJobsDirectory(&csJobsDirectory))
	   {
		   delete pUtil;
		   return;
	   }
	   csTemp.MakeLower(); 
	   csTemp.Replace(".xml",""); 
	   csTemp=csJobsDirectory+csTemp+".xml";
	   if(pUtil->IsFileValid(csTemp)) 
	   	  AfxGetApp()->OpenDocumentFile(csTemp);
	   else
	   {
		   csTemp.Format("New Job File [%s] Not Found",csJobsDirectory+csTemp+".xml");
	 	   pUtil->ErrorMessage(csTemp,"File Not Found");

	   }
	   delete pUtil;
	}
}


void CMainFrame::OnSetupMorphorNetwork() 
{

CMorphorTCPSetupDlg *pDlg;

	pDlg = new CMorphorTCPSetupDlg();

	pDlg->DoModal();

	delete pDlg;
		
}

void CMainFrame::OnSetupMorphorSerial() 
{
CComPortDlg *pDlg;

	pDlg = new CComPortDlg();

	pDlg->DoModal();
	
	delete pDlg;

	
}

HMENU CMainFrame::NewMenu()
{
  static UINT toolbars[]={
      IDR_MAINFRAME
  };

  // Load the menu from the resources
  // ****replace IDR_MENUTYPE with your menu ID****
  m_menu.LoadMenu(IDR_MAINMENU);  
  // One method for adding bitmaps to menu options is 
  // through the LoadToolbars member function.This method 
  // allows you to add all the bitmaps in a toolbar object 
  // to menu options (if they exist). The first function 
  // parameter is an array of toolbar id's. The second is 
  // the number of toolbar id's. There is also a function 
  // called LoadToolbar that just takes an id.
 m_menu.LoadToolbars(toolbars,1);



  return(m_menu.Detach());
}

HMENU CMainFrame::NewDefaultMenu()
{
  m_default.LoadMenu(IDR_MAINFRAME);
  m_default.LoadToolbar(IDR_MAINFRAME);
  return(m_default.Detach());
}

void CMainFrame::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
 BOOL setflag=FALSE;
  if(lpMeasureItemStruct->CtlType==ODT_MENU){
    if(IsMenu((HMENU)lpMeasureItemStruct->itemID)){
      CMenu* cmenu = 
       CMenu::FromHandle((HMENU)lpMeasureItemStruct->itemID);

      if(m_menu.IsMenu(cmenu)||m_default.IsMenu(cmenu)){
        m_menu.MeasureItem(lpMeasureItemStruct);
        setflag=TRUE;
      }
    }
  }

  if(!setflag)CMDIFrameWnd::OnMeasureItem(nIDCtl, 
                                          lpMeasureItemStruct);
}

LRESULT CMainFrame::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
  LRESULT lresult;
  if(m_menu.IsMenu(pMenu)||m_default.IsMenu(pMenu))
    lresult=BCMenu::FindKeyboardShortcut(nChar, nFlags, pMenu);
  else
    lresult=CMDIFrameWnd::OnMenuChar(nChar, nFlags, pMenu);
  return(lresult);

}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
  CMDIFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
  if(!bSysMenu)
  {
    if(m_menu.IsMenu(pPopupMenu)||m_default.IsMenu(pPopupMenu))
      BCMenu::UpdateMenu(pPopupMenu);
  }
	
}



BOOL CMainFrame::BuildToolsMenu(HMENU hMenu)
{
#ifdef UNICODE
    wchar_t szMenuText[256];
#else
    char szMenuText[256];
#endif
    int  nIdx;

	// this memory is cleaned up when when the menu is deleted (DeleteMenu)
	// or when the application is closed. Whichever happens first.
	BCMenu *pBCMenu = new BCMenu;
	int nRes;
    nRes=pBCMenu->CreateMenu();

    // Append an Edit Tools item
    pBCMenu->AppendMenu(MF_STRING, ID_APP_ABOUT, _T("&Edit Tools..."));

    // Add a separator before the user-defined tools
    pBCMenu->AppendMenu(MF_SEPARATOR);

    // Append one menu item for each user-defined item
    for(nIdx = 0; nIdx < 10; nIdx++)
    {
#ifdef UNICODE
        wsprintf(szMenuText, _T("User Item #%d"), nIdx + 1);
#else
        sprintf(szMenuText, "User Item #%d", nIdx + 1);
#endif
        pBCMenu->AppendMenu(MF_STRING, ID_APP_ABOUT, szMenuText);
    }

    nRes=m_menu.Attach(hMenu);
    nRes=m_menu.InsertMenu( 2, MF_BYPOSITION | MF_BYCOMMAND |MF_POPUP, (UINT)pBCMenu->m_hMenu, _T("Tools"));
 	m_menu.Detach();

    return TRUE;
}