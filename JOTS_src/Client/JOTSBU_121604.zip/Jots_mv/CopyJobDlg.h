#if !defined(AFX_COPYJOBDLG_H__4702C642_3422_4695_9853_6FC339DD6B86__INCLUDED_)
#define AFX_COPYJOBDLG_H__4702C642_3422_4695_9853_6FC339DD6B86__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CopyJobDlg.h : header file
//

#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"
/////////////////////////////////////////////////////////////////////////////
// CCopyJobDlg dialog

class CCopyJobDlg : public CDialog
{
// Construction
public:
	CCopyJobDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCopyJobDlg();
	CString GetJobName();
	void	SetJobName(CString csJobName);

// Dialog Data
	//{{AFX_DATA(CCopyJobDlg)
	enum { IDD = IDD_COPY_JOBS };
	CStatic	m_lblTitle;
	CButton	m_btnCancel;
	CButton	m_btnCopy;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCopyJobDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCopyJobDlg)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CCopyJobDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
public:
	void				InitGrid();
	JobInfo				*m_pJobInfo;
	CGridCtrl			m_Grid;
	BOOL				GetAvailableJobs();
	void				InitControls();
	BOOL				IsModified();

private:
	int					m_nCurrentRow;
	CStringArray		m_csaJobNames;
	CString				m_csJobDirectory;
	CString				m_csJobName;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COPYJOBDLG_H__4702C642_3422_4695_9853_6FC339DD6B86__INCLUDED_)
