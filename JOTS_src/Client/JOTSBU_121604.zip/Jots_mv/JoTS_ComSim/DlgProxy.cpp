// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS_ComSim.h"
#include "DlgProxy.h"
#include "JoTS_ComSimDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlgAutoProxy

IMPLEMENT_DYNCREATE(CJoTS_ComSimDlgAutoProxy, CCmdTarget)

CJoTS_ComSimDlgAutoProxy::CJoTS_ComSimDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CJoTS_ComSimDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CJoTS_ComSimDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CJoTS_ComSimDlgAutoProxy::~CJoTS_ComSimDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CJoTS_ComSimDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CJoTS_ComSimDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CJoTS_ComSimDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CJoTS_ComSimDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CJoTS_ComSimDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IJoTS_ComSim to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {233CDD76-2416-4BD0-8886-6CECF587EEFE}
static const IID IID_IJoTS_ComSim =
{ 0x233cdd76, 0x2416, 0x4bd0, { 0x88, 0x86, 0x6c, 0xec, 0xf5, 0x87, 0xee, 0xfe } };

BEGIN_INTERFACE_MAP(CJoTS_ComSimDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CJoTS_ComSimDlgAutoProxy, IID_IJoTS_ComSim, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {AFEBBDF1-D33F-49F3-B7D1-DE94928251EA}
IMPLEMENT_OLECREATE2(CJoTS_ComSimDlgAutoProxy, "JoTS_ComSim.Application", 0xafebbdf1, 0xd33f, 0x49f3, 0xb7, 0xd1, 0xde, 0x94, 0x92, 0x82, 0x51, 0xea)

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlgAutoProxy message handlers
