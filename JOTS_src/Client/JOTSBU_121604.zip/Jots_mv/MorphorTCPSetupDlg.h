#if !defined(AFX_MORPHORTCPSETUPDLG_H__C7D60114_96F2_41C2_AA41_4505093F1022__INCLUDED_)
#define AFX_MORPHORTCPSETUPDLG_H__C7D60114_96F2_41C2_AA41_4505093F1022__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MorphorTCPSetupDlg.h : header file
//

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

#include "LMorphor3.h"

/////////////////////////////////////////////////////////////////////////////
// CMorphorTCPSetupDlg dialog




class CMorphorTCPSetupDlg : public CDialog
{
// Construction
public:
	
	CMorphorTCPSetupDlg(CWnd* pParent = NULL);   // standard constructor
	
	void InitControls();
	void GetTCPValues();




	BOOL VerifyTCPAddress();
	BOOL VerifyTCPPort();
	BOOL Verify();
	void UpdateMsgDisplay(CString csMessage);
	CLMorphor3 *m_pMorphor;

// Dialog Data
	//{{AFX_DATA(CMorphorTCPSetupDlg)
	enum { IDD = IDD_SETUP_TCP };
	CShadeButtonST	m_btnOK;
	CShadeButtonST	m_btnCancel;
	CShadeButtonST	m_btnTest;
	CComboBox	m_cmbLM3Cmds;
	CEdit	m_edtTestMessage;
	CString	m_csTCPAddress;
	CString	m_csTCPPort;
	CString	m_csMessage;
	CString	m_csLM3Command;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMorphorTCPSetupDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMorphorTCPSetupDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBtnTest();
	afx_msg void OnUpdateTxbTest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MORPHORTCPSETUPDLG_H__C7D60114_96F2_41C2_AA41_4505093F1022__INCLUDED_)
