// TCPComm.cpp : implementation file
//

#include "stdafx.h"
//#include "JoTS.h"
#include "TCPComm.h"
#include "LMorphor3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTCPComm

CTCPComm::CTCPComm(CLMorphor3 *pMorphor)
{
	m_pMorphor = pMorphor;
}

CTCPComm::~CTCPComm()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CTCPComm, CSocket)
	//{{AFX_MSG_MAP(CTCPComm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CTCPComm member functions

void CTCPComm::OnReceive(int nErrorCode) 
{
	
	CSocket::OnReceive(nErrorCode);

	m_pMorphor->ProcessPendingRead(); 



}
