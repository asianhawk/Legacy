////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "StdAfx.h"
#include "CCrystalEditControl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define NO_CLASS_NAME NULL
#define NO_TITLE NULL


IMPLEMENT_DYNAMIC(CCrystalEditControl, CCrystalEditView)
BEGIN_MESSAGE_MAP(CCrystalEditControl, CCrystalEditView)
ON_WM_DESTROY()
ON_WM_MOUSEACTIVATE()
ON_WM_GETDLGCODE()
END_MESSAGE_MAP()

//////////////////
// Create control in same position as an existing control with the same ID.
BOOL CCrystalEditControl::CreateFromControl( UINT controlID, CWnd* parentWindow )
{
CEdit editControl;
CRect controlRect;

// Subclass the control at that id.
if (!editControl.SubclassDlgItem( controlID, parentWindow ) )
return FALSE;

// Get static control rect, convert to parent's client coords.
editControl.GetWindowRect(&controlRect);
parentWindow->ScreenToClient(&controlRect);
editControl.DestroyWindow();

// Create the CrystalEdit control (CCrystalEditView)
return Create( NO_CLASS_NAME, NO_TITLE, (WS_CHILD | WS_VISIBLE | WS_TABSTOP), controlRect,
parentWindow, controlID, NULL );

} // CCrystalEditControl::CreateFromControl


UINT CCrystalEditControl::OnGetDlgCode()
{
// We want all the keys.
return DLGC_WANTALLKEYS;

} // CCrystalEditControl::OnGetDlgCode


////////////////
// Override to avoid CView stuff that assumes a frame.
//
void CCrystalEditControl::OnDestroy()
{
// NOTE: This stuff was copied from CCrystalEditView::OnDestroy
// since we are skipping it and going right to the CWnd::OnDestroy
// because CCrystalEditView::OnDestroy calls CView::OnDestroy which
// doesn't work since it assumes it's in a frame window which it
// won't be as a control.

// Detach from our buffer.
DetachFromBuffer();
m_hAccel = NULL;

// Bypass CView doc/frame stuff
CWnd::OnDestroy(); 

for ( int I = 0; I < 4; I ++ )
{
if ( m_apFonts[I] != NULL )
{
m_apFonts[I]->DeleteObject();
delete m_apFonts[I];
m_apFonts[I] = NULL;
}
}
if ( m_pCacheBitmap != NULL )
{
delete m_pCacheBitmap;
m_pCacheBitmap = NULL;
}

} // CCrystalEditControl::OnDestroy

////////////////
// Override to avoid CView stuff that assumes a frame.
//
int CCrystalEditControl::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT msg)
{
int result;

// bypass CView doc/frame stuff
result = CWnd::OnMouseActivate(pDesktopWnd, nHitTest, msg);

// re-activate this view
CView::OnActivateView(TRUE, this, this);

// Return the result.
return result;

} // CCrystalEditControl::OnMouseActivate
