#ifndef __ProcessJob
#define __ProcessJob

#include "JoTS.h"
#include "LMorphor3.h"
#include "XML\XMLFile.h"
#include "JoTSDoc.h"
#include "RunDlg.h"

#define JOBERROR							0
#define JOBSTARTEDOK						1
#define JOBWAITINGFORPARTPRESENT			2
#define JOBWAITINGFORCYCLECOMPLETE			4
#define JOBWAITINGFORPART2BREMOVED			8

#define JOBPRINTCOMPLETED					16

#define LABELNOTCONFIGUREDFORSCANNING		32
#define BARCODENOTMATCHEDTOPRINTEDVALUE		64
#define GOODSCAN							128


#define JOBSTOPPED							256
#define ERRORCONNECTINGTOM3					512
#define APPLICATORREADYERROR				1024
#define LABELAPPLYERROR						2048

class CProcessJob 
{
public:
	CProcessJob(CString csJobName, CLMorphor3 *pLMorphor3);
	CProcessJob(CJoTSDoc	*pDoc, CLMorphor3 *pLMorphor3);

	~CProcessJob();

	BOOL BuildTemplate(int nLabelIndex, CString *csTemplate);
	CString GetTemplatePath(int nLabelIndex);
	int		PrintLabel(int nLabelIndex);
	
	CString ProcessTemplate(CString csRawTemplate);

	void    ProcessBCVars(CString *csTemplate, BC_Vars *BCVars);
	void	ProcessHCVars(CString *csTemplate, HR_Vars *HRVars);

	CString BuildSerialNumber(CString csSerialVar);
	CStringArray m_csaBarCodeValues;
	void	Run();
	BOOL	ScanLabel();
	BOOL	ScanLabel(CRunDlg *pRunDlg);
	
	BOOL	GetUseNewSerialNumber();
	void	SetUseNewSerialNumber(BOOL blnState);

	BOOL	WaitForResponse(int nTimeOut);

	BOOL	InitTimeOuts();
	BOOL	Init();
	void	SetMaxItems(int nMaxItems);
	int		GetMaxItems();
	void	UpdateDisplay(CRunDlg *pRunDlg, int nLabelID);
	int		GetLabelsPerUnit();
	void	SetRunDlg(CRunDlg *pDlg);
	BOOL	HoldOrExit();
	BOOL	AutoRun();
	DWORD WINAPI	AutoPrint();
	void	AutoInit();



	// DIO Inputs
	BOOL	IsPartPresent();
	BOOL    IsPartRemoved();
	BOOL	IsApplicatorReady();
	BOOL	IsPrintCycleComplete();
	void	ResetApplicator();

	// DIO Outputs
	void    StartApplicator(BOOL blnState);
	void	StopApplicator(BOOL blnState);
	void	ApplyLabel(BOOL blnState);
	void	SetEStop(BOOL blnState);
	

	// Process Functions & Data Members
	CString	GetErrorMessage();
	CString m_csErrorMessage;

	int		m_nState;
	int		GetState();
	void	SetState(int nState);
	

	CString GetCurrentSerialNumber();
	void	SetCurrentSerialNumber(CString csCurrentSerialNumber);
	void	CheckMaxAndRollOverValues(int nCount, CString csSerialNumber);
	CString	GetScannedLabel();
	void	SetScannedLabel(CString csScannedLabel);
	int	RePrintLabel();
	int GetMaxRescans();
	int GetMaxRePrints();
	int GetTemplatesPerUnit();
	int GetDataFactories();


private:
	CLMorphor3	*m_pLMorphor3;
//	JobInfo		*m_pJobInfo;
	CString		m_csTemplate;
	CString		m_csJobName;
	CString		m_csCurrentSerialNumber;
	CString		m_csPreviousSerialNumber;
	CXMLFile	*m_pXML;
	CJoTSDoc	*m_pDoc;
	JobInfo		*m_pJobInfo;
	CString		m_csCurrentTemplate;
	CString		m_csLastPrintedLabel;
	NumberBases m_udfNumberBases[MAXNUMBERBASES];
	BOOL		m_blnUseNewSerialNumber;
	Scanner		*m_pScannerInfo;
	CRunDlg		*m_pRunDlg;
	int			m_nMaxLabels;
	int			m_nPrinterTimeOut;
	int			m_nScannerTimeOut;
	int			m_nMaxItems;
	int			m_nLabelsCount;
	int			m_nLabelsPerUnit;
	int			m_nJobLabelCount;
	CString		m_csStepSize;
	CString		m_csScannedLabel;


};


#endif