// AddJobStep6.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep6.h"
#include "PropertyEx.h"
#include "ZebraZPL.h"
#include "Utilities.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep6 property page

IMPLEMENT_DYNCREATE(CAddJobStep6, CPropertyPage)

CAddJobStep6::CAddJobStep6() : CPropertyPage(CAddJobStep6::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep6)
	m_nTemplateCount=0;
	m_csTemplateName = _T("");
	//}}AFX_DATA_INIT
}

CAddJobStep6::~CAddJobStep6()
{
	m_Grid.DeleteAllItems(); 
}

void CAddJobStep6::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep6)
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	DDX_Text(pDX, IDC_LBL_TEMPLATE_PATH, m_csTemplateName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep6, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep6)
    ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep6 message handlers

BOOL CAddJobStep6::OnSetActive() 
{
CString csTemp;


	CPropertyEx* parent = (CPropertyEx*)GetParent();

    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);

	m_csTemplateName=m_csaTemplatesProcessed.GetAt(m_nTemplateCount);
	GetBCTemplateInfo(parent->GetTemplatePath()+m_csTemplateName);
	InitGrid();
	
	parent->m_nBarCodePageID=parent->GetPageIndex(this); 
	return CPropertyPage::OnSetActive();
}

void CAddJobStep6::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
//    CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(1,3);
//	csData=pCell->GetText(); 	   	 

}


BOOL CAddJobStep6::OnInitDialog() 
{

	CPropertyPage::OnInitDialog();
	
	PreProcessTemplates();


//	GetBCTemplateInfo();
	InitGrid();
	InitControls();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAddJobStep6::PreProcessTemplates()
{
BOOL blnFirstTime=TRUE,
	 blnDuplicateFound=FALSE;	
int nCount=0,
	nInsideCount=0;	
CString csBuffer;
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	
	for (nCount=0;nCount<parent->m_nNumberOfLabels;nCount++)
	{
		blnDuplicateFound=FALSE;
		if (blnFirstTime)
		{
			m_csaTemplatesProcessed.Add(parent->LabelData[nCount].TemplateName); 
			blnFirstTime=FALSE;
		}
		else
		{	
			// Process only uniquely named Templates
			csBuffer=parent->LabelData[nCount].TemplateName;
			for(nInsideCount=0;nInsideCount<m_csaTemplatesProcessed.GetSize();nInsideCount++)
			{
				if (csBuffer==m_csaTemplatesProcessed.GetAt(nInsideCount))
				{
					blnDuplicateFound=TRUE;
					break;
				}

			}
			if (!blnDuplicateFound)
			{

				m_csaTemplatesProcessed.Add(parent->LabelData[nCount].TemplateName); 
			}
		}
	}
	

}

void CAddJobStep6::GetBCTemplateInfo(CString csTemplateName) 
{
CUtilities oUtil;
CZebraZPL ZebraPrinter;
int nNumberOfBarCodeVars=0;
int nCount=0;
	
	m_csBCVars.RemoveAll(); 

	if (oUtil.IsStringEmpty("Job Wizard Step 6",csTemplateName,"Printer Template Not Defined")) return;  
	ZebraPrinter.ReadTemplate(csTemplateName);
	ZebraPrinter.ScanForVars(); 
	m_nNumberOfBC_vars=ZebraPrinter.GetCountOfBarCodeVars();
	
	for (nCount=0;nCount<m_nNumberOfBC_vars;nCount++)
	{
		m_csBCVars.Add(ZebraPrinter.GetBCVar(nCount)); 

	}
	UpdateData(FALSE);
}


void CAddJobStep6::InitGrid() 
{
CStringArray options;
int	nCount,
	nMaxCount;

	CPropertyEx* parent = (CPropertyEx*)GetParent();
	nMaxCount = parent->m_csaDataDefinition.GetSize();
	
	if (nMaxCount==-1)
	{
		AfxMessageBox("Warning: Error In Data Definition");

	}
	UpdateData(FALSE);


	m_Grid.DeleteAllItems(); 
	
	m_Grid.SetRowCount(10);
	m_Grid.SetColumnCount(4);
	m_Grid.SetFixedRowCount(1);
	m_Grid.SetFixedColumnCount(1);

    m_Grid.SetItemText(0,0,"Var Name");
    m_Grid.SetItemText(0,1,"Prefix");
	
    m_Grid.SetItemText(0,2,"Suffix");
    m_Grid.SetItemText(0,3,"Data");
	
	m_Grid.SetColumnWidth(0,75);
	m_Grid.SetColumnWidth(1,75);
	m_Grid.SetColumnWidth(2,75);
	m_Grid.SetColumnWidth(3,100);

	m_Grid.SetItemFormat(0,0,DT_CENTER);
	m_Grid.SetItemFormat(0,1,DT_CENTER);
	m_Grid.SetItemFormat(0,2,DT_CENTER);
	m_Grid.SetItemFormat(0,3,DT_CENTER);


	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);

	
	for (int nID=0;nID<m_nNumberOfBC_vars;nID++)
	{
		m_Grid.SetRowHeight(nID,20); 
		m_Grid.SetItemFormat(nID+1,0,DT_CENTER);
		m_Grid.SetItemText(nID+1,0,m_csBCVars.GetAt(nID));


		if (nMaxCount>1)	// No need for a combo if only one data definition
		{
			if (!m_Grid.SetCellType(nID+1,3, RUNTIME_CLASS(CGridCellCombo)))
				return;

			options.RemoveAll();
			
			for (nCount=0;nCount<nMaxCount;nCount++)
			{			
				
				
				
				options.Add( _T(parent->m_csaDataDefinition.GetAt(nCount)));
							
				CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(nID+1,3);
				pCell->SetOptions(options);
				pCell->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


			}
		}
		m_Grid.SetItemText(nID+1,3, _T(parent->m_csaDataDefinition.GetAt(0)));

	}
	m_Grid.ExpandColumnsToFit(TRUE); 
}




LRESULT CAddJobStep6::OnWizardNext() 
{
 	if (!VerifyData())
		return -1;
	
	PopulateTemplateDataIntoJobRecord();


	
	if (m_nTemplateCount<(m_csaTemplatesProcessed.GetSize()-1))
	{
		
		m_nTemplateCount++;
		return IDD_ADDJOB_STEP6;

	}
	


	return CPropertyPage::OnWizardNext();
}

BOOL CAddJobStep6::VerifyData() 
{

	return TRUE;
}
void CAddJobStep6::PopulateTemplateDataIntoJobRecord()
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	parent->Templates[m_nTemplateCount].Name = m_csaTemplatesProcessed.GetAt(m_nTemplateCount);
		

	for (int nID=0;nID<m_nNumberOfBC_vars;nID++)
	{

		parent->Templates[m_nTemplateCount].BCVars[nID].Name   = m_Grid.GetItemText(m_Grid.GetFixedRowCount()+nID,0);  	
		parent->Templates[m_nTemplateCount].BCVars[nID].Prefix    = m_Grid.GetItemText(m_Grid.GetFixedRowCount()+nID,1);  	
		parent->Templates[m_nTemplateCount].BCVars[nID].Suffix    = m_Grid.GetItemText(m_Grid.GetFixedRowCount()+nID,2);  	
		parent->Templates[m_nTemplateCount].BCVars[nID].Data   = m_Grid.GetItemText(m_Grid.GetFixedRowCount()+nID,3);  	
	}


}


void CAddJobStep6::InitControls()
{
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 

	// format label controls
	GetDlgItem(IDC_LBL_TITLE)->SetFont(&font);
	GetDlgItem(IDC_LBL_TEMPLATE_NAME)->SetFont(&font);
	GetDlgItem(IDC_LBL_TEMPLATE_PATH)->SetFont(&font);



}
