// ConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "ConfigDlg.h"
#include "Utilities.h"
#include "GetDirectoryDlg.h"
#include "UserAccountDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog

#define	  CONFIGNAME			0
#define	  CONFIGVALUE			1	
#define   CONFIGDESCRIPTION		2

#define	  PRINTER_ROW_TIMEROUT	1
#define	  SCANNER_ROW_TIMEROUT	2
#define   MORPHOR_ROW_TIMEROUT	3
#define	  ZEBRA_TEMPLATES		4
#define	  MORPHORCOMM			5
#define	  PROMPT_LABELQTY		6
#define	  SECURITY_ENABLE		7
#define	  PRESCANDELAY			8
#define	  POSTSCANDELAY			9


#include "GridBtnCell_src\GridBtnCell.h"
#include "GridBtnCell_src\GridBtnCellCombo.h"

typedef struct
{
    CGridBtnCellBase::STRUCT_DRAWCTL DrawCtl;  // most btn props here
    int iBtnNbr;                        // which btn within cell does this define?
    const char* pszBtnText;             // text associated with pushbutton or NULL
}   STRUCT_CTL;

// This macro evaluates to the number of elements in an array -- from Jeff Richter
#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))


CConfigDlg::CConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigDlg::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}
CConfigDlg::~CConfigDlg()
{
	m_Grid.DeleteAllItems(); 

}

void CConfigDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_LBL_SETTINGS, m_lblTitle);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CConfigDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CConfigDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CConfigDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IConfigDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {385B0F19-A1BF-40B4-A321-43A799C79D1B}
static const IID IID_IConfigDlg =
{ 0x385b0f19, 0xa1bf, 0x40b4, { 0xa3, 0x21, 0x43, 0xa7, 0x99, 0xc7, 0x9d, 0x1b } };

BEGIN_INTERFACE_MAP(CConfigDlg, CDialog)
	INTERFACE_PART(CConfigDlg, IID_IConfigDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg message handlers


void CConfigDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;


	CString strMsg;

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;


    if( nRow < m_Grid.GetFixedRowCount() )
        return;

    CGridBtnCell* pGridBtnCell=NULL;
    CGridBtnCellCombo* pGridBtnCellCombo=NULL;




    // 3/2001:  I don't ASSERT(FALSE) if the button type is unexpected
    //          this is to support addition to test app of inserted
    //          tree branches that don't have button cells
    switch( nRow)
    {
 



        case  ZEBRA_TEMPLATES:  // btn + combo
            pGridBtnCell = (CGridBtnCell*)m_Grid.GetCell( nRow, CONFIGVALUE);
            if( pGridBtnCell)
            {
                if( !pGridBtnCell->IsKindOf( RUNTIME_CLASS(CGridBtnCell) ) )
                {
                    return;
                }


                if( pGridBtnCell->GetLastCtlClicked() == 0)
                {
				
					CGetDirectoryDlg *pDia = new CGetDirectoryDlg();
					
					if(pDia->DoModal()==IDOK)
					{	
						CString csTemp=pDia->GetDirectory();
						if (!csTemp.IsEmpty())
							m_Grid.SetItemText(ZEBRA_TEMPLATES,CONFIGVALUE,csTemp+"\\");
					}

					m_Grid.RedrawCell( nRow, nCol);
                    
                }
            }
			break;
         case  SECURITY_ENABLE:  
 
				CUserAccountDlg *pDlg = new CUserAccountDlg();
				pDlg->DoModal();
				delete pDlg;
				m_Grid.RedrawCell( nRow, nCol);
                    
               break;
       
    }


    

}

void CConfigDlg::InitGrid() 
{
CStringArray options,
			 csaTemplates;
CUtilities *pUtil;
CString csCount;
CStringArray strAryCombo;

	m_Grid.SetFixedRowCount(1);
	m_Grid.SetRowCount(MAXCONPARAMETERS + m_Grid.GetFixedRowCount());		//Data Rows

	m_Grid.SetColumnCount(2);
	m_Grid.SetFixedColumnCount(1);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE); 



   // will create some cells with btns, below
    m_BtnDataBase.SetGrid( &m_Grid);

    m_Grid.SetItemText(0,CONFIGNAME,"          Name   ");
    m_Grid.SetItemText(0,CONFIGVALUE,"Value");
	
    int iComboCtlWidth = GetSystemMetrics( SM_CXVSCROLL);


	
	pUtil = new CUtilities();

	// Printer Time Out
	strAryCombo.RemoveAll();
	for (int nCount=1;nCount<=10;nCount++)
	{
		csCount.Format("%d",nCount);
		strAryCombo.Add(csCount);
	}	
	for (nCount=1;nCount<5;nCount++)
	{
		csCount.Format("%d",10+nCount*5);
		strAryCombo.Add(csCount);
	}	

	m_Grid.SetItemText(PRINTER_ROW_TIMEROUT,CONFIGNAME,"Printer Time Out");

	if (!m_Grid.SetCellType(PRINTER_ROW_TIMEROUT,CONFIGVALUE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(PRINTER_ROW_TIMEROUT,CONFIGVALUE);

	pCell->SetOptions(strAryCombo);
	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	m_Grid.SetItemText(PRINTER_ROW_TIMEROUT,CONFIGVALUE,pUtil->GetConfigValue(PRINT_TIMEOUT));






	// Scanner Time Out
	strAryCombo.RemoveAll();
	for (nCount=1;nCount<=10;nCount++)
	{
		csCount.Format("%d",nCount);
		strAryCombo.Add(csCount);
	}	
	for (nCount=1;nCount<5;nCount++)
	{
		csCount.Format("%d",10+nCount*5);
		strAryCombo.Add(csCount);
	}	
	
	m_Grid.SetItemText(SCANNER_ROW_TIMEROUT,CONFIGNAME,"Scanner Time Out");
	if (!m_Grid.SetCellType(SCANNER_ROW_TIMEROUT,CONFIGVALUE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(SCANNER_ROW_TIMEROUT,CONFIGVALUE);

	pCell->SetOptions(strAryCombo);
	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	m_Grid.SetItemText(SCANNER_ROW_TIMEROUT,CONFIGVALUE,pUtil->GetConfigValue(SCANNER_TIMEOUT));
	

	// Morphor Time Out
	strAryCombo.RemoveAll();
	for (nCount=1;nCount<=10;nCount++)
	{
		csCount.Format("%d",nCount);
		strAryCombo.Add(csCount);
	}	
	for (nCount=1;nCount<5;nCount++)
	{
		csCount.Format("%d",10+nCount*5);
		strAryCombo.Add(csCount);
	}	

	m_Grid.SetItemText(MORPHOR_ROW_TIMEROUT,CONFIGNAME,"Morphor Time Out");

	if (!m_Grid.SetCellType(MORPHOR_ROW_TIMEROUT,CONFIGVALUE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(MORPHOR_ROW_TIMEROUT,CONFIGVALUE);

	pCell->SetOptions(strAryCombo);
	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	m_Grid.SetItemText(MORPHOR_ROW_TIMEROUT,CONFIGVALUE,pUtil->GetConfigValue(MORPHOR_TIMEOUT));

		
	// Zebra Templates
	strAryCombo.RemoveAll();
	m_Grid.SetItemText(ZEBRA_TEMPLATES,CONFIGNAME,"Templates Folder");
   
    strAryCombo.Add( pUtil->GetConfigValue(ZEBRATEMPLATES));
	SetUpComboBtns(ZEBRA_TEMPLATES,CONFIGVALUE, strAryCombo);





		// Morphor Connection Type
	strAryCombo.RemoveAll();
	strAryCombo.Add(_T("TCP"));
	strAryCombo.Add(_T("Serial"));

	m_Grid.SetItemText(MORPHORCOMM,CONFIGNAME,"Morphor Communication");

	
	if (!m_Grid.SetCellType(MORPHORCOMM,CONFIGVALUE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(MORPHORCOMM,CONFIGVALUE);

	pCell->SetOptions(strAryCombo);
	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	m_Grid.SetItemText(MORPHORCOMM,CONFIGVALUE,pUtil->GetConfigValue(MORPHOR_COMM_TYPE));


	
	// Prompt The User To Enter User Qty
	strAryCombo.RemoveAll();
	strAryCombo.Add(_T("Yes"));
	strAryCombo.Add(_T("No"));
	

	m_Grid.SetItemText(PROMPT_LABELQTY,CONFIGNAME,"Prompt For Label Quantity");
	if (!m_Grid.SetCellType(PROMPT_LABELQTY,CONFIGVALUE, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(PROMPT_LABELQTY,CONFIGVALUE);

	pCell->SetOptions(strAryCombo);
	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	m_Grid.SetItemText(PROMPT_LABELQTY,CONFIGVALUE,pUtil->GetConfigValue(PROMPT_FOR_QTY));


	for (nCount =0;nCount<m_Grid.GetRowCount() ; nCount++)
	{
		for (int nColumn=1;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			m_Grid.SetItemFormat(nCount,nColumn,DT_LEFT|DT_VCENTER|DT_NOPREFIX );
		}
		m_Grid.SetRowHeight(nCount,25); 
	}


		// Zebra Templates
	strAryCombo.RemoveAll();
	m_Grid.SetItemText(SECURITY_ENABLE,CONFIGNAME,"Security");
   
//   	SetUpGridBtn(SECURITY_ENABLE,CONFIGVALUE);

	m_Grid.Refresh(); 
	m_Grid.ExpandColumnsToFit(TRUE); 

 	SetUpGridBtn(SECURITY_ENABLE,CONFIGVALUE);	
	

	m_Grid.SetItemText(PRESCANDELAY,CONFIGNAME,"Pre Scan Delay (milliseconds)");
	m_Grid.SetItemText(POSTSCANDELAY,CONFIGNAME,"Post Scan Delay (milliseconds)");
	
	
	
	m_Grid.SetItemText(PRESCANDELAY,CONFIGVALUE,pUtil->GetConfigValue(SCANPREDELAY));
	m_Grid.SetItemText(POSTSCANDELAY,CONFIGVALUE,pUtil->GetConfigValue(SCANPOSTDELAY));


	delete pUtil;

	

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);
	m_Grid.SetModified(FALSE); 

	

}



void CConfigDlg::SetUpComboBtns(int nRow, int nCol, CStringArray &csaArray)
{
int i1;
int iComboCtlWidth = (int)(GetSystemMetrics( SM_CXVSCROLL)*1.25);
	 
	
	STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        { -1,  DFCS_BUTTONPUSH, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_BUTTON, 0, "..."},// combo w/ btn...
//        { -1,  DFCS_SCROLLDOWN, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 1, NULL},
    };  // (-1 iWidth's will be filled-in later)


          // retain old cell properties
    CGridBtnCell GridCellCopy;       
	GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
	CGridCellBase* pCurrCell = m_Grid.GetCell( nRow, nCol);
	if (pCurrCell)
	GridCellCopy = *pCurrCell;

	m_Grid.SetCellType( nRow, nCol, RUNTIME_CLASS(CGridBtnCell) );


	CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_Grid.GetCell( nRow, nCol);
//	pGridBtnCell->SetComboStyle( CBS_DROPDOWNLIST);
//	pGridBtnCell->SetComboString( csaArray);

//	CGridBtnCell*  pGridBtnCell = (CGridBtnCell*)m_Grid.GetCell( nRow, nCol);
	pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);


	for (i1=0;i1<1;i1++)
	{
		int iWidth = DrawCtlAry[ i1].DrawCtl.iWidth;
		if( iWidth < 0) iWidth = iComboCtlWidth;


		pGridBtnCell->SetupBtns(
			DrawCtlAry[ i1].iBtnNbr,        // zero-based index of image to draw
			DrawCtlAry[ i1].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
			DrawCtlAry[ i1].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
			(CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ i1].DrawCtl.ucAlign,
											// horizontal alignment of control image
			iWidth,                         // fixed width of control or 0 for size-to-fit
			DrawCtlAry[ i1].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
			DrawCtlAry[ i1].pszBtnText );   // Text to insert centered in button; if NULL no text

	}
//	pCurrCell->SetText(csaArray.GetAt(0));
	m_Grid.SetItemText(nRow,nCol,csaArray.GetAt(0));
}

void CConfigDlg::SetUpGridBtn(int nRow, int nCol)
{
int i1;
int iComboCtlWidth = m_Grid.GetColumnWidth(nCol);
	 
	
	STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        { -1,  DFCS_BUTTONPUSH, FALSE, CGridBtnCellBase::CTL_ALIGN_CENTER, DFC_BUTTON, 0, "Security"},// combo w/ btn...
//        { -1,  DFCS_SCROLLDOWN, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 1, NULL},
    };  // (-1 iWidth's will be filled-in later)


          // retain old cell properties
    CGridBtnCell GridCellCopy;       
	GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
	CGridCellBase* pCurrCell = m_Grid.GetCell( nRow, nCol);
	if (pCurrCell)
	GridCellCopy = *pCurrCell;

	m_Grid.SetCellType( nRow, nCol, RUNTIME_CLASS(CGridBtnCell) );


	CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_Grid.GetCell( nRow, nCol);

	pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);


	for (i1=0;i1<1;i1++)
	{
		int iWidth = DrawCtlAry[ i1].DrawCtl.iWidth;
		if( iWidth < 0) iWidth = iComboCtlWidth;


		pGridBtnCell->SetupBtns(
			DrawCtlAry[ i1].iBtnNbr,        // zero-based index of image to draw
			DrawCtlAry[ i1].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
			DrawCtlAry[ i1].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
			(CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ i1].DrawCtl.ucAlign,
											// horizontal alignment of control image
			iWidth,                         // fixed width of control or 0 for size-to-fit
			DrawCtlAry[ i1].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
			DrawCtlAry[ i1].pszBtnText );   // Text to insert centered in button; if NULL no text

	}
//	pCurrCell->SetText(csaArray.GetAt(0));
//	m_Grid.SetItemText(nRow,nCol,"Security");
}



void CConfigDlg::SetUpScrollButton(int nRow, int nCol)
{
int i1;
int iComboCtlWidth = GetSystemMetrics( SM_CXVSCROLL);
	 
	
	STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        { -1,  DFCS_SCROLLUP,   FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 0, NULL}, // spin box...
        { -1,  DFCS_SCROLLDOWN, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 1, NULL},
    };  // (-1 iWidth's will be filled-in later)


      // retain old cell properties
    CGridBtnCell GridCellCopy;
    GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
    CGridCellBase* pCurrCell = m_Grid.GetCell( nRow, nCol);
    if (pCurrCell)
        GridCellCopy = *pCurrCell;
			
	int nMargin=pCurrCell->GetMargin();
	
	m_Grid.SetCellType( nRow, nCol, RUNTIME_CLASS(CGridBtnCell) );

//	m_Grid.SetVirtualMode(TRUE);
	CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_Grid.GetCell( nRow, nCol);
    pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);


	
	
	for (i1=0;i1<2;i1++)
	{
		int iWidth = DrawCtlAry[ i1].DrawCtl.iWidth;
		if( iWidth < 0) iWidth = iComboCtlWidth;


		pGridBtnCell->SetupBtns(
			DrawCtlAry[ i1].iBtnNbr,        // zero-based index of image to draw
			DrawCtlAry[ i1].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
			DrawCtlAry[ i1].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
			(CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ i1].DrawCtl.ucAlign,
											// horizontal alignment of control image
			iWidth,                         // fixed width of control or 0 for size-to-fit
			DrawCtlAry[ i1].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
			DrawCtlAry[ i1].pszBtnText );   // Text to insert centered in button; if NULL no text

	}




}

BOOL CConfigDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitGrid();	
	InitControls();	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CConfigDlg::InitControls()
{

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format label controls
	
	m_lblTitle.SetFont(&font); 



	// format btn controls
	
	m_btnOK.SetFont(&font);
	m_btnOK.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnOK.SetIcon(IDI_OK);
	m_btnOK.SetAlign(CButtonST::ST_ALIGN_HORIZ);

	m_btnCancel.SetFont(&font);
	m_btnCancel.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnCancel.SetIcon(IDI_CANCEL1);
	m_btnCancel.SetAlign(CButtonST::ST_ALIGN_HORIZ);

}

void CConfigDlg::OnOK() 
{
CString csTemp;
		CUtilities *pUtil = new CUtilities();
	
	if(IsModified(PRINTER_ROW_TIMEROUT))
	{
		csTemp=m_Grid.GetItemText(PRINTER_ROW_TIMEROUT,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(PRINT_TIMEOUT,csTemp); 
	}


	if(IsModified(SCANNER_ROW_TIMEROUT))
	{
		csTemp=m_Grid.GetItemText(SCANNER_ROW_TIMEROUT,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(SCANNER_TIMEOUT,csTemp); 
	}


	if(IsModified(ZEBRA_TEMPLATES))
	{
		csTemp=m_Grid.GetItemText(ZEBRA_TEMPLATES,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(ZEBRATEMPLATES,csTemp); 
	}

	if(IsModified(MORPHOR_ROW_TIMEROUT))
	{
		csTemp=m_Grid.GetItemText(MORPHOR_ROW_TIMEROUT,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(MORPHOR_TIMEOUT,csTemp); 
	}

	if(IsModified(MORPHORCOMM))
	{
		csTemp=m_Grid.GetItemText(MORPHORCOMM,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(MORPHOR_COMM_TYPE,csTemp); 
	}


	if(IsModified(PROMPT_LABELQTY))
	{
		csTemp=m_Grid.GetItemText(PROMPT_LABELQTY,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(PROMPT_FOR_QTY,csTemp); 
	}

	if(IsModified(PRESCANDELAY))
	{
		csTemp=m_Grid.GetItemText(PRESCANDELAY,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(SCANPREDELAY,csTemp); 
	}


	if(IsModified(PRESCANDELAY))
	{
		csTemp=m_Grid.GetItemText(PRESCANDELAY,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(SCANPREDELAY,csTemp); 
	}



	if(IsModified(POSTSCANDELAY))
	{
		csTemp=m_Grid.GetItemText(POSTSCANDELAY,CONFIGVALUE);
		if (!csTemp.IsEmpty()) 
			pUtil->SetConfigValue(SCANPOSTDELAY,csTemp); 
	}


	
	delete pUtil;

	CDialog::OnOK();
}


BOOL CConfigDlg::IsModified(int nRow)
{
CString csTemp;

	CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nRow,CONFIGVALUE);


	if (pCell->IsModified())
		return TRUE;
	if( pCell->IsSelected() )
	{
		pCell->EndEdit();
		if (pCell->IsModified())
			return TRUE;
	}
	return FALSE;
}