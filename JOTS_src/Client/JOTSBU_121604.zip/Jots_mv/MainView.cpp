// MainView.cpp : Implementation of CMainView
#include "stdafx.h"
#include "JoTS.h"
#include "MainView.h"

/////////////////////////////////////////////////////////////////////////////
// CMainView

