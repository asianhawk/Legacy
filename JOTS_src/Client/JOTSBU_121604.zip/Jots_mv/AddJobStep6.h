#if !defined(AFX_ADDJOBSTEP6_H__AB911B4B_7BD4_4B1C_B53A_088DED437B3F__INCLUDED_)
#define AFX_ADDJOBSTEP6_H__AB911B4B_7BD4_4B1C_B53A_088DED437B3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep6.h : header file
//

#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"


/////////////////////////////////////////////////////////////////////////////
// CAddJobStep6 dialog

class CAddJobStep6 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep6)

// Construction
public:
	CAddJobStep6();
	~CAddJobStep6();
	CGridCtrl m_Grid;
	void InitGrid();
	void GetBCTemplateInfo(CString csTemplateName);
	int	 m_nNumberOfBC_vars;
	CStringArray m_csBCVars;
	BOOL VerifyData(); 

	int m_nTemplateCount;
	CStringArray m_csaTemplatesProcessed;
	void PreProcessTemplates();
	void PopulateTemplateDataIntoJobRecord();


// Dialog Data
	//{{AFX_DATA(CAddJobStep6)
	enum { IDD = IDD_ADDJOB_STEP6 };
	CString	m_csTemplateName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep6)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep6)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void	InitControls();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP6_H__AB911B4B_7BD4_4B1C_B53A_088DED437B3F__INCLUDED_)
