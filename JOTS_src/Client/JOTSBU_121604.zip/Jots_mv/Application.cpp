// Application.cpp : Implementation of CApplication
#include "stdafx.h"
#include "JoTS.h"
#include "Application.h"

/////////////////////////////////////////////////////////////////////////////
// CApplication

