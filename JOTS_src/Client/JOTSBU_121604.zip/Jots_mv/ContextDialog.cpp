// ContextDialog.cpp : implementation file
//
#include "stdafx.h"
#include "CShelp.h"
#include "ContextDialog.h"
#include <HtmlHelp.h>
#include <io.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContextDialog dialog


CContextDialog::CContextDialog(UINT idd, CWnd* pParent /*=NULL*/)
	: CDialog(idd, pParent)
{
	//{{AFX_DATA_INIT(CContextDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pContextParent = pParent;
	m_iContextID = idd;
	m_strChmName.Empty();
}

void CContextDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CContextDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CContextDialog, CDialog)
	//{{AFX_MSG_MAP(CContextDialog)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_HELP, OnHelpInfo)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContextDialog message handlers


BOOL CContextDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(!m_strChmName.IsEmpty()){

		// Searching if the chm file exists
		if(_taccess(m_strChmName.GetBuffer(1), 00)){
			m_strChmName.Empty();
			return TRUE;
		}

		// the file exists, so we can modify the style of the dialog box
		LONG style = ::GetWindowLong(m_hWnd, GWL_EXSTYLE);
		style |= WS_EX_CONTEXTHELP;
		::SetWindowLong(m_hWnd, GWL_EXSTYLE, style);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


BOOL CContextDialog::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	if(m_strChmName.IsEmpty())
		return CDialog::OnHelpInfo(pHelpInfo);

	if(pHelpInfo->iContextType != HELPINFO_WINDOW)
		return FALSE;

	HH_POPUP popupStruct;
	CString strHelpText((LPCTSTR) IDS_NO_HELP_TOPIC);

	BOOL bStandard = ((pHelpInfo->iCtrlId == IDOK) || 
		(pHelpInfo->iCtrlId == IDCANCEL));

	if(pHelpInfo->iCtrlId == -1){
		// search if there is a control under the mouse cursor
		CPoint mousePoint(pHelpInfo->MousePos);
		int nControlID = -1;
		CWnd *pWnd = GetWindow(GW_CHILD);
		while(pWnd){
			int nID = ::GetDlgCtrlID(pWnd->GetSafeHwnd());
			if ((nID != -1) && (nID != 65535)){
				CRect windowRect;

				pWnd->GetWindowRect(&windowRect);
				if(windowRect.PtInRect(mousePoint)){
					nControlID = nID;
					break;
				}
			}
			pWnd = pWnd->GetWindow(GW_HWNDNEXT);
		}
		pHelpInfo->iCtrlId = nControlID;
		if(pHelpInfo->iCtrlId == -1)
			return FALSE;
	}

	if(!pHelpInfo->iCtrlId)
		return FALSE;

	// Build the contextual help identifier by combination of the dialog ID 
	// and of the Control ID. The 3standard" case avoids to multiply the 
	// descriptions for button "Ok" and "Cancel"

	UINT iContextId = bStandard ? pHelpInfo->iCtrlId : MAKELPARAM(pHelpInfo->iCtrlId, m_iContextID);

	popupStruct.hinst = NULL;
	popupStruct.idString = iContextId;
	popupStruct.pt.x = pHelpInfo->MousePos.x;
	popupStruct.pt.y = pHelpInfo->MousePos.y;
	popupStruct.clrForeground = (COLORREF)-1;
	popupStruct.clrBackground = (COLORREF)-1;
	popupStruct.rcMargins = CRect(-1, -1, -1, -1);
	popupStruct.pszFont  = NULL;
	popupStruct.pszText = strHelpText.GetBuffer(1);
	popupStruct.cbStruct = sizeof(popupStruct);

	CString strHelpString = m_strChmName + _T("::/cshelp.txt"); 
	// Display the popup using HtmlHelp API
	HWND popupHwnd = HtmlHelp(m_pContextParent->GetSafeHwnd(), strHelpString.GetBuffer(1), 
		HH_DISPLAY_TEXT_POPUP, (DWORD) &popupStruct);
	return (popupHwnd != NULL);
}