#if !defined(AFX_JOBWIZARD_H__2374AAE8_2D6A_45E1_B389_0E7E667BED24__INCLUDED_)
#define AFX_JOBWIZARD_H__2374AAE8_2D6A_45E1_B389_0E7E667BED24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// JobWizard.h : header file
//

// Headers for add job wizard
#include "PropertyEx.h"

#include "AddJobStep1.h"
#include "AddJobStep2.h"
#include "DefineNumOfIndexesPge.h"
#include "AddJobStep3.h"
#include "AddJobStep4.h"
#include "AddJobStep5.h"
#include "AddJobStep6.h"
#include "AddJobStep7.h"
#include "FinishPage.h"



/////////////////////////////////////////////////////////////////////////////
// CJobWizard window

class CJobWizard 
{
// Construction
public:
	CJobWizard();

// Attributes
public:

// Operations
public:

	void CreateNewJob();
	void BuildPage2DataStruct(CAddJobStep2 *pDlg);
	JobInfo m_udfJobInfo;

	void BuildPage2aDataStruct(CDefineNumOfIndexesPge *pDlg);
	void BuildDataSeries(CPropertyEx  *dlg);
	void BuildLabelSeries(CPropertyEx *dlg);
	void BuildJobTemplates(CPropertyEx *dlg);
	CString	GetJobName();
	void	SetJobName(CString csJobName);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJobWizard)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJobWizard();

	// Generated message map functions
protected:

private:
	CString		m_csJobName;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOBWIZARD_H__2374AAE8_2D6A_45E1_B389_0E7E667BED24__INCLUDED_)
