// AddJobStep4.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep4.h"
#include "PropertyEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep4 property page

IMPLEMENT_DYNCREATE(CAddJobStep4, CPropertyPage)

CAddJobStep4::CAddJobStep4() : CPropertyPage(CAddJobStep4::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep4)
	m_blnUTemplate = FALSE;
	//}}AFX_DATA_INIT
}

CAddJobStep4::~CAddJobStep4()
{
}

void CAddJobStep4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep4)
	DDX_Check(pDX, IDC_CHK_UTEMPLATE, m_blnUTemplate);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep4, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep4 message handlers

BOOL CAddJobStep4::OnSetActive() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	InitControls();


	return CPropertyPage::OnSetActive();
}

LRESULT CAddJobStep4::OnWizardNext() 
{

	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	
	UpdateData(TRUE);

	if (m_blnUTemplate||(parent->m_nNumberOfLabels<=1) )
	{
			
		parent->m_blnUniqueTemplates=TRUE;
	}
	else
	{
		parent->m_blnUniqueTemplates=FALSE;
	}
	
	return CPropertyPage::OnWizardNext();
}


void CAddJobStep4::InitControls()
{
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format label controls
	GetDlgItem(IDC_LBL_NUMBER_OF_LABELS)->SetFont(&font);
	GetDlgItem(IDC_CHK_UTEMPLATE)->SetFont(&font);

}

BOOL CAddJobStep4::OnInitDialog() 
{
int nNumOfLabels;
	CPropertyPage::OnInitDialog();
	
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	
	nNumOfLabels=parent->m_nNumberOfLabels;

	if (nNumOfLabels>1)
	{
		GetDlgItem(IDC_CHK_UTEMPLATE)->SetWindowText("Use The Same template For Each Label Y/N?");

	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
