// MorphorProtocol.cpp : implementation file
//

#include "stdafx.h"
//#include "jots.h"
#include "MorphorProtocol.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMorphorProtocol

CMorphorProtocol::CMorphorProtocol()
{
}

CMorphorProtocol::~CMorphorProtocol()
{
}



/////////////////////////////////////////////////////////////////////////////
// CMorphorProtocol message handlers

CString CMorphorProtocol::HostInquiry()
{

	return LM3INQUIRY;
}

CString CMorphorProtocol::HostInquiry(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return LM3INQUIRY;

}

CString CMorphorProtocol::PrintAndApply()
{
CString csReturn;
	csReturn = PRINTANDAPPLY + CString(",N,");
	return csReturn;

}


CString CMorphorProtocol::PrintAndApply(CString *csExpectedResponse)
{
CString csReturn;

	*csExpectedResponse = "OK";
	csReturn = PRINTANDAPPLY + CString(",Y,");
	return csReturn;

}



CString CMorphorProtocol::Version()
{
	return LM3VERSION;

}

CString CMorphorProtocol::Version(CString *csExpectedResponse)
{
	*csExpectedResponse = "String";
	return LM3VERSION;

}

CString CMorphorProtocol::GetDeviceConfig()
{
	return LM3CONFIG;

}
CString CMorphorProtocol::GetDeviceConfig(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return LM3CONFIG;

}

CString CMorphorProtocol::Reset()
{
	return LM3RESET;

}

CString CMorphorProtocol::Reset(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return LM3RESET;

}
CString CMorphorProtocol::ActivatePassThruMode()
{
	return LM3PASSTHRU;

}
CString CMorphorProtocol::ActivatePassThruMode(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return LM3PASSTHRU;

}
CString CMorphorProtocol::DeActivatePassThruMode()
{
	return ABORTPASSTHRU;

}

CString CMorphorProtocol::DeActivatePassThruMode(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return ABORTPASSTHRU;

}	

CString CMorphorProtocol::ReadScanner()
{
	return READFROMSCSANNER;

}
CString CMorphorProtocol::ReadScanner(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return READFROMSCSANNER;

}
CString CMorphorProtocol::GetDigitalInputs()
{
	return DIGITALINPUT;

}
CString CMorphorProtocol::GetDigitalInputs(CString *csDigitalInputs)
{
	return DIGITALINPUT;

}
CString CMorphorProtocol::SetDigitalOutputs(CString csDigitalOutputs)
{
	return DIGITALOUTPUT + csDigitalOutputs;

}
CString CMorphorProtocol::ResetApplicator()
{
	return RESETAPPLICATOR;

}
CString CMorphorProtocol::ResetApplicator(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return RESETAPPLICATOR;

}
CString CMorphorProtocol::PrintStatus()
{

	return PRINTSTATUS;

}
CString CMorphorProtocol::PrintStatus(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return PRINTSTATUS;

}
CString CMorphorProtocol::QueryPrintStatus()
{

	return QPRINTSTATUS;

}
CString CMorphorProtocol::QueryPrintStatus(CString *csExpectedResponse)
{
	*csExpectedResponse = "OK";
	return QPRINTSTATUS;

}

