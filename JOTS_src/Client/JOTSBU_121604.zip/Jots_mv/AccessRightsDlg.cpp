// AccessRightsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AccessRightsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAccessRightsDlg dialog


CAccessRightsDlg::CAccessRightsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAccessRightsDlg::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CAccessRightsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


CAccessRightsDlg::~CAccessRightsDlg()
{
	if (m_Grid)
		m_Grid.DeleteAllItems();
}



void CAccessRightsDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CAccessRightsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAccessRightsDlg)
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAccessRightsDlg, CDialog)
	//{{AFX_MSG_MAP(CAccessRightsDlg)
    ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CAccessRightsDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CAccessRightsDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IAccessRightsDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {B1CF62F4-DAC6-4F72-B1FD-4612AF6A9D25}
static const IID IID_IAccessRightsDlg =
{ 0xb1cf62f4, 0xdac6, 0x4f72, { 0xb1, 0xfd, 0x46, 0x12, 0xaf, 0x6a, 0x9d, 0x25 } };

BEGIN_INTERFACE_MAP(CAccessRightsDlg, CDialog)
	INTERFACE_PART(CAccessRightsDlg, IID_IAccessRightsDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAccessRightsDlg message handlers
void CAccessRightsDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
	CGridCellCheck* pCell = (CGridCellCheck*) m_Grid.GetCell(pItem->iRow,pItem->iColumn);
	
		GV_ITEM Item;

    	Item.mask = GVIF_TEXT;
	    Item.row = pItem->iRow;
		Item.col = pItem->iColumn;


	
	if (pItem->iRow<=1)
		return;
	
	if (pItem->iColumn==0)
		return;

	if(pCell->GetCheck()==1)
	{
		Item.strText = "Yes";
	    Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);
        Item.crFgClr = RGB(0,0,255);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    
        Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
        m_Grid.SetItem(&Item);
		
		

	}
	else
	{

        Item.strText = "No";
        Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);
        Item.crFgClr = RGB(255,0,0);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    
        Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
        m_Grid.SetItem(&Item);
	}
	   	 
}

BOOL CAccessRightsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	InitGrid();
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAccessRightsDlg::InitGrid() 
{
char Buffer[10];
	UpdateData(FALSE);

	m_Grid.SetRowCount(10);
	m_Grid.SetColumnCount(10);
	m_Grid.SetFixedRowCount(2);
	m_Grid.SetFixedColumnCount(1);

    
	m_Grid.SetItemText(1,0,"Level");
    m_Grid.SetItemText(1,1,"Run Jobs");
    m_Grid.SetItemText(1,2,"Edit Menu");
    m_Grid.SetItemText(1,3,"Setup Menu");
    m_Grid.SetItemText(0,4,"  Security");
    m_Grid.SetItemText(1,4,"Configuration");

    m_Grid.SetItemText(0,5,"  Printer");
    m_Grid.SetItemText(1,5,"Configuration");

    m_Grid.SetItemText(0,6,"  Scanner");
    m_Grid.SetItemText(1,6,"Configuration");
   
    m_Grid.SetItemText(0,7,"System File");
    m_Grid.SetItemText(1,7," Location");
	
    m_Grid.SetItemText(0,8," Data");
    m_Grid.SetItemText(1,8,"Sources");

	
	m_Grid.SetItemText(1,9,"Templates");


	GV_ITEM Item;
	for (int nProfileID=2;nProfileID<10;nProfileID++)
	{
		m_Grid.SetItemText(nProfileID,0,_itoa(nProfileID-1,Buffer,10));

	

		for (int nCount=1;nCount<10;nCount++)
		{
			m_Grid.SetItemText(nProfileID,nCount,"No");
			m_Grid.SetCellType(nProfileID,nCount, RUNTIME_CLASS(CGridCellCheck));


    		Item.mask = GVIF_TEXT;
			Item.row = nProfileID;
			Item.col = nCount;

			Item.strText = "No";

			Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);
			Item.crFgClr = RGB(255,0,0);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    
			Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
			m_Grid.SetItem(&Item);



		}
	}
}
