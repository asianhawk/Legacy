// testio.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DIOOutput.h"
#define		ON	1
#define		OFF 0 


void SetOutput(unsigned int nValue, int nState)
{
   switch (nState)
   {
   case ON:
	   SetOutputOn(nValue);

	   break;
   case OFF:
	   SetOutputOff(nValue);
	   break;
   default:
		   break;



   }

}


int main(int argc, char* argv[])
{
int nCnt=0;
unsigned nRes;
	while (nCnt<8)
	{
		SetOutput(nCnt++,1);
		nRes=GetOutputValue();
		printf("Output Value = %d, %02x\n",nRes,nRes);
	}
	nCnt=0;
	while (nCnt<8)
	{
		SetOutput(nCnt++,0);
		nRes=GetOutputValue();
		printf("Output Value = %d, %02x\n",nRes,nRes);
	}

	// begin test 1

	SetOutput(2,ON);
	nRes=GetOutputValue();
	printf("Output Value = %d, %02x\n",nRes,nRes);

	SetOutput(1,ON);
	nRes=GetOutputValue();
	printf("Output Value = %d, %02x\n",nRes,nRes);	

	SetOutput(2,OFF);
	nRes=GetOutputValue();
	printf("Output Value = %d, %02x\n",nRes,nRes);


	return 0;
}

