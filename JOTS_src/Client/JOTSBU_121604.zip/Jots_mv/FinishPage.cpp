// FinishPage.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "PropertyEx.h"
#include "FinishPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFinishPage property page

IMPLEMENT_DYNCREATE(CFinishPage, CPropertyPage)

CFinishPage::CFinishPage() : CPropertyPage(CFinishPage::IDD)
{
	//{{AFX_DATA_INIT(CFinishPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CFinishPage::~CFinishPage()
{
}

void CFinishPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFinishPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFinishPage, CPropertyPage)
	//{{AFX_MSG_MAP(CFinishPage)

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinishPage message handlers

BOOL CFinishPage::OnSetActive() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	
	if (parent->m_lastPageID==0)
	{
		parent->SetWizardButtons(PSWIZB_FINISH);
		
	}
	else
		parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);

	return CPropertyPage::OnSetActive();	

}

BOOL CFinishPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	InitControls();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFinishPage::InitControls()
{
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 

	// format label controls
	GetDlgItem(IDC_LBL_TITLE)->SetFont(&font);


}