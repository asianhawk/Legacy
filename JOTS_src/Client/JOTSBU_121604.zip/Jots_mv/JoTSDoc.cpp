// JoTSDoc.cpp : implementation of the CJoTSDoc class
//

#include "stdafx.h"
#include "JoTS.h"

#include "JoTSDoc.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJoTSDoc


IMPLEMENT_DYNCREATE_ATL(CJoTSDoc, CDocument)

BEGIN_MESSAGE_MAP(CJoTSDoc, CDocument)
	//{{AFX_MSG_MAP(CJoTSDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL, OnUpdateFileSendMail)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTSDoc construction/destruction

CJoTSDoc::CJoTSDoc()
{
;

}

CJoTSDoc::~CJoTSDoc()
{
}

BOOL CJoTSDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;



	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CJoTSDoc serialization

void CJoTSDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSDoc diagnostics

#ifdef _DEBUG
void CJoTSDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CJoTSDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJoTSDoc commands

STDMETHODIMP CJoTSDoc::Hello()
{
	METHOD_PROLOGUE_ATL

	::MessageBox(NULL, GetTitle(), "Hello World", MB_OK | MB_ICONEXCLAMATION);

	return S_OK;
}

HRESULT CJoTSDoc::FinalConstruct()
{
 METHOD_PROLOGUE_ATL

 CJoTSApp* pApp = (CJoTSApp*)AfxGetApp();
 ASSERT_VALID(pApp);

 // Find document template
 POSITION pos = pApp->GetFirstDocTemplatePosition();
 CAnotherMultiDocTemplate* pDocClass = 
  (CAnotherMultiDocTemplate*)pApp->GetNextDocTemplate(pos);

 ASSERT_VALID(pDocClass);

 // Create view and frame
 pDocClass->m_pDocument = this;
 pDocClass->OpenDocumentFile(NULL, true);
 


 return S_OK;
}

void CJoTSDoc::FinalRelease()
{
 // Do will still have a View connected?
 // (The frame will no longer exist if the document
 // has been closed manually, because the OnClose
 // message is passed BEFORE deleting the document)
 POSITION pos = GetFirstViewPosition();
 if (pos != NULL) {
  // Prevent the document from deleting itself already.
  m_bAutoDelete = false;
  OnCloseDocument();
  m_bAutoDelete = true;
 }
}


BOOL CJoTSDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{

	AfxGetApp()->OpenDocumentFile(lpszPathName);
	


	m_csOpenFileName=lpszPathName;
	SetJobName(ExtractJobName(m_csOpenFileName)); 
	return TRUE;
}


BOOL CJoTSDoc::OpenJobFile(LPCTSTR lpszPathName)
{
CString	csJobName;
   
   int bResult = -1;
   short sResult = FALSE;
   
   csJobName=lpszPathName;
   if (!csJobName.IsEmpty())
   {
	   m_oXML.LoadFile(lpszPathName);
	   m_csOpenFileName=lpszPathName;
	   SetJobName(ExtractJobName(m_csOpenFileName)); 
	   ReadJobInfo();
	   return TRUE;
   }
   return bResult;



}


BOOL CJoTSDoc::GetProcessInfo()
{
JobInfo *pJobInfo;


   
   pJobInfo = m_oXML.GetJobInfo();


   SetJobName(GetJobName()); // name of job file opened, not stored filename in job file
							 // necessary in case job records are manually copied
   SetCompanyName(pJobInfo->Customer);
   SetProduct(pJobInfo->ProductDescription);
   SetMaxRePrints(pJobInfo->Reprints);
   SetMaxReScans(pJobInfo->Rescans);
	


   return TRUE;
}

CString CJoTSDoc::ExtractJobName(CString csJobPathName)
{
int nOffset;
CString csTemp;
	nOffset=csJobPathName.ReverseFind('\\');

    csTemp.Empty();
	csTemp=csJobPathName.Mid(nOffset+1);
	nOffset=csTemp.Find(".");
	csTemp=csTemp.Mid(0,nOffset);

	return csTemp;
	   

}


int CJoTSDoc::GetLabelInformation()
{
	m_nNumberOfLabels=-1;

	m_nNumberOfLabels=m_oXML.GetLabelInformation();
	
	return m_nNumberOfLabels;
}


void CJoTSDoc::ReadJobInfo()
{
	m_oXML.JobHeaderInfo();
	GetLabelInformation();
	m_nNumberOfDataSeries=m_oXML.GetDataSeriesInformation();
	m_oXML.GetTemplateInfo();	
}





CString CJoTSDoc::GetJobName()
{
	return m_csJobName;
}

void CJoTSDoc::SetJobName(CString csJobName)
{
	if (!csJobName.IsEmpty())
	{
		m_csJobName=csJobName;	
	}
	else
		m_csJobName.Empty();

}


CString CJoTSDoc::GetCompanyName()
{

	return m_csCompanyName;
}

void CJoTSDoc::SetCompanyName(CString csCompanyName)
{
	if (!csCompanyName.IsEmpty())
	{
		m_csCompanyName=csCompanyName;	
	}
	else
		m_csCompanyName.Empty();

}


CString CJoTSDoc::GetProduct()
{

	return m_csProduct;
}

void CJoTSDoc::SetProduct(CString csProduct)
{
	if (!csProduct.IsEmpty())
	{
		m_csProduct=csProduct;	
	}
	else
		m_csProduct.Empty();

}



//			Max Reprints property

CString CJoTSDoc::GetMaxRePrints()
{

	if (m_csMaxRePrints.IsEmpty())
		return "0";

	return m_csMaxRePrints;
}

void CJoTSDoc::SetMaxRePrints(CString csMaxRePrints)
{
	if (!csMaxRePrints.IsEmpty())
	{
		m_csMaxRePrints=csMaxRePrints;	
	}
	else
		m_csMaxRePrints="0";

}


//			Max ReScans property

CString CJoTSDoc::GetMaxReScans()
{
	if (m_csMaxReScans.IsEmpty()) return "0"; 
	return m_csMaxReScans;
}

void CJoTSDoc::SetMaxReScans(CString csMaxReScans)
{
	if (!csMaxReScans.IsEmpty())
	{
		m_csMaxReScans=csMaxReScans;	
	}
	else
		m_csMaxReScans="0";

}




void CJoTSDoc::SaveJob()
{
	PreProcessInfo();
	m_oXML.SaveFile(m_csOpenFileName);
}

void CJoTSDoc::SaveJobAs(CString csJobName)
{
	PreProcessInfo();
	m_oXML.SaveFile(csJobName);
}

void CJoTSDoc::PreProcessInfo()
{

//	m_oXML.SetLabelInformation();
	
	m_oXML.UpdateLabelInfo();
//	m_oXML.SetDataSeries();
	m_oXML.UpdateDataSeries(); 
//	m_oXML.SetVariableData();
	m_oXML.UpdateTemplates();

}







JobInfo *CJoTSDoc::GetJobInfo()
{ 
	return m_oXML.GetJobInfo();

}



void CJoTSDoc::CreateNewJob(CString csFileName)
{
	
	if (!csFileName.IsEmpty())
	{

		// need code to make sure path name is valid
		CXMLFile *pXML = new CXMLFile();
		pXML->CreateNewFile(csFileName);
		delete pXML;
	}
}

STDMETHODIMP CJoTSDoc::get_JobName(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
CUtilities oUtil;
CString csJobDirectory;
CString csJobPathName;
	if (oUtil.GetJobsDirectory(&csJobDirectory))
	{
	
		csJobPathName=csJobDirectory+GetJobName()+".xml";
		*pVal = csJobPathName.AllocSysString(); 

	}
	else
		*pVal = NULL; 
	return S_OK;
}

STDMETHODIMP CJoTSDoc::put_JobName(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	SetJobName(newVal); 

	return S_OK;
}

STDMETHODIMP CJoTSDoc::get_Description(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

		*pVal = GetProduct().AllocSysString(); 

	return S_OK;
}

STDMETHODIMP CJoTSDoc::put_Description(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	SetProduct(newVal); 
	return S_OK;
}
