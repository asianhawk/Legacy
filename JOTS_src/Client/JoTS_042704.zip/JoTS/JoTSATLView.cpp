// JoTSATLView.cpp : implementation of the CJoTSATLView class
//

#include "stdafx.h"
#include "JoTSATL.h"

#include "JoTSATLDoc.h"
#include "JoTSATLView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView

IMPLEMENT_DYNCREATE(CJoTSATLView, CView)

BEGIN_MESSAGE_MAP(CJoTSATLView, CView)
	//{{AFX_MSG_MAP(CJoTSATLView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView construction/destruction

CJoTSATLView::CJoTSATLView()
{
	// TODO: add construction code here

}

CJoTSATLView::~CJoTSATLView()
{
}

BOOL CJoTSATLView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView drawing

void CJoTSATLView::OnDraw(CDC* pDC)
{
	CJoTSATLDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView printing

BOOL CJoTSATLView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CJoTSATLView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CJoTSATLView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView diagnostics

#ifdef _DEBUG
void CJoTSATLView::AssertValid() const
{
	CView::AssertValid();
}

void CJoTSATLView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CJoTSATLDoc* CJoTSATLView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJoTSATLDoc)));
	return (CJoTSATLDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLView message handlers
