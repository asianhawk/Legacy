
#include "stdafx.h"
#include "SequenceGen.h"
#include "Utilities.h"




CSequenceGen::CSequenceGen()
{

	m_lng_tx = 1;
	memset(m_cs_tx_id,'\0',sizeof(m_cs_tx_id));
	memset(m_cs_begin_samp,'\0',sizeof(m_cs_begin_samp));
	memset(m_cs_end_samp,'\0',sizeof(m_cs_end_samp));
	memset(m_cs_error,'\0',sizeof(m_cs_error));
	memset(m_cs_quantity,'\0',sizeof(m_cs_quantity));
	memset(m_cs_start10,'\0',sizeof(m_cs_start10));
	memset(m_cs_end10,'\0',sizeof(m_cs_end10));
	memset(m_cs_omit,'\0',sizeof(m_cs_omit));
	memset(m_cs_btypefile,'\0',sizeof(m_cs_btypefile));


	m_csBaseTypePath = "c:\\JoTS\\Config\\basetype.txt";

	m_lng_type = atol((const char *)"0");
	m_lng_msglen=-1;
	m_blnInitComplete=FALSE;
}

CSequenceGen::CSequenceGen(CString csBaseTypePath)
{

	m_lng_tx = 1;
	memset(m_cs_tx_id,'\0',sizeof(m_cs_tx_id));
	memset(m_cs_begin_samp,'\0',sizeof(m_cs_begin_samp));
	memset(m_cs_end_samp,'\0',sizeof(m_cs_end_samp));
	memset(m_cs_error,'\0',sizeof(m_cs_error));
	memset(m_cs_quantity,'\0',sizeof(m_cs_quantity));
	memset(m_cs_start10,'\0',sizeof(m_cs_start10));
	memset(m_cs_end10,'\0',sizeof(m_cs_end10));
	memset(m_cs_omit,'\0',sizeof(m_cs_omit));
	memset(m_cs_btypefile,'\0',sizeof(m_cs_btypefile));
	
	if (!csBaseTypePath.IsEmpty()) 
		strcpy(m_cs_btypefile,csBaseTypePath);

	m_lng_type = atol((const char *)"0");
	m_lng_msglen=-1;
	m_blnInitComplete=FALSE;

}

void CSequenceGen::InitSeqGenerator(CString csTable, long lngFieldWidth, int nStepSize)
{

	if (csTable.IsEmpty()) 
	{
		AfxMessageBox("Base Type Not Defined");
		return;
	}
		
	if (lngFieldWidth<=0)
	{
		AfxMessageBox("Field Width Must Be Greate Than Zero");
		return;

	}

	SetFieldWidth(lngFieldWidth);
	
	strcpy(m_cs_table,csTable);
	m_lng_base = csTable.GetLength();

	if (nStepSize<0)	//Numgen requires quantity=2 for decrementing
		strcpy(m_cs_quantity,"2");//m_csQty);
	else
		strcpy(m_cs_quantity,"\0");

	m_blnInitComplete=TRUE;	

}

void CSequenceGen::InitSeqGenerator(CString csTable, CString csFieldWidth, int nStepSize)
{

	if (csTable.IsEmpty()) 
	{
		AfxMessageBox("Base Type Not Defined");
		return;
	}
		
	if (csFieldWidth.IsEmpty())
	{
		AfxMessageBox("Field Width Not Defined");
		return;

	}

	SetFieldWidth(csFieldWidth);
	
	strcpy(m_cs_table,csTable);
	m_lng_base = csTable.GetLength();

	if (nStepSize<0)	//Numgen requires quantity=2 for decrementing
		strcpy(m_cs_quantity,"2");//m_csQty);
	else
		strcpy(m_cs_quantity,"\0");

	m_blnInitComplete=TRUE;
}


void CSequenceGen::InitSeqGenerator(CString csBaseName, int nStepSize)
{
CUtilities *pUtil= new CUtilities();

CString csTable;
	
	csTable=pUtil->GetBaseNumberTable(csBaseName);
	if (csTable.IsEmpty())
	{
		pUtil->ErrorMessage("Base Number Schema Not Found");
		delete pUtil;
		return;
	}
	strcpy(m_cs_table,csTable);
	m_lng_base = csTable.GetLength();
	delete pUtil;

	if (nStepSize<0)	//Numgen requires quantity=2 for decrementing
		strcpy(m_cs_quantity,"2");//m_csQty);
	else
		strcpy(m_cs_quantity,"\0");

	m_blnInitComplete=TRUE;

}



CString CSequenceGen::GetNextSerialNumber(CString csCurrentValue)
{

	m_lng_tx = 1;
	strcpy(m_cs_tx_id,"\0");
	strcpy(m_cs_begin_samp,"\0");
	strcpy(m_cs_end_samp,  "\0");
	strcpy(m_cs_error,"\0");
	strcpy(m_cs_start,"\0");


	strcpy(m_cs_start10,"\0");
	strcpy(m_cs_end10,"\0");
	strcpy(m_cs_omit,"\0");

	PadString(&csCurrentValue,m_lng_msglen);
	strcpy(m_cs_end,csCurrentValue);
	
	if (m_lng_type>1)
	{
		CString csTest=GetBasePath();
		int nLength= csTest.GetLength(); 
		
		if (csTest.IsEmpty())
		{
			m_lng_process_status=0;
			return "Base Path Not Defined";
		}
	}
	
	Sequence_Generator	(	m_lng_tx,
								m_cs_tx_id,
								&m_lng_tx_status,
								&m_lng_process_status,
								m_lng_base,
								m_lng_type,
								m_cs_table,
								m_cs_begin_samp,
								m_cs_end_samp,
								m_cs_start,
								m_cs_end,
								m_cs_quantity,
								m_cs_start10,
								m_cs_end10,
								m_cs_omit,
								m_lng_msglen,
								m_cs_error,
								GetBasePath());

	if (GetStatusMessage().Find("Successful")==-1)
	{
		if (m_lng_process_status==9)
		{
			int nStep=atoi(m_cs_quantity);
			CString csBuffer;
			for (int nCount=0;nCount<m_lng_msglen;nCount++)
			{
				if (nStep==2)
				{
					csBuffer+=m_cs_table[m_lng_base-1];

				}
				else
					csBuffer+=m_cs_table[0];

			}
			return csBuffer;
	
		}
	}

	if (m_cs_quantity[0]=='\0')
		return m_cs_end;
	else	// decrememting
		return m_cs_start;

}


BOOL CSequenceGen::GetNextSerialNumber(CString csCurrentValue, CString *csNextValue)
{

	m_lng_tx = 1;
	strcpy(m_cs_tx_id,"\0");
	strcpy(m_cs_begin_samp,"\0");
	strcpy(m_cs_end_samp,  "\0");
	strcpy(m_cs_error,"\0");
	strcpy(m_cs_start,"\0");

	strcpy(m_cs_start10,"\0");
	strcpy(m_cs_end10,"\0");
	strcpy(m_cs_omit,"\0");


	PadString(&csCurrentValue,m_lng_msglen);
	strcpy(m_cs_end,csCurrentValue);
	
	if (m_lng_type>1)
	{
		CString csTest=GetBasePath();
		int nLength= csTest.GetLength(); 
		
		if (csTest.IsEmpty())
		{
			m_lng_process_status=0;
			return FALSE;
		}
	}
	
	Sequence_Generator	(	m_lng_tx,
								m_cs_tx_id,
								&m_lng_tx_status,
								&m_lng_process_status,
								m_lng_base,
								m_lng_type,
								m_cs_table,
								m_cs_begin_samp,
								m_cs_end_samp,
								m_cs_start,
								m_cs_end,
								m_cs_quantity,
								m_cs_start10,
								m_cs_end10,
								m_cs_omit,
								m_lng_msglen,
								m_cs_error,
								GetBasePath());


	if (GetStatusMessage().Find("Successful")!=-1)
	{
		if (m_cs_quantity[0]=='\0')
			*csNextValue=m_cs_end;
		else
			*csNextValue=m_cs_start;
		return TRUE;

	}
	else
	{
		if (m_lng_process_status==9)
		{
			int nStep=atoi(m_cs_quantity);
			CString csBuffer;
			for (int nCount=0;nCount<m_lng_msglen;nCount++)
			{
				if (nStep==2)
				{
					csBuffer+=m_cs_table[m_lng_base-1];

				}
				else
					csBuffer+=m_cs_table[0];

			}
			*csNextValue=csBuffer;
			return TRUE;
	
		}
	}
	return FALSE;
}

CString CSequenceGen::GetStatusMessage()
{
CString csStatusMessage;
	switch (m_lng_process_status)
	{
		case 0:
			csStatusMessage = "General Error";
			break;
		case 1:
			csStatusMessage = "Successful";
			break;
		case 6:
			csStatusMessage = "Invalid Base Or Numbering Type";
			break;
		case 7:
			csStatusMessage = "Invalid Message Length";
			break;
		case 8:
			csStatusMessage = "Invalid Character, Check Base Schema Selected";
			break;
		case 9:
			csStatusMessage = "Value Of End Number Greater Than Max Value";
			break;
		case 12:
			csStatusMessage = "End Number Is Smaller That Start Number";
			break;
		case 14:
			csStatusMessage = "Invalid Characters In Quantity";
			break;
		case 17:
			csStatusMessage = "Message Length Was Not Entered";
			break;
		default:
			csStatusMessage = "Unknown Error";
			break;

	}

	return csStatusMessage;

}

BOOL CSequenceGen::IsError()
{
	if (m_lng_process_status==1)
		return FALSE;

	return TRUE;


}

void CSequenceGen::SetBasePath(CString csBasePath)
{
	strcpy(m_cs_btypefile,csBasePath);

}
char *CSequenceGen::GetBasePath()
{

	return m_cs_btypefile;
}

void CSequenceGen::PadString(CString *csValue, int nWidth)
{
CString csBuffer;
CString csFormat;
	
	csFormat.Format("%d",nWidth); 
	csFormat= CString("%0") + csFormat +"s";
	csBuffer.Format(csFormat,*csValue);
	
	*csValue = csBuffer;

}

long CSequenceGen::GetFieldWidth()
{

	return m_lng_msglen;
}

void CSequenceGen::SetFieldWidth(CString csFieldWidth)
{

	m_lng_msglen = atol(csFieldWidth);
}
void CSequenceGen::SetFieldWidth(long lngFieldWidth)
{
	m_lng_msglen = lngFieldWidth;

}

BOOL CSequenceGen::GetBase10Equivalent(CString csNumber, long &lngConvertedValue, CString *csErrMessage)
{
	CUtilities *pUtil= new CUtilities();	

	if(!m_blnInitComplete)
	{
		*csErrMessage="Sequence Generator Not Initialized";
		delete pUtil;
		return FALSE;

	}

	if (csNumber.IsEmpty())
	{

		pUtil->ErrorMessage("Value To Be Converted To Base 10 Can Not Be Blank","Error: Level 2");
		delete pUtil;
		return FALSE;

	}

	m_lng_tx = 1;
	strcpy(m_cs_tx_id,"\0");
	strcpy(m_cs_begin_samp,"\0");
	strcpy(m_cs_end_samp,  "\0");
	strcpy(m_cs_error,"\0");
	strcpy(m_cs_start,"\0");

	strcpy(m_cs_quantity,"\0");//m_csQty);
	strcpy(m_cs_start10,"\0");
	strcpy(m_cs_end10,"\0");
	strcpy(m_cs_omit,"\0");
	strcpy(m_cs_end,"\0");

//	PadString(&csNumber,m_lng_msglen);
//	m_lng_msglen=4;
	strcpy(m_cs_start,csNumber);
	
	if (m_lng_type>1)
	{
		CString csTest=GetBasePath();
		int nLength= csTest.GetLength(); 
		
		if (csTest.IsEmpty())
		{
			m_lng_process_status=0;
			delete pUtil;
			return FALSE;
		}
	}
	
	Sequence_Generator	(	m_lng_tx,
								m_cs_tx_id,
								&m_lng_tx_status,
								&m_lng_process_status,
								m_lng_base,
								m_lng_type,
								m_cs_table,
								m_cs_begin_samp,
								m_cs_end_samp,
								m_cs_start,
								m_cs_end,
								m_cs_quantity,
								m_cs_start10,
								m_cs_end10,
								m_cs_omit,
								m_lng_msglen,
								m_cs_error,
								GetBasePath());

	
	if (GetStatusMessage().Find("Successful")!=-1)
	{
		lngConvertedValue=atol(m_cs_start10);
		delete pUtil;
		return TRUE;
	}
	lngConvertedValue=-1;
	*csErrMessage = GetStatusMessage();
	delete pUtil;
	return FALSE;


}