//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_JOBVIEW_H__3D847DB9_3A0D_4E9E_A125_56D8811A36BD__INCLUDED_)
#define AFX_JOBVIEW_H__3D847DB9_3A0D_4E9E_A125_56D8811A36BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// JobView.h : header file
//0x000000000





#include "AccessRightsDlg.h"
#include "UserAccountDlg.h"
#include "tab control src/TabCtrlSSL.h"
#include "LabelsTabPage.h"
#include "DisplayLabelsDlg.h"
#include "DataSeriesDlg.h"
#include "DisplayTemplatesDlg.h"
#include "VariableDataDlg.h"
#include "XMLTreeDlg.h"

#include "XInfoTip.h"
#include "BCMenu.h"

#include "LMorphor3.h"
#include "ProcessJob.h"


/////////////////////////////////////////////////////////////////////////////
// CJobView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CJobView : public CFormView,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CJobView, &CLSID_Main>,
	public IConnectionPointContainerImpl<CJobView>,
	public IDispatchImpl<IMain, &IID_IMain, &LIBID_JoTS>

{
protected:
	CJobView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE_ATL(CJobView)
	DECLARE_REGISTRY_RESOURCEID(IDR_MAINVIEW)
	DECLARE_NOT_AGGREGATABLE(CJobView)

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CJobView)
		COM_INTERFACE_ENTRY(IMain)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY(IConnectionPointContainer)
	END_COM_MAP()
	BEGIN_CONNECTION_POINT_MAP(CJobView)
	END_CONNECTION_POINT_MAP()


// Form Data
public:
	//{{AFX_DATA(CJobView)
	enum { IDD = IDD_JOBVIEW_FORM };
	CEdit	m_txbMaxReScans;
	CEdit	m_txbMaxRePrints;
	CEdit	m_txbCompanyName;
	CTabCtrl	*m_tabMain;
	CEdit	m_txbProductDescription;
	CEdit	m_txbJobName;
	CString	m_csJobName;
	CString	m_csProductDescription;
	CString	m_csCompanyName;
	CString	m_csMaxRePrints;
	CString	m_csMaxReScans;
	//}}AFX_DATA

// Attributes
public:
	CJoTSDoc* GetDocument();

	// Array of all the property-page dialogs
	CTypedPtrArray<CObArray, CDialog*> m_DlgArray;

	CDisplayLabelsDlg		*m_DisplayDlg;
	CDataSeriesDlg			*m_DataSeriesDlg;
	CDisplayTemplatesDlg	*m_TemplatesDlg;
	CVariableDataDlg		*m_VariableDataDlg;
	CXMLTreeDlg				*m_XMLTreeDlg;

	void			UpDateJobView();
	void			UnLockTab(int nID);
	BCMenu m_menu,m_mymenu,m_default,m_test;

// Operations
public:
	STDMETHOD(get_LabelsPerUnit)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_GetBarCode)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(ScanLabel)(/*[out, retval]*/ BOOL *blnCompleted);
	STDMETHOD(PrintJob)(/*[in]*/ BSTR JobName, /*[out, retval]*/ BOOL *blnCompleted);
	STDMETHOD(get_ErrorMessage)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(PrintOne)();
	STDMETHOD(get_Status)(/*[out, retval]*/ long *pVal);
	STDMETHOD(Stop)();
	STDMETHOD(Start)();
	STDMETHOD(Run)(BSTR JobName);
	STDMETHOD(OpenJob)(BSTR newVal, BOOL *blnIsOpen);
	STDMETHOD(get_ProductDescription)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ProductDescription)(/*[in]*/ BSTR newVal);
	STDMETHOD(CloseJob)();
	STDMETHOD(OpenJobDlg)();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJobView)
	public:
	virtual void OnFinalRelease();
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnDraw(CDC* pDC);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CJobView();
	CDC m_MemDC; 
	CBitmap m_bmpView; 
	int m_nBmpWidth,m_nBmpHeight;
	CLabelsTabPage *m_tabPage_Labels;
	void CreatePages();
	void DeleteTabItems();
	void AddRunTab();


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CJobView)
	afx_msg void OnSetupSecurityAccessRights();
	afx_msg void OnSetupUserAccount();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnFileJobsOpen();
	afx_msg void OnFileJobsNew();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnRunSingle();
	afx_msg void OnUpdateRunSingle(CCmdUI* pCmdUI); 
	afx_msg void OnSetupMorphorNetwork();
	afx_msg void OnFileClose();
	afx_msg void OnEditJobInformation();
	afx_msg void OnEditJobLabels();
	afx_msg void OnEditDataSeries();
	afx_msg void OnEditTemplates();
	afx_msg void OnEditVariableData();
	afx_msg void OnSetupSystemconfiguration();
	afx_msg void OnSetupCustomBasenumber();
	afx_msg void OnFileNew();
	afx_msg LRESULT OnReset(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnUpdateTemplates(WPARAM wp, LPARAM lp);
	afx_msg void OnAppExit();
	//}}AFX_MSG
	// Handle TCN_SELCHANGING message - hide the current active page
	afx_msg void OnTabSelChanging(NMHDR* pnmhdr, LRESULT* pResult);

	// Handle TCN_SELCHANGE message - show the newly selected page
	afx_msg void OnTabSelChange(NMHDR* pnmhdr, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CJobView)
	afx_msg BSTR GetProduct();
	afx_msg void SetProduct(LPCTSTR lpszNewValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
private:
	BOOL m_blnNewJob;

	CJoTSDoc *m_pDoc;
	BOOL OnFileJobsOpen(CString csJobName); 
	void CheckForJobRecordChanges();
	BOOL UpdateJobHeaderInfo();
	BOOL CheckJobReferentialIntegrity();
	void RestoreJobView();
	void DisplayRunJobView();
	BOOL BuildToolsMenu(HMENU hMenu);

	CImageList m_imageList;
	int		   m_nRunDlgIndex;
	CPPToolTip 		m_Tip;
	HICON			m_hIcon1;

	BOOL			m_blnRunOleMode;

	// Automation Status
	long			m_lngRunStatus;
	void			SetRunStatus(long lngStatus);
	long			GetRunStatus();

	// Automation Routines + Data Members
	CLMorphor3		*m_pMorphor;
	CProcessJob		*m_pProcessJob;

	BOOL			AutoStart();
	BOOL			AutoStop();
	BOOL			AutoRun(); 
	HANDLE			m_dwThread;


	void	SetServerState(int nState);
	int		GetServerState();
	int		m_nServerState;
	unsigned short	m_nViewState;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOBVIEW_H__3D847DB9_3A0D_4E9E_A125_56D8811A36BD__INCLUDED_)
