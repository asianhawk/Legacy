// DisplayTemplatesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "DisplayTemplatesDlg.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplayTemplatesDlg dialog


CDisplayTemplatesDlg::CDisplayTemplatesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDisplayTemplatesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDisplayTemplatesDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_blnIsModified=FALSE;
}


void CDisplayTemplatesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDisplayTemplatesDlg)
	DDX_Control(pDX, IDC_BTN_PRINT, m_btnPrint);
	DDX_Control(pDX, IDC_BTN_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_BTN_LOAD, m_btnLoad);
	DDX_Control(pDX, IDC_CMB_TEMPLATES, m_cmbTemplates);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDisplayTemplatesDlg, CDialog)
	//{{AFX_MSG_MAP(CDisplayTemplatesDlg)
	ON_BN_CLICKED(IDC_BTN_LOAD, OnBtnLoad)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayTemplatesDlg message handlers

BOOL CDisplayTemplatesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CRect frameRect;
	GetDlgItem(IDC_EDIT_FRAME)->GetWindowRect(frameRect);
	ScreenToClient(frameRect);
	frameRect.InflateRect(-2,-2);


	CString keywordsFile = "c:\\JoTS\\Keywords.ini";
	long iTabSize = 4;   // number of spaces in a tab. tabs are always spaces.
	int iFontSize = 100; //font size * 10 (I.E. 100 = 10pt)
	CString csFontName = "Courier New";
   
   
	m_pColorWnd = new ColorEditWnd(this,			      // parent window
		                           frameRect,			   // initial size and position
		                           ID_EDIT_WND,	      // id value
		                           iTabSize,		
		                           iFontSize,		
		                           csFontName);


   // put a little space between the chars
   m_pColorWnd->SetCharXSpacing(2);

   // we'll use a custom colorizer
   m_pColorWnd->SetColorizer(&m_colorizer);

   m_pColorWnd->SetHighlightColor(RGB(0,0,0));

   m_pColorWnd->SetReadOnly(false);

 //  m_pColorWnd->SetSelection(0,0,10,40);
 //  m_pColorWnd->ReplaceSelText("#this is a comment\nThis is some text\n\n@:label\nThat was a label...\nHere's a special sequence:\n@+\nmore text ");

   m_pColorWnd->ClearUndoHistory();

   // load the keywords file
   m_colorizer.LoadKeywordFile(keywordsFile);

   m_pColorWnd->SetFocus();

   InitControls();

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDisplayTemplatesDlg::OnBtnLoad() 
{
CString csInput;
CString csFileName;
CUtilities *pUtil=new CUtilities();
CString csTemplateDir;

	pUtil->GetZebraPrinterTemplateDirectory(&csTemplateDir);
	if (csTemplateDir.IsEmpty())
	{
		pUtil->ErrorMessage("Template Directory Not Found"); 

	}
	delete pUtil;		
	
	m_csFileName="";
	m_cmbTemplates.GetWindowText(csFileName); 
	csFileName = csTemplateDir +	csFileName;  

	CStdioFile f;
	if (!f.Open(csFileName, CFile::modeRead | CFile::typeText))
	{
	 AfxMessageBox("Can't open that file");
	 return;
	}
	m_csFileName=csFileName;
	CString t;
	while (f.ReadString(t))
	{
	 csInput+=t;
	 csInput+="\n"; // ReadString strips these
	}

	f.Close();

	m_pColorWnd->LoadText(csInput);

}

void CDisplayTemplatesDlg::OnBtnSave() 
{
CUtilities *pUtil=new CUtilities();
CString csTemplateDir;

	pUtil->GetZebraPrinterTemplateDirectory(&csTemplateDir);
	delete pUtil;
	
	CString csOutput;

	CString filt="Printer Template(*.zpl)|*.zpl||";
    
//	CFileDialog fileDlg(FALSE,"*.zpl","*.zpl",NULL,filt,this);
	
//	fileDlg.m_ofn.lpstrTitle="Save Printer Template";
//	fileDlg.m_ofn.lpstrInitialDir = csTemplateDir;

 
	m_pColorWnd->UnloadText(csOutput);
	
	if (csOutput.IsEmpty()) return; 
    if(!UpdateDataSeries(csOutput))
		return;

//	if (fileDlg.DoModal()==IDOK) 
//	{
//		CWaitCursor bob;
		
//		CString fileName=fileDlg.GetPathName();
;
	if (!m_csFileName.IsEmpty()) 
	{
      CStdioFile f;
      if (!f.Open(m_csFileName, CFile::modeWrite | CFile::modeCreate | CFile::typeText))
      {
         AfxMessageBox("Can't open that file");
         return;
      }


      CString t;
      f.WriteString(csOutput);

      f.Close();

	}
	
}

BOOL CDisplayTemplatesDlg::UpdateDataSeries(CString csTemplate)
{

	if(!UpdateBCVars(csTemplate))
		return FALSE;

	if(!UpdateHRVars(csTemplate))
		return FALSE;
	::SendMessage(m_hwndParent,UWM_RESET_VIEW,0,0); 
	return TRUE;
}


void  CDisplayTemplatesDlg::UpdateCombo()
{

	m_cmbTemplates.ResetContent();  
	for (int i=0;i<MAXTEMPLATES;i++)
	{
		if(m_pJobInfo->Templates[i].Name.IsEmpty()) break;   

        if (m_cmbTemplates.FindString(-1,m_pJobInfo->Templates[i].Name)==CB_ERR)
			m_cmbTemplates.AddString(m_pJobInfo->Templates[i].Name);
		
	}
	if(!m_pJobInfo->Templates[0].Name.IsEmpty())
		m_cmbTemplates.SetCurSel(0);   

	
}


void CDisplayTemplatesDlg::InitControls()
{


	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	GetDlgItem(IDC_LBL_TEMPLATES)->SetFont(&font);
	GetDlgItem(IDC_CMB_TEMPLATES)->SetFont(&font);

	GetDlgItem(IDC_LBL_TEST)->SetFont(&font);
	GetDlgItem(IDC_LBL_PRINT_QTY)->SetFont(&font);
	GetDlgItem(IDC_TXB_PQTY)->SetFont(&font);


	// format label controls
	
	m_btnLoad.SetFont(&font);
	m_btnLoad.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnLoad.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnLoad.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnLoad.SetIcon(IDI_OK);
//	m_btnLoad.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnSave.SetFont(&font);
	m_btnSave.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnLoad.SetIcon(IDI_OK);
//	m_btnLoad.SetAlign(CButtonST::ST_ALIGN_HORIZ);

	m_btnPrint.SetFont(&font);
	m_btnPrint.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnPrint.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnPrint.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnLoad.SetIcon(IDI_OK);
//	m_btnLoad.SetAlign(CButtonST::ST_ALIGN_HORIZ);



}

BOOL CDisplayTemplatesDlg::IsModified()
{
	return m_blnIsModified;
}

void CDisplayTemplatesDlg::SetModified(BOOL blnState)
{
	m_blnIsModified=blnState;

}


BOOL CDisplayTemplatesDlg::UpdateBCVars(CString csTemplate)
{

CUtilities *pUtil=new CUtilities();
CStringArray csaBCVars;
CString csTemp;
int nMaxNumberOfBarCodeVars;

	csTemp=pUtil->GetConfigValue(MAXBARCODEVALUES); 
	nMaxNumberOfBarCodeVars=atoi(csTemp);
	pUtil->ScanForBarcode_Vars(csTemplate, &csaBCVars);
	if (csaBCVars.GetSize()>nMaxNumberOfBarCodeVars)
	{
		csTemp.Format("Only [%d] Bar Code Allowed",nMaxNumberOfBarCodeVars);
		pUtil->ErrorMessage(csTemp);
		delete pUtil;

		return FALSE;
	}
	else if (csaBCVars.GetSize()>0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			m_cmbTemplates.GetLBText(m_cmbTemplates.GetCurSel(),csTemplate);   
			if (csTemplate==m_pJobInfo->Templates[nCount].Name)
			{
				if(!m_pJobInfo->Templates[nCount].BCVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=csaBCVars.GetAt(nIndex); 
					m_blnIsModified=TRUE;
					nIndex++;
				}
				else
				{
					if (csaBCVars.GetAt(nIndex)!=m_pJobInfo->Templates[nCount].BCVars[nIndex].Name)
					{
						m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=csaBCVars.GetAt(nIndex); 
						if (!m_pJobInfo->SerialData[0].Name.IsEmpty()) 
							m_pJobInfo->Templates[nCount].BCVars[nIndex].Data=m_pJobInfo->SerialData[0].Name;
						m_blnIsModified=TRUE;
						nIndex++;
					}

				}

			}
			nCount++;
		}
	}
	else if (csaBCVars.GetSize()==0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			m_cmbTemplates.GetLBText(m_cmbTemplates.GetCurSel(),csTemplate);   
			if (csTemplate==m_pJobInfo->Templates[nCount].Name)
			{
				while(!m_pJobInfo->Templates[nCount].BCVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Data=""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Prefix =""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Suffix =""; 

					m_blnIsModified=TRUE;
					nIndex++;
				}

			}
			nCount++;
		}
	}

	delete pUtil;
	return TRUE;
}


BOOL CDisplayTemplatesDlg::UpdateBCVars(CString csTemplate, CString csTemplateName)
{

CUtilities *pUtil=new CUtilities();
CStringArray csaBCVars;
CString csTemp;
int nMaxNumberOfBarCodeVars;

	csTemp=pUtil->GetConfigValue(MAXBARCODEVALUES); 
	nMaxNumberOfBarCodeVars=atoi(csTemp);
	pUtil->ScanForBarcode_Vars(csTemplate, &csaBCVars);
	if (csaBCVars.GetSize()>nMaxNumberOfBarCodeVars)
	{
		csTemp.Format("Only [%d] Bar Code Allowed",nMaxNumberOfBarCodeVars);
		pUtil->ErrorMessage(csTemp);
		delete pUtil;

		return FALSE;
	}
	else if (csaBCVars.GetSize()>0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			   
			if (csTemplateName==m_pJobInfo->Templates[nCount].Name)
			{
				if(!m_pJobInfo->Templates[nCount].BCVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=csaBCVars.GetAt(nIndex); 
					m_blnIsModified=TRUE;
					nIndex++;
				}
				else
				{
					if (csaBCVars.GetAt(nIndex)!=m_pJobInfo->Templates[nCount].BCVars[nIndex].Name)
					{
						m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=csaBCVars.GetAt(nIndex); 
						if (!m_pJobInfo->SerialData[0].Name.IsEmpty()) 
							m_pJobInfo->Templates[nCount].BCVars[nIndex].Data=m_pJobInfo->SerialData[0].Name;
						m_blnIsModified=TRUE;
						nIndex++;
					}

				}

			}
			nCount++;
		}
	}
	else if (csaBCVars.GetSize()==0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			   
			if (csTemplateName==m_pJobInfo->Templates[nCount].Name)
			{
				while(!m_pJobInfo->Templates[nCount].BCVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Name=""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Data=""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Prefix =""; 
					m_pJobInfo->Templates[nCount].BCVars[nIndex].Suffix =""; 

					m_blnIsModified=TRUE;
					nIndex++;
				}

			}
			nCount++;
		}
	}

	delete pUtil;
	return TRUE;
}



BOOL CDisplayTemplatesDlg::UpdateHRVars(CString csTemplate)
{

CUtilities *pUtil=new CUtilities();
CStringArray csaVars;
CString csTemp;
HR_Vars HRVars[MAXVARS];
int nCurrentCount=0;
	pUtil->ScanForHR_Vars(csTemplate, &csaVars);



	if (csaVars.GetSize()>0)
	{
		int nCount=0;
		int nIndex=0;
		int nSearchIndex=0;
		CString csTemplate;
		BOOL blnMatch=FALSE;
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			m_cmbTemplates.GetLBText(m_cmbTemplates.GetCurSel(),csTemplate);   
			if (csTemplate==m_pJobInfo->Templates[nCount].Name)
			{

				// save current HR var info
				nCurrentCount=pUtil->GetHRVars(nCount, m_pJobInfo, HRVars);
				for(nIndex=0;nIndex<csaVars.GetSize();nIndex++)
				{
				
					blnMatch=FALSE;
				    for (nSearchIndex=0;nSearchIndex<=nCurrentCount;nSearchIndex++)
					{

						if (csaVars.GetAt(nIndex)==HRVars[nSearchIndex].Name)
						{
							blnMatch=TRUE;
							break;
						}
					}
					
					// 


					if (!blnMatch)
					{
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=csaVars.GetAt(nIndex) ; 
							if (!m_pJobInfo->SerialData[0].Name.IsEmpty()) 
								m_pJobInfo->Templates[nCount].HRVars[nIndex].Data=m_pJobInfo->SerialData[0].Name;
					}
					else
					{

						m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=HRVars[nSearchIndex].Name ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Prefix =HRVars[nSearchIndex].Prefix  ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Suffix =HRVars[nSearchIndex].Suffix  ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Data =HRVars[nSearchIndex].Data  ; 



					}
				}
			}
			nCount++;
		}
	}
	else if (csaVars.GetSize()==0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			m_cmbTemplates.GetLBText(m_cmbTemplates.GetCurSel(),csTemplate);   
			if (csTemplate==m_pJobInfo->Templates[nCount].Name)
			{
				while(!m_pJobInfo->Templates[nCount].HRVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Data=""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Prefix =""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Suffix =""; 

					m_blnIsModified=TRUE;
					nIndex++;
				}

			}
			nCount++;
		}
	}

	delete pUtil;
//	::SendMessage(m_hwndParent,UWM_RESET_VIEW,0,0); 
	return TRUE;
}


BOOL CDisplayTemplatesDlg::UpdateHRVars(CString csTemplate, CString csTemplateName)
{

CUtilities *pUtil=new CUtilities();
CStringArray csaVars;
CString csTemp;
HR_Vars HRVars[MAXVARS];
int nCurrentCount=0;
	pUtil->ScanForHR_Vars(csTemplate, &csaVars);



	if (csaVars.GetSize()>0)
	{
		int nCount=0;
		int nIndex=0;
		int nSearchIndex=0;
		CString csTemplate;
		BOOL blnMatch=FALSE;
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{

			if (csTemplateName==m_pJobInfo->Templates[nCount].Name)
			{

				// save current HR var info
				nCurrentCount=pUtil->GetHRVars(nCount, m_pJobInfo, HRVars);
				for(nIndex=0;nIndex<csaVars.GetSize();nIndex++)
				{
				
					blnMatch=FALSE;
				    for (nSearchIndex=0;nSearchIndex<=nCurrentCount;nSearchIndex++)
					{

						if (csaVars.GetAt(nIndex)==HRVars[nSearchIndex].Name)
						{
							blnMatch=TRUE;
							break;
						}
					}
					
					// 


					if (!blnMatch)
					{
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=csaVars.GetAt(nIndex) ; 
							if (!m_pJobInfo->SerialData[0].Name.IsEmpty()) 
								m_pJobInfo->Templates[nCount].HRVars[nIndex].Data=m_pJobInfo->SerialData[0].Name;
					}
					else
					{

						m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=HRVars[nSearchIndex].Name ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Prefix =HRVars[nSearchIndex].Prefix  ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Suffix =HRVars[nSearchIndex].Suffix  ; 
						m_pJobInfo->Templates[nCount].HRVars[nIndex].Data =HRVars[nSearchIndex].Data  ; 



					}
				}
			}
			nCount++;
		}
	}
	else if (csaVars.GetSize()==0)
	{
		int nCount=0;
		int nIndex=0;
		CString csTemplate;
		
		while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
		{
			if (csTemplateName==m_pJobInfo->Templates[nCount].Name)
			{
				while(!m_pJobInfo->Templates[nCount].HRVars[nIndex].Name.IsEmpty())
				{
					
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Name=""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Data=""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Prefix =""; 
					m_pJobInfo->Templates[nCount].HRVars[nIndex].Suffix =""; 

					m_blnIsModified=TRUE;
					nIndex++;
				}

			}
			nCount++;
		}
	}

	delete pUtil;
//	::SendMessage(m_hwndParent,UWM_RESET_VIEW,0,0); 
	return TRUE;
}



BOOL CDisplayTemplatesDlg::UpdateDataSeries2(CString csTemplateName)
{

CString csInput;
CString csFileName;
CUtilities *pUtil=new CUtilities();
CString csTemplateDir;

	pUtil->GetZebraPrinterTemplateDirectory(&csTemplateDir);
	if (csTemplateDir.IsEmpty())
	{
		pUtil->ErrorMessage("Template Directory Not Found"); 

	}
	delete pUtil;		
	
	csFileName = csTemplateDir + csTemplateName;  

	CStdioFile f;
	if (!f.Open(csFileName, CFile::modeRead | CFile::typeText))
	{
	 AfxMessageBox("Can't open that file");
	 return FALSE;
	}
	CString t;
	while (f.ReadString(t))
	{
	 csInput+=t;
	 csInput+="\n"; // ReadString strips these
	}

	f.Close();




	if(!UpdateBCVars(csInput, csTemplateName))
		return FALSE;

	if(!UpdateHRVars(csInput, csTemplateName))
		return FALSE;


	::SendMessage(m_hwndParent,UWM_RESET_VIEW,0,0); 
	return TRUE;
}

