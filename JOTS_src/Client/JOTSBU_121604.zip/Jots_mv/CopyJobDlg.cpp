// CopyJobDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "CopyJobDlg.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	  JOBNAME		0
#define	  COMPANY		1	
#define   PRODUCT		2


/////////////////////////////////////////////////////////////////////////////
// CCopyJobDlg dialog


CCopyJobDlg::CCopyJobDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCopyJobDlg::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CCopyJobDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CCopyJobDlg::~CCopyJobDlg()
{
	m_Grid.DeleteAllItems(); 

}

void CCopyJobDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CCopyJobDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCopyJobDlg)
	DDX_Control(pDX, IDC_LBL_TITLE, m_lblTitle);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDOK, m_btnCopy);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCopyJobDlg, CDialog)
	//{{AFX_MSG_MAP(CCopyJobDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CCopyJobDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CCopyJobDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ICopyJobDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {7A62AC16-7575-456A-AC46-F3A3D354628A}
static const IID IID_ICopyJobDlg =
{ 0x7a62ac16, 0x7575, 0x456a, { 0xac, 0x46, 0xf3, 0xa3, 0xd3, 0x54, 0x62, 0x8a } };

BEGIN_INTERFACE_MAP(CCopyJobDlg, CDialog)
	INTERFACE_PART(CCopyJobDlg, IID_ICopyJobDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCopyJobDlg message handlers
void CCopyJobDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
	if ((pItem->iRow) >= (m_Grid.GetFixedRowCount()))
	{
		if (!m_Grid.GetItemText(pItem->iRow,0).IsEmpty())	
		{
			m_btnCopy.EnableWindow(TRUE); 
			m_nCurrentRow=pItem->iRow;
			return;
			
		}

	}
	m_btnCopy.EnableWindow(FALSE);  
	m_nCurrentRow=-1; 
	


}


void CCopyJobDlg::InitGrid() 
{

int	nCount;
JobInfo JobRecord;
CString csTemp;

	m_Grid.SetFixedRowCount(1);
	m_Grid.SetRowCount(MAXJOBS + m_Grid.GetFixedRowCount());		//Data Rows

	m_Grid.SetColumnCount(3);
	m_Grid.SetFixedColumnCount(1);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(TRUE); 

    m_Grid.SetItemText(0,JOBNAME,"Job Name");
    m_Grid.SetItemText(0,COMPANY,"Company");

    m_Grid.SetItemText(0,PRODUCT,"Description");
	





	




	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);
	if(!GetAvailableJobs()) return;
	
	int nMaxJobs=m_csaJobNames.GetSize(); 

	if (nMaxJobs>MAXJOBS)
		m_Grid.SetRowCount(nMaxJobs); 

	int nRowOffset=m_Grid.GetFixedRowCount();
	CUtilities *pUtil = new CUtilities();

	for (nCount=0;nCount<nMaxJobs;nCount++)
	{
		csTemp = m_csaJobNames.GetAt(nCount);
		if(!pUtil->GetJobFileInfo(csTemp,&JobRecord))
		{
			pUtil->ErrorMessage("Error In Retrieving Job Record Information");
			delete pUtil;
			return;

		}
		m_Grid.SetItemText(nCount+nRowOffset,JOBNAME,csTemp);
		m_Grid.SetItemText(nCount+nRowOffset,COMPANY,JobRecord.Customer );
		m_Grid.SetItemText(nCount+nRowOffset,PRODUCT,JobRecord.ProductDescription );

		
	}

	
	
	for (nCount=0;nCount<nMaxJobs;nCount++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			if (nCount==0)
				m_Grid.SetItemFormat(nCount,nColumn,DT_CENTER|DT_VCENTER);
			else
				m_Grid.SetItemFormat(nCount,nColumn,DT_LEFT|DT_VCENTER);

			
		}
		m_Grid.SetRowHeight(nCount,25); 
	}
	m_Grid.ExpandColumnsToFit(TRUE); 
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
    m_Grid.SetFixedColumnSelection(FALSE);
    m_Grid.SetFixedRowSelection(TRUE);
	

	m_btnCopy.EnableWindow(FALSE); 

}


BOOL CCopyJobDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	InitGrid();	
	InitControls();
	m_Grid.SetModified(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CCopyJobDlg::InitControls() 
{

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	GetDlgItem(IDC_LBL_TITLE)->SetFont(&font);
	GetDlgItem(IDOK)->SetFont(&font);
	GetDlgItem(IDCANCEL)->SetFont(&font);

}

BOOL CCopyJobDlg::GetAvailableJobs()
{
CString csJobDirectory;
CUtilities *pUtil = new CUtilities();
CFileFind ff;

	if(!pUtil->GetJobsDirectory(&m_csJobDirectory))
	{
		
		pUtil->ErrorMessage("Job Directory Not Defined");
		delete pUtil;
		return FALSE;
	}
	csJobDirectory=m_csJobDirectory+"*.xml";
	if(!ff.FindFile(csJobDirectory))
	{
		
		pUtil->ErrorMessage("Job Directory/Or No Job Files Found");
		delete pUtil;
		return FALSE;

	}
	delete pUtil;

	if (ff.FindNextFile()==0)
	{
		m_csaJobNames.Add(ff.GetFileName());  
		return TRUE;
	}
	else
		m_csaJobNames.Add(ff.GetFileName());  
	while(ff.FindNextFile()!=0)
	{
		m_csaJobNames.Add(ff.GetFileName());  
	}
	m_csaJobNames.Add(ff.GetFileName());  

	return TRUE;
}

void CCopyJobDlg::OnOK() 
{

		
	
CString csJobFileName,
		csJobsDirectory;
CUtilities *pUtil=new CUtilities();
	 
	CString csCurrentJobName = m_Grid.GetItemText(m_nCurrentRow,0);
	if (csCurrentJobName.IsEmpty())
	{
	// Should never happen, but just in case
		pUtil->ErrorMessage("No Job Name Is Selected");
		delete pUtil;
		return;
		
	}
	if (m_csJobDirectory.IsEmpty())
	{
		// Should never happen, but just in case
		pUtil->ErrorMessage("Job Directory Not Found");
		delete pUtil;
		return;
	}

	CFileDialog fileDlg(FALSE, NULL, NULL, 
					   OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY, 
					   "Job Files (*.xml)|*.xml||");


  
  
  
   fileDlg.m_ofn.lpstrTitle = "Copy Job Record";
   fileDlg.m_ofn.lpstrInitialDir = m_csJobDirectory;

	// Call DoModal
	if ( fileDlg.DoModal() == IDOK)
	{
		csJobFileName = fileDlg.GetFileName(); // This is your selected file name with path
		if (csJobFileName.IsEmpty())
		{
			pUtil->ErrorMessage("No File Name Was Entered");
			delete pUtil;
			return;

		}
		
		// in case user add's own extension
		int  nOffset = csJobFileName.Find(".");
		if (nOffset!=-1)
		  csJobFileName=csJobFileName.Mid(0,nOffset);

		csJobFileName+=".xml";
		if(CopyFile(m_csJobDirectory+csCurrentJobName,m_csJobDirectory+csJobFileName,TRUE)==0)
		{
			pUtil->ErrorMessage("Can Not Copy Over An Existing File");
			delete pUtil;
			return;


		}
	}
	IsModified();
	JobInfo JobRecord;
	JobRecord.Name = m_Grid.GetItemText(m_nCurrentRow,JOBNAME);
	JobRecord.Customer  = m_Grid.GetItemText(m_nCurrentRow,COMPANY);
	JobRecord.ProductDescription   = m_Grid.GetItemText(m_nCurrentRow,PRODUCT);

	pUtil->SetJobFileInfo(csJobFileName,&JobRecord); 
	if (!csJobFileName.IsEmpty())
		SetJobName(csJobFileName);
	delete pUtil;
	
	CDialog::OnOK();
}

BOOL CCopyJobDlg::IsModified()
{
CString csTemp;
int nFixedRows=m_Grid.GetFixedRowCount();

	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nFixedRows ,nColumn);
				csTemp.Empty(); 
				csTemp=pCell->GetText();
				if (csTemp.IsEmpty()) return FALSE; 

				if (pCell->IsModified())
					return TRUE;
				if( pCell->IsSelected() )
				{
					pCell->EndEdit();
					if (pCell->IsModified())
						return TRUE;
				}

		}
	}
	return FALSE;
}

CString CCopyJobDlg::GetJobName()
{
	return m_csJobName;
}
void CCopyJobDlg::SetJobName(CString csJobName)
{

	m_csJobName=csJobName;
}
