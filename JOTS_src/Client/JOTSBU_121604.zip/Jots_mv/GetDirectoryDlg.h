#if !defined(AFX_GETDIRECTORYDLG_H__9E48D0E1_555D_4E28_BD78_DC4EC2E6E4C8__INCLUDED_)
#define AFX_GETDIRECTORYDLG_H__9E48D0E1_555D_4E28_BD78_DC4EC2E6E4C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GetDirectoryDlg.h : header file
//
#include "BrowseCtrl.h"
/////////////////////////////////////////////////////////////////////////////
// CGetDirectoryDlg dialog

class CGetDirectoryDlg : public CDialog
{
// Construction
public:
	CGetDirectoryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGetDirectoryDlg)
	enum { IDD = IDD_GET_DIR };
	CBrowseCtrl	m_btnGetDirectory;
	//}}AFX_DATA
	void	SetDirectory(CString csDirectory);
	CString	GetDirectory();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetDirectoryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGetDirectoryDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	afx_msg LRESULT OnFileCtrlNotify(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	CString				m_csDirectory;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETDIRECTORYDLG_H__9E48D0E1_555D_4E28_BD78_DC4EC2E6E4C8__INCLUDED_)
