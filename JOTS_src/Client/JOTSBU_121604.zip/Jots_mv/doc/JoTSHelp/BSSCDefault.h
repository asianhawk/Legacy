#ifndef __HELP_SUPPORT_FILE
#define __HELP_SUPPORT_FILE

#define HID_BTN_EXIT                            0x10444
#define HID_BTN_HOLD                            0x10003
#define HID_BTN_TEST                            0x10003
#define HID_EDIT_JOB_LABELS                     0x1801E
#define HID_EDIT_JOB_NAME                       0x1801D
#define HID_EDIT_JOB_RUN                        0x1801F
#define HID_EDIT_WND                            0x1006E
#define HID_FILE_EXPORT                         0x18007
#define HID_FILE_IMPORT                         0x18006
#define HID_FILE_JOBS_NEW                       0x18004
#define HID_FILE_JOBS_OPEN                      0x18005
#define HID_RUN_BATCH                           0x18020
#define HID_RUN_SINGLE                          0x18008
#define HID_SETUP_CUSTOM_BASENUMBER             0x1801B
#define HID_SETUP_DATASOURCES_FLAT_FILE         0x18016
#define HID_SETUP_DATASOURCES_ODBC              0x18015
#define HID_SETUP_KEYWORDS                      0x1801C
#define HID_SETUP_LOGGING                       0x18029
#define HID_SETUP_MORPHOR_NETWORK               0x1800D
#define HID_SETUP_MORPHOR_SERIAL                0x1800C
#define HID_SETUP_PRINTER                       0x18027
#define HID_SETUP_PRINTER_LOAD                  0x18023
#define HID_SETUP_PRINTER_SAVE                  0x18022
#define HID_SETUP_PRINTER_TEST                  0x18024
#define HID_SETUP_PRINTER_VIEW                  0x18021
#define HID_SETUP_SCANNER_DIAGNOSTIC            0x18026
#define HID_SETUP_SCANNER_EDIT                  0x18025
#define HID_SETUP_SECURITY_ACCESS_RIGHTS        0x18010
#define HID_SETUP_SECURITY_USER                 0x1800F
#define HID_SETUP_SERIALIZATION                 0x1801A
#define HID_SETUP_SYSTEM                        0x18017
#define HID_SETUP_TEMPLATE                      0x18028
#define HID_SETUP_TEMPLATES_EDITOR              0x18019
#define HIDD_ABOUTBOX                           0x20064

#define HIDD_ACCESS_RIGHTS                      0x2008B
#define HIDD_ADDJOB_STEP1                       0x20094
#define HIDD_ADDJOB_STEP2                       0x20095
#define HIDD_ADDJOB_STEP2A                      0x2009B
#define HIDD_ADDJOB_STEP3                       0x20096
#define HIDD_ADDJOB_STEP4                       0x20097
#define HIDD_ADDJOB_STEP5                       0x20098
#define HIDD_ADDJOB_STEP6                       0x20099
#define HIDD_ADDJOB_STEP7                       0x2009A
#define HIDD_ADDJOB_STEP8                       0x2009C
#define HIDD_DATA_SERIES                        0x2009D
#define HIDD_DIALOG1                            0x2008F
#define HIDD_DIALOG2                            0x20090
#define HIDD_DIALOG3                            0x2009F
#define HIDD_FORMVIEW                           0x20065
#define HIDD_JOBVIEW_FORM                       0x2006B
#define HIDD_LABELS                             0x2008E
#define HIDD_MAIN_LABELS                        0x20091
#define HIDD_MAIN_RUN                           0x20093
#define HIDD_MAIN_TEMPLATES                     0x20092
#define HIDD_MESSAGE_BOX                        0x2009F
#define HIDD_RUN                                0x200A3
#define HIDD_SETUP_TCP                          0x200A2
#define HIDD_USER_ACCOUNT                       0x2008D
#define HIDD_USERS_LIST                         0x20082
#define HIDD_VARIABLE_DATA                      0x2009E
#define HIDP_SOCKETS_INIT_FAILED                0x30068
#define HIDR_APPLICATION                        0x20067
#define HIDR_COLOREDITCTX                       0x2009D
#define HIDR_DOCUMENT                           0x20069
#define HIDR_JOBVIEW_TMPL                       0x2006C
#define HIDR_JOTS                               0x20066
#define HIDR_JOTSTYPE                           0x20081
#define HIDR_MAINFRAME                          0x20080
#define HIDR_MAINMENU                           0x2008A
#define HIDR_MAINVIEW                           0x2006D
#define HIDR_SERVICES                           0x2006F
#define HIDR_VIEW                               0x2006A


#define HIDC_TXB_JOBNAME				1058
#define HIDC_TXB_CUSTOMER				1059
#define HIDC_TXB_PRODUCT				1005
#define HIDC_TXB_NOOFLABELS				1027
#define HIDC_TXB_NOOFREPRINTS				1026
#define HIDC_TXB_NOOFRESCANS				1028
#define HIDC_CHK_EXTERNAL_LOG_DATA			1046


#define HIDC_TXB_INDEX_NAME				1050
#define HIDC_CMB_SCHEMA					1049
#define HIDC_TXB_SSN					1051
#define HIDC_TXB_MSN					1024
#define HIDC_TXB_ROLL_VALUE				1025
#define HIDC_TXB_MAXWIDTH				1052
#define HIDC_CHK_EXTERNAL_NO_DUPLICATES			1044
#define HIDC_CMB_CHKDIGIT				1040
#define HIDC_TXB_STEP_SIZE				1054
#define HIDC_TXB_DATA_SERIES				1060



#define HIDC_GRID_PRINT_ORDER				2000
#define HIDC_TEMPLATE_NAME				2001
#define HIDC_SCAN_LABEL					2002
#define HIDC_VERIFY_LABEL				2003
#define HIDC_ROTATION_ANGLE				2004
#define HIDC_STATIC_INDEX				2005



#endif