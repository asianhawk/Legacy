#if !defined(AFX_MSGDIALOG_H__63B05E94_45F0_463D_93F8_6C3BAE2D407C__INCLUDED_)
#define AFX_MSGDIALOG_H__63B05E94_45F0_463D_93F8_6C3BAE2D407C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MsgDialog.h : header file
//
#include "resource.h"
/////////////////////////////////////////////////////////////////////////////
// CMsgDialog dialog

#define YES_OR_NO			4
#define ERRORLEVEL_1		1
#define ERRORLEVEL_2		2
#define ERRORLEVEL_3		3

class CMsgDialog : public CDialog
{
// Construction
public:
	CMsgDialog(CWnd* pParent = NULL);   // standard constructor
	int m_nMsgType;
	CString m_csTitle;

// Dialog Data
	//{{AFX_DATA(CMsgDialog)
	enum { IDD = IDD_MESSAGE_BOX };
	CButton	m_btnCancel;
	CButton	m_btnOK;
	CString	m_csMessage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsgDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsgDialog)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void SetCmdButtons();
	BOOL GetContinue();
	void SetContinue(BOOL blnContinue); 
private:
	BOOL m_blnContinue;
	CString m_csCaption;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSGDIALOG_H__63B05E94_45F0_463D_93F8_6C3BAE2D407C__INCLUDED_)
