#if !defined(AFX_RUNDLG_H__EC215F4C_E69C_4F06_AF03_2AF7BBB7A8B7__INCLUDED_)
#define AFX_RUNDLG_H__EC215F4C_E69C_4F06_AF03_2AF7BBB7A8B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RunDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRunDlg dialog

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

class CRunDlg : public CDialog
{
// Construction
public:
	void UpdateDisplay();
	CString GetStatus();
	void SetStatus(CString csStatus);
	CRunDlg(CWnd* pParent = NULL);   // standard constructor
	BOOL	GetHoldStatus();		// determine if job is in hold or not
	void YieldToWindows (void);
	void Init();
	void InitControls();
	BOOL ExitRun();

// Dialog Data
	//{{AFX_DATA(CRunDlg)
	enum { IDD = IDD_RUN };
	CShadeButtonST	m_btnExit;
	CStatic	m_lblCount;
	CShadeButtonST	m_btnHold;
	CString	m_csStatus;
	CString	m_csLabelCount;
	CString	m_csCurrentIndex;
	CString	m_csBarCodeValue;
	CString	m_csStepSize;
	CString	m_csScannedBarcode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRunDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRunDlg)
	afx_msg void OnBtnHold();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBtnExit();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CRunDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
private:
	BOOL m_blnJobHold;
	BOOL m_blnExit;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RUNDLG_H__EC215F4C_E69C_4F06_AF03_2AF7BBB7A8B7__INCLUDED_)
