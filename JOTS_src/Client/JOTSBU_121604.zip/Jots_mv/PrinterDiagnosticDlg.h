#if !defined(AFX_PRINTERDIAGNOSTICDLG_H__1D36E888_CD0B_4394_AA37_857A600FCF30__INCLUDED_)
#define AFX_PRINTERDIAGNOSTICDLG_H__1D36E888_CD0B_4394_AA37_857A600FCF30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PrinterDiagnosticDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"
/////////////////////////////////////////////////////////////////////////////
// CPrinterDiagnosticDlg dialog

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

#include "LMorphor3.h"


class CPrinterDiagnosticDlg : public CDialog
{
// Construction
public:
	CPrinterDiagnosticDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPrinterDiagnosticDlg();
// Dialog Data
	//{{AFX_DATA(CPrinterDiagnosticDlg)
	enum { IDD = IDD_PRINTER_DLG };
	CShadeButtonST	m_btnSave;
	CShadeButtonST	m_btnOK;
	CShadeButtonST	m_btnDisplayCurrent;
	CStatic	m_lblTitle;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrinterDiagnosticDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPrinterDiagnosticDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/);
	afx_msg void OnBtnGetcurrentFps();
	afx_msg void OnBtnSaveFps();
	afx_msg void OnPrintersettingsTransmit();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CPrinterDiagnosticDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
private:

	CGridCtrl			m_Grid;
	CLMorphor3			*m_pMorphor;
	CString				m_csLastError;
	BOOL				m_blnMorphorReady;
	CString				m_csLastPrinterSettings;
	CString				m_csBaselinePrinterSettings;

	ZebraSetting		*m_pPrinterSettings;
	ZebraSetting		m_oPrinterSettings[MAXPRINTERPARAMETERS];
	int					m_nCurrentRow;
	int					m_nCurrentCol;

public:
	
	void				InitGrid();
	void				InitControls();
	void				InitLabelMorphor();
	BOOL				IsLabelMorphorReady();
	BOOL				OpenLabelMorphor();
	BOOL				CloseLabelMorphor();
	CString				GetLastErrorMsg();
	void				SetLastErrorMsg(CString csErrorMessage);
	BOOL				WaitForResponse(int nTimeOut);
	BOOL				ReadFps(); 

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRINTERDIAGNOSTICDLG_H__1D36E888_CD0B_4394_AA37_857A600FCF30__INCLUDED_)
