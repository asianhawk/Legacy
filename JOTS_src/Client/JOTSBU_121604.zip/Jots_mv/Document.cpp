// Document.cpp : Implementation of CDocument
#include "stdafx.h"
#include "JoTS.h"
#include "Document.h"

/////////////////////////////////////////////////////////////////////////////
// CDocument

