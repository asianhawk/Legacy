// BuildZPLDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "BuildZPLDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBuildZPLDlg dialog


CBuildZPLDlg::CBuildZPLDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBuildZPLDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBuildZPLDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBuildZPLDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBuildZPLDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBuildZPLDlg, CDialog)
	//{{AFX_MSG_MAP(CBuildZPLDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBuildZPLDlg message handlers
