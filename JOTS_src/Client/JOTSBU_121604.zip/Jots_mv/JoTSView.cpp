// JoTSView.cpp : implementation of the CJoTSView class
//

#include "stdafx.h"
#include "JoTS.h"

#include "JoTSDoc.h"
#include "JoTSView.h"

#include "UserAccessDlg.h"

#include "DisplayTemplatesDlg.h"
#include "DisplayLabelsDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_TABCTRL	1111			// id for the CTabCtrl
/////////////////////////////////////////////////////////////////////////////
// CJoTSView

IMPLEMENT_DYNCREATE_ATL(CJoTSView, CView)

BEGIN_MESSAGE_MAP(CJoTSView, CView)
	//{{AFX_MSG_MAP(CJoTSView)
	ON_COMMAND(ID_FILE_JOBS_NEW, OnFileJobsNew)
	ON_COMMAND(ID_FILE_JOBS_OPEN, OnFileJobsOpen)
	ON_COMMAND(ID_RUN_BATCH, OnRunBatch)
	ON_COMMAND(ID_RUN_SINGLE, OnRunSingle)
	ON_COMMAND(ID_SETUP_CUSTOM_BASENUMBER, OnSetupCustomBasenumber)
	ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
	ON_COMMAND(ID_FILE_IMPORT, OnFileImport)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_COMMAND(ID_SETUP_DATASOURCES_FLAT_FILE, OnSetupDatasourcesFlatFile)
	ON_COMMAND(ID_SETUP_DATASOURCES_ODBC, OnSetupDatasourcesOdbc)
	ON_COMMAND(ID_SETUP_KEYWORDS, OnSetupKeywords)
	ON_COMMAND(ID_SETUP_LOGGING, OnSetupLogging)
	ON_COMMAND(ID_SETUP_MORPHOR_NETWORK, OnSetupMorphorNetwork)
	ON_COMMAND(ID_SETUP_MORPHOR_SERIAL, OnSetupMorphorSerial)
	ON_COMMAND(ID_SETUP_PRINTER, OnSetupPrinter)
	ON_COMMAND(ID_SETUP_PRINTER_LOAD, OnSetupPrinterLoad)
	ON_COMMAND(ID_SETUP_PRINTER_SAVE, OnSetupPrinterSave)
	ON_COMMAND(ID_SETUP_PRINTER_TEST, OnSetupPrinterTest)
	ON_COMMAND(ID_SETUP_PRINTER_VIEW, OnSetupPrinterView)
	ON_COMMAND(ID_SETUP_SCANNER_DIAGNOSTIC, OnSetupScannerDiagnostic)
	ON_COMMAND(ID_SETUP_SCANNER_EDIT, OnSetupScannerEdit)
	ON_COMMAND(ID_SETUP_SECURITY_ACCESS_RIGHTS, OnSetupSecurityAccessRights)
	ON_COMMAND(ID_SETUP_SECURITY_USER, OnSetupSecurityUser)
	ON_COMMAND(ID_SETUP_SERIALIZATION, OnSetupSerialization)
	ON_COMMAND(ID_SETUP_SYSTEM, OnSetupSystem)
	ON_COMMAND(ID_SETUP_TEMPLATE, OnSetupTemplate)
	ON_COMMAND(ID_SETUP_TEMPLATES_EDITOR, OnSetupTemplatesEditor)
	ON_COMMAND(ID_EDIT_JOB_LABELS, OnEditJobLabels)
	ON_COMMAND(ID_EDIT_JOB_NAME, OnEditJobName)
	ON_COMMAND(ID_EDIT_JOB_RUN, OnEditJobRun)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_FILE_CLOSE, OnFileClose)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTSView construction/destruction

CJoTSView::CJoTSView()
{
	// TODO: add construction code here

}

CJoTSView::~CJoTSView()
{
}

BOOL CJoTSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSView drawing

void CJoTSView::OnDraw(CDC* pDC)
{
    pDC->BitBlt(0,0,m_nBmpWidth,m_nBmpHeight,
        &m_MemDC,0,0,SRCCOPY);


	CJoTSDoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSView printing

BOOL CJoTSView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CJoTSView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CJoTSView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSView diagnostics

#ifdef _DEBUG
void CJoTSView::AssertValid() const
{
	CView::AssertValid();
}

void CJoTSView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CJoTSDoc* CJoTSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJoTSDoc)));
	return (CJoTSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJoTSView message handlers

void CJoTSView::OnFileJobsNew() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileJobsOpen() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnRunBatch() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnRunSingle() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupCustomBasenumber() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileExport() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileImport() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileSave() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnFileSendMail() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupDatasourcesFlatFile() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupDatasourcesOdbc() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupKeywords() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupLogging() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupMorphorNetwork() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupMorphorSerial() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupPrinter() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupPrinterLoad() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupPrinterSave() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupPrinterTest() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupPrinterView() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupScannerDiagnostic() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupScannerEdit() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupSecurityAccessRights() 
{
  UserAccessDlg *dlg;
  dlg = new UserAccessDlg();
  
  dlg->DoModal(); 
	
}

void CJoTSView::OnSetupSecurityUser() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupSerialization() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupSystem() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupTemplate() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnSetupTemplatesEditor() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnEditJobLabels() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnEditJobName() 
{
	// TODO: Add your command handler code here
	
}

void CJoTSView::OnEditJobRun() 
{
	// TODO: Add your command handler code here
	
}

STDMETHODIMP CJoTSView::Edit_Job_Information()
{
	METHOD_PROLOGUE_ATL

	OnSetupSecurityAccessRights();

	return S_OK;
}

void CJoTSView::OnInitialUpdate() 
{
//	CView::OnInitialUpdate();
	
    CDC *pDC = this->GetDC();

    m_MemDC.CreateCompatibleDC(pDC);

    m_bmpView.LoadBitmap(IDB_BITMAP);    
 
    m_MemDC.SelectObject(&m_bmpView);

    BITMAP Bitmap;
    m_bmpView.GetBitmap(&Bitmap);

    m_nBmpHeight = Bitmap.bmHeight;
    m_nBmpWidth = Bitmap.bmWidth;

    CSize size(m_nBmpWidth,m_nBmpHeight);

    this->ReleaseDC(pDC);    	
}

int CJoTSView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Create a tab control which is a child window of the CTabView and
	// whose size will be determined in CTabView::OnSize().
	m_TabCtrl = new CTabCtrl;
	ASSERT(m_TabCtrl);

	if (m_TabCtrl->Create(
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, 
		CRect(0, 0, 0, 0), this, ID_TABCTRL) == FALSE)
		return -1;

	// Create all pages for the tab control.
	CreatePages();
	return 0;
}
#include "Dialog1.h"				// page one

void CJoTSView::CreatePages()
{
	CDialog*	dlg;
	// Create page one and add it to dialog array.
	dlg = new CDisplayLabelsDlg;
	ASSERT(dlg);
	m_DlgArray.Add(dlg);
	VERIFY(dlg->Create(IDD_MAIN_LABELS, m_TabCtrl));


	// Determine the tab text.  The tab text can be found from the 
	// dialog template.
	char str[50];
	TC_ITEM tci;
	tci.mask	= TCIF_TEXT;
	tci.iImage	= -1;
	for (int i = 0; i < 1; i++)
	{	
		// Get the caption from dialog template and insert this caption
		// to the tab control.
		dlg = m_DlgArray[i];
		dlg->GetWindowText(str, sizeof(str));
		tci.pszText	= str;
		m_TabCtrl->InsertItem(i, &tci);

		// Remove caption from the dialog box because no caption is allowed
		// for pages in the tab control.
		dlg->ModifyStyle(WS_CAPTION, 0);

		// IMPORTANT: Why sending a WM_NCACTIVATE message to the dialog box?
		// When writing this sample, we found a problem which is related to
		// the edit control refuses to give up the input focus when mouse is 
		// being clicked on some other edit control.  This problem only 
		// happens when title bar is found from a dialog resource.  And we
		// need the title bar because it is the text in the tab control.  
		// Sending a WM_NCACTIVATE message seems to fix the problem.
		dlg->SendMessage(WM_NCACTIVATE, TRUE);
	}



}

void CJoTSView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	m_TabCtrl->MoveWindow(0, 0, cx, cy);
	
}

void CJoTSView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	OnTabSelChange(NULL, NULL);
	
}

void CJoTSView::OnTabSelChange(NMHDR* pnmhdr, LRESULT* pResult)
{
	// Get the rectangle size of the tab control so we know the position 

	// and size of the page that will be shown.
	RECT rc;
	m_TabCtrl->GetItemRect (0, &rc);

	// Call GetCurSel() will return the index of the page that is newly
	// selected.  This page will be visible soon.
	int sel_index = m_TabCtrl->GetCurSel();
	m_DlgArray[sel_index]->SetWindowPos (
		NULL, 
		rc.left + 5, rc.bottom + 5, 0, 0, 
		SWP_NOSIZE | SWP_NOZORDER | SWP_SHOWWINDOW);
	
	// Set input focus to this page.
	m_DlgArray[sel_index]->SetFocus();

//	*pResult = TRUE;	// no return value according to online documentation
}	

void CJoTSView::OnFileClose() 
{

	
}
