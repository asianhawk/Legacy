// JoTSATLDoc.cpp : implementation of the CJoTSATLDoc class
//

#include "stdafx.h"
#include "JoTSATL.h"

#include "JoTSATLDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLDoc

IMPLEMENT_DYNCREATE_ATL(CJoTSATLDoc, CDocument)

BEGIN_MESSAGE_MAP(CJoTSATLDoc, CDocument)
	//{{AFX_MSG_MAP(CJoTSATLDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLDoc construction/destruction

CJoTSATLDoc::CJoTSATLDoc()
{
	// TODO: add one-time construction code here

}

CJoTSATLDoc::~CJoTSATLDoc()
{
}

HRESULT
CJoTSATLDoc::FinalConstruct()
{
	METHOD_PROLOGUE_ATL

	CJoTSATLApp* pApp = (CJoTSATLApp*)AfxGetApp();
	ASSERT_VALID(pApp);

	// Find document template
	POSITION pos = pApp->GetFirstDocTemplatePosition();
	CAnotherMultiDocTemplate* pDocClass = (CAnotherMultiDocTemplate*)pApp->GetNextDocTemplate(pos);
	ASSERT_VALID(pDocClass);

	// Create view and frame
	pDocClass->m_pDocument = this;
	pDocClass->OpenDocumentFile(NULL, true);

	return S_OK;
}

void
CJoTSATLDoc::FinalRelease()
{
	// Do will still have a View connected?
	// (The frame will no longer exist if the document
	// has been closed by manually, because the OnClose
	// message is passed BEFORE deleting the document)
	POSITION pos = GetFirstViewPosition();
	if (pos != NULL) {
		// Prevent the document from deleting itself already.
		m_bAutoDelete = false;
		OnCloseDocument();
		m_bAutoDelete = true;
	}
}

BOOL CJoTSATLDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CJoTSATLDoc serialization

void CJoTSATLDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLDoc diagnostics

#ifdef _DEBUG
void CJoTSATLDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CJoTSATLDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJoTSATLDoc commands

STDMETHODIMP CJoTSATLDoc::Hello()
{
	METHOD_PROLOGUE_ATL

	::MessageBox(NULL, GetTitle(), "Hello World", MB_OK | MB_ICONEXCLAMATION);

	return S_OK;
}
