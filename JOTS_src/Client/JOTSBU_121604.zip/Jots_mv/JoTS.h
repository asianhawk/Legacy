// JoTS.h : main header file for the JOTS application
//

#if !defined(AFX_JOTS_H__2C3828CF_F2F9_4B16_BE75_E6F489E1AD1A__INCLUDED_)
#define AFX_JOTS_H__2C3828CF_F2F9_4B16_BE75_E6F489E1AD1A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif
#include "resource.h"       // main symbols
#include "JoTS_i.h"
#include "MsgDialog.h"

#define BUTTON_IN_ACTIVE_COLOR		RGB(255,5,0)
#define BUTTON_OUT_ACTIVE_COLOR		RGB(10,10,10)
#define TIMER_COLOR					RGB(100,20,200)


#define	TOOLTIP_FADEOUT		50
#define DEFCOLOR		14811135

#define UWM_RESET_VIEW (WM_APP + 200)
#define UWM_UPDATE_TEMPLATE (WM_APP + 201)


#include "htmlhelp.h"
#include "BSSCDefault.h"

static const DWORD aMenuHelpIDs[] =
{
	
	IDD_ADDJOB_STEP1, HIDD_ADDJOB_STEP1,
		0,0
};

// define tool tip CONST's

#define  BEGINTIPCOLOR			16710068
#define  MIDTIPCOLOR			16052108
#define  ENDTIPCOLOR			15392540




#define CW_ROTATION			0
#define CCW_ROTATION		1	

// BEGIN TCP CONSTANTS

#define		SERIALCONNECTION		0
#define		TCPCONNECTION			1

#define		PASSTHRU				0
#define		CMDLANGINTERPRET		1
#define		NOTREADY				0	
#define		READY					1	

// END TCP CONSTANTS


#define		IDLE					0x000000000
#define		RUN						0x000000010
#define		HOLD					0x000000100
#define		LM3ERROR				0x000001000
#define		WAITINGFORLM3			0x000010000
#define		LABELCOMPLETE			0x000100000
#define		SCANERROR				0x001000000
#define		PRINTERROR				0x010000000
#define		COMPLETE				0x100000000


#define		MAXJOBS		10	

#define		MAXLABELS   10			//per job
#define		MAXDATASERIES  10		//per job
#define		MAXTEMPLATES	20		// perjob
#define		MAXREPRINTS		10
#define		MAXRESCANS		10
#define		MAXNUMBERBASES  50
#define		MAXCONPARAMETERS	50
#define		MAXPRINTERPARAMETERS 50


#define		MAXVARS			50		// perjob


typedef struct ZebraSetting
{
	CString		Name;
	CString		Description;
	CString		ZPLCmd;
	CString		NumberOfArgs;
	CString		Value;


}ZebraSettings; 





typedef struct ComPort
{
	CString		Name;
	CString		BaudRate;
	CString		Parity;

	int			Wordlength;
	int			StopBits;

}SerialPortData; 


typedef struct Scanners
{
	CString		ID;
	CString		PreTriggerDelay;
	CString		PostScanMaxTimeout;

}Scanner; 




#include "AutoFont.h"
//#include "Utilities.h"

#include "ConfigDlg.h"
#include "BaseSchemaDlg.h"
#include "TemplateEditorDlg.h"

struct NumberBases
{
	CString BaseName;
	CString Table;

};



struct DataSeries
{
	CString Name;
	CString BaseNumberSchema;
	CString FieldWidth;
	CString StepSize;
	CString StartingSequencNumber;
	CString MaxSequenceNumber;
	CString RollOverValue;
	CString AllowDuplicates;
	CString CheckDigit;
	CString Static;

}; 

struct LabelInfo
{
	CString TemplateName;
	CString PrintOrder;
	CString ScanLabel;
	CString VerifyLabel;
	CString RotationAngle;

} ; 

struct BC_Vars
{
	CString Name;
	CString Prefix;
	CString Suffix;
	CString Data;

}; 

struct HR_Vars
{
	CString Name;
	CString Prefix;
	CString Suffix;
	CString Data;

}; 

struct TemplateVariables
{
	CString Name;
	HR_Vars HRVars[MAXVARS];
	BC_Vars BCVars[MAXVARS];

}; 




struct JobInfo
{
	CString Name;
	CString Customer;
	CString ProductDescription;
	CString NoOfLabels;
	CString Reprints;
	CString Rescans;
	BOOL	LogData;

	BOOL	SerializedData;
	BOOL	ExternalDataSource;
	int		NoOfDataSeries;

	DataSeries  SerialData[MAXDATASERIES]; 
	LabelInfo	LabelInfo[MAXLABELS]; 
	TemplateVariables Templates[MAXTEMPLATES];

}; 






// CAutoATLApp:
class CJoTSApp : public CWinApp, 
 	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CJoTSApp, &CLSID_Application>,
	public IConnectionPointContainerImpl<CJoTSApp>,
	public IDispatchImpl<IApplication, &IID_IApplication, &LIBID_JoTS>

{
public:
	STDMETHOD(get_Services)(/*[out, retval]*/ IMain* *pVal);
	STDMETHOD(Terminate)();
	STDMETHOD(get_Visible)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_Visible)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_ActiveDocument)(/*[out, retval]*/ IJobRecord* *pVal);
 CJoTSApp();
 BOOL IsSystemIntegrityOK();

 DECLARE_CLASSFACTORY_SINGLETON(CJoTSApp)

DECLARE_REGISTRY_RESOURCEID(IDR_APPLICATION)
DECLARE_NOT_AGGREGATABLE(CJoTSApp)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CJoTSApp)
 COM_INTERFACE_ENTRY(IApplication)
 COM_INTERFACE_ENTRY(IDispatch)
 COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CJoTSApp)
END_CONNECTION_POINT_MAP()

// Overrides
 //{{AFX_VIRTUAL(CJoTSApp)
	public:
 virtual BOOL InitInstance();
 virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	virtual int ExitInstance();
	//}}AFX_VIRTUAL



// Implementation
 //{{AFX_MSG(CJoTSApp)
 afx_msg void OnAppAbout();
 afx_msg void OnFileNew();
 afx_msg void OnFileOpen();
	afx_msg void OnHelp();
	afx_msg void OnSetupSecurityUser();
	afx_msg void OnSetupSystemconfiguration();
	afx_msg void OnSetupCustomBasenumber();
	afx_msg void OnSetupTemplatesEditor();
	afx_msg void OnSetupPrinterView();
	afx_msg void OnUpdateAIK();
	//}}AFX_MSG
 DECLARE_MESSAGE_MAP()

virtual void WinHelp(DWORD dwData, UINT nCMD = HELP_CONTEXT);
};

////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOTS_H__2C3828CF_F2F9_4B16_BE75_E6F489E1AD1A__INCLUDED_)
