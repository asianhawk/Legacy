#if !defined(AFX_ADDJOBSTEP2_H__64912991_F545_461A_BE16_CB594EEEED29__INCLUDED_)
#define AFX_ADDJOBSTEP2_H__64912991_F545_461A_BE16_CB594EEEED29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep2.h : header file
//
#include "Edit Class Ex/amsEdit.h"
#include "tooltip/PPTooltip.h"
/////////////////////////////////////////////////////////////////////////////
// CAddJobStep2 dialog


#define	TOOLTIP_FADEOUT		50



#define DEFCOLOR		14811135


class CAddJobStep2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep2)

// Construction
public:
	CAddJobStep2();
	~CAddJobStep2();
	void InitControls();
	BOOL VerifyData();
	BOOL GetInitStatus();
	void SetInitStatus(BOOL blnStatus);
	void SetToolTipsProperties();
	void CreateToolTips();

// Dialog Data
	//{{AFX_DATA(CAddJobStep2)
	enum { IDD = IDD_ADDJOB_STEP2 };
	CButton	m_chkLogData;
	CSpinButtonCtrl	m_spnAutoRescans;
	CSpinButtonCtrl	m_spnAutoReprints;
	CSpinButtonCtrl	m_spnNumberOfLabels;
	CAMSNumericEdit			m_txbNoOfRescans;
	CAMSNumericEdit			m_txbNoOfReprints;
	CAMSNumericEdit			m_txbNoOfLabels;
	CAMSAlphanumericEdit	m_txbProduct;
	CAMSAlphanumericEdit	m_txbCustomer;
	CAMSAlphanumericEdit	m_txbJobName;
	BOOL	m_blnLogData;
	CString	m_csCustomer;
	CString	m_csJobName;
	CString	m_csNoOfLabels;
	CString	m_csNoOfReprints;
	CString	m_csNoOfRescans;
	CString	m_csProductDescription;
	CString	m_csLabelCustomer;
	CString	m_csProduct;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep2)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep2)
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CPPToolTip 		m_Tip;
	CString			m_csJobNameTip;
	long			m_lngColorGrad1;
	long			m_lngColorGrad2;
	long			m_lngColorGrad3;

	HICON			m_hIcon1;
	HICON			m_hIcon2;
	HICON			m_hIcon3;
	BOOL			m_blnErrorIniting;


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP2_H__64912991_F545_461A_BE16_CB594EEEED29__INCLUDED_)
