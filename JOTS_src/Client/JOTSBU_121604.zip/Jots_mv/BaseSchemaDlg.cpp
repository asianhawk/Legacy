// BaseSchemaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "BaseSchemaDlg.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBaseSchemaDlg dialog


#define	  BASENAME			0
#define	  BASESET			1	

CBaseSchemaDlg::CBaseSchemaDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBaseSchemaDlg::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CBaseSchemaDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBaseSchemaDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CBaseSchemaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBaseSchemaDlg)
	DDX_Control(pDX, IDC_LBL_TITLE, m_lblTitle);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBaseSchemaDlg, CDialog)
	//{{AFX_MSG_MAP(CBaseSchemaDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	ON_COMMAND(ID_SETUP_CUSTOM_BASENUMBER, OnSetupCustomBasenumber)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CBaseSchemaDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CBaseSchemaDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IBaseSchemaDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {4F43C071-C09D-4C94-9AF5-46C839478C57}
static const IID IID_IBaseSchemaDlg =
{ 0x4f43c071, 0xc09d, 0x4c94, { 0x9a, 0xf5, 0x46, 0xc8, 0x39, 0x47, 0x8c, 0x57 } };

BEGIN_INTERFACE_MAP(CBaseSchemaDlg, CDialog)
	INTERFACE_PART(CBaseSchemaDlg, IID_IBaseSchemaDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBaseSchemaDlg message handlers



void CBaseSchemaDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{

  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    

}

void CBaseSchemaDlg::InitGrid() 
{
CStringArray options,
			 csaTemplates;
CUtilities *pUtil;
NumberBases *pBaseSchema;
int nBaseCount=0;

	m_Grid.SetFixedRowCount(1);
	m_Grid.SetRowCount(MAXNUMBERBASES + m_Grid.GetFixedRowCount());		//Data Rows

	m_Grid.SetColumnCount(2);
	m_Grid.SetFixedColumnCount(0);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE); 




    m_Grid.SetItemText(0,BASENAME,"   Name   ");

    m_Grid.SetItemText(0,BASESET,"Value");
	

	
	pUtil = new CUtilities();

	// Printer Time Out
	pBaseSchema=pUtil->GetNumberBases();

	while (!pBaseSchema[nBaseCount].BaseName.IsEmpty() )
	{
		m_Grid.SetItemText(nBaseCount+m_Grid.GetFixedRowCount(),BASENAME,pBaseSchema[nBaseCount].BaseName);
		m_Grid.SetItemText(nBaseCount+m_Grid.GetFixedRowCount(),BASESET,pBaseSchema[nBaseCount].Table);
		nBaseCount++;
	}
	
	delete pUtil;
	
	for (int nCount =0;nCount<m_Grid.GetRowCount() ; nCount++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			m_Grid.SetItemFormat(nCount,nColumn,DT_LEFT|DT_VCENTER);
		
		}
	}


	m_Grid.ExpandLastColumn();       
	m_Grid.Refresh(); 
	
	


	

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);
	m_Grid.SetModified(FALSE); 

	

}

BOOL CBaseSchemaDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitGrid();	
	InitControls();	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CBaseSchemaDlg::InitControls()
{

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format label controls
	
	m_btnOK.SetFont(&font);
	m_btnOK.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnOK.SetIcon(IDI_OK);
	m_btnOK.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnCancel.SetFont(&font);
	m_btnCancel.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnCancel.SetIcon(IDI_CANCEL1);
	m_btnCancel.SetAlign(CButtonST::ST_ALIGN_HORIZ);

	m_lblTitle.SetFont(&font); 
}

void CBaseSchemaDlg::OnOK() 
{
CString csTemp;
NumberBases BaseSchema[MAXNUMBERBASES];
int nRow,
	nDataRow;
	CUtilities *pUtil = new CUtilities();
	
	if(m_Grid.GetModified())
	{
		for(nRow=0;nRow<m_Grid.GetRowCount();nRow++)
		{
			nDataRow=nRow+m_Grid.GetFixedRowCount();
			if (m_Grid.GetItemText(nDataRow,0).IsEmpty()) break;
				
			BaseSchema[nRow].BaseName= m_Grid.GetItemText(nDataRow ,BASENAME);
			if (m_Grid.GetItemText(nDataRow,BASESET).IsEmpty())
			{
				csTemp.Format("Error With [%s]",BaseSchema[nRow].BaseName);
				pUtil->ErrorMessage("Base Numbering Set Can Not Be Blank",csTemp);
				return;
			}
			BaseSchema[nRow].Table = m_Grid.GetItemText(nDataRow,BASESET);


		}
		pUtil->SetBaseNumber(BaseSchema); 
	}
	delete pUtil;

	CDialog::OnOK();
}



void CBaseSchemaDlg::OnSetupCustomBasenumber() 
{

	
}
