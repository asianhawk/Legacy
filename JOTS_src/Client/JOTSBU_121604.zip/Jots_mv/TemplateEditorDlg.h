#if !defined(AFX_TEMPLATEEDITORDLG_H__4EC44DF4_3F24_4DD0_8CFA_DFA1E0C1A2E6__INCLUDED_)
#define AFX_TEMPLATEEDITORDLG_H__4EC44DF4_3F24_4DD0_8CFA_DFA1E0C1A2E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TemplateEditorDlg.h : header file
//
#include "CCrystalEditControl.h"

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

/////////////////////////////////////////////////////////////////////////////
// CTemplateEditorDlg dialog

class CTemplateEditorDlg : public CDialog
{
// Construction
public:
	CTemplateEditorDlg(CWnd* pParent = NULL);   // standard constructor
	CCrystalEditControl m_ScriptEditor;
	CCrystalTextBuffer m_ScriptBuffer ;
	void GetTemplates();
	void InitControls();
	void PurgeBuffer();
// Dialog Data
	//{{AFX_DATA(CTemplateEditorDlg)
	enum { IDD = IDD_TEMPLATE_EDITOR };
	CShadeButtonST	m_btnExit;
	CShadeButtonST	m_btnDelete;
	CShadeButtonST	m_btnSaveAs;
	CShadeButtonST	m_btnSave;
	CComboBox	m_cmbTemplates;
	CShadeButtonST	m_btnOpenTemplate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTemplateEditorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTemplateEditorDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnOpenTemplate();
	afx_msg void OnBtnSave();
	afx_msg void OnBtnSaveAs();
	afx_msg void OnBtnDelete();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString			m_csTemplatePath;
	CString			m_csCurrentTemplateFullPath;
	BOOL			m_blnFileIsOpen;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEMPLATEEDITORDLG_H__4EC44DF4_3F24_4DD0_8CFA_DFA1E0C1A2E6__INCLUDED_)
