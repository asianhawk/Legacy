#if !defined(AFX_ADDJOBSTEP5_H__CAAF8437_374C_4BED_B0FA_D15A56295A11__INCLUDED_)
#define AFX_ADDJOBSTEP5_H__CAAF8437_374C_4BED_B0FA_D15A56295A11__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep5.h : header file
//
#include "tooltip/PPTooltip.h"

//const char *conGradient1 =  "//Config/ToolTips/Gradient1";
//const char *conGradient2 =  "//Config/ToolTips/Gradient2";
//const char *conGradient3 =  "//Config/ToolTips/Gradient3";
#include "textsrc\ColorEditWnd.h"
#include "textsrc\SampleColorizer.h"
/////////////////////////////////////////////////////////////////////////////
// CAddJobStep5 dialog

class CAddJobStep5 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep5)

// Construction
public:
	CAddJobStep5();
	~CAddJobStep5();
	void DisplayScannerControls(BOOL blnVisible);
	void DisplayRotationControls(BOOL blnVisible);


// Dialog Data
	//{{AFX_DATA(CAddJobStep5)
	enum { IDD = IDD_ADDJOB_STEP5 };
	CButton	m_btnViewTemplate;
	CStatic	m_lblLabelID;
	CComboBox	m_cmbRotationAngle;
	CComboBox	m_cmbTemplateName;
	BOOL	m_blnVerify;
	BOOL	m_blnScanLabel;
	CString	m_csLabelOrder;
	int		m_optRotationType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep5)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual LRESULT OnWizardBack();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep5)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnBtnViewTemplate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void				InitControls();
	void				SetToolTipsProperties();
	void				CreateToolTips();

private:
	CPPToolTip 			m_Tip;
	HICON				m_hIcon1;
	long			m_lngColorGrad1;
	long			m_lngColorGrad2;
	long			m_lngColorGrad3;
	BOOL			m_blnDisplayScannerPrompts;
	BOOL			m_blnDisplayRotatePrompts;

	CAutoFont		m_stdFont;
	CAutoFont		m_ViewFont;
    ColorEditWnd	*m_pColorWnd;
	CSampleColorizer m_colorizer;
	void			DisplayTemplate(CString csTemplate);



};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP5_H__CAAF8437_374C_4BED_B0FA_D15A56295A11__INCLUDED_)
