#ifndef _COMMANDS_H
#define _COMMANDS_H

extern int processCommand(int filedes);

#endif /* _COMMANDS_H */
