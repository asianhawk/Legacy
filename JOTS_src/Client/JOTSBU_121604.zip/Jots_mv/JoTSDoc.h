// JoTSDoc.h : interface of the CJoTSDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_JOTSDOC_H__608FCFBF_7B3F_43F1_A7E8_7DAEE784B089__INCLUDED_)
#define AFX_JOTSDOC_H__608FCFBF_7B3F_43F1_A7E8_7DAEE784B089__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000





#include "XML\XMLFile.h"

#define CHECK_AND_RELEASE(pInterface)  \
if(pInterface) \
   {\
pInterface->Release();\
pInterface = NULL;\
   }\

#define RELEASE(pInterface)  \
   {\
pInterface->Release();\
pInterface = NULL;\
   }\


//-----------------------------------------------------------
// Call this MACRO when you need to create a new Document.
// The document will construct itself further inside FinalConstruct.
#define IMPLEMENT_CREATE_DOCUMENT								\
	CComObject<CJoTSDoc>* pDoc;								\
	HRESULT hr = CComObject<CJoTSDoc>::CreateInstance(&pDoc);\
	ASSERT(SUCCEEDED(hr));										\
	pDoc->InternalAddRef();
//-----------------------------------------------------------


class CJoTSDoc : public CDocument,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CJoTSDoc, &CLSID_JobRecord>,
	public IConnectionPointContainerImpl<CJoTSDoc>,
	public IDispatchImpl<IJobRecord, &IID_IJobRecord, &LIBID_JoTS>
{
protected: // create from serialization only
	CJoTSDoc();
	DECLARE_DYNCREATE_ATL(CJoTSDoc)

	DECLARE_REGISTRY_RESOURCEID(IDR_DOCUMENT)
	DECLARE_NOT_AGGREGATABLE(CJoTSDoc)

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CJoTSDoc)
		COM_INTERFACE_ENTRY(IJobRecord)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY(IConnectionPointContainer)
	END_COM_MAP()
	BEGIN_CONNECTION_POINT_MAP(CJoTSDoc)
	END_CONNECTION_POINT_MAP()


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJoTSDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	STDMETHOD(get_Description)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Description)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_JobName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_JobName)(/*[in]*/ BSTR newVal);
	STDMETHOD(Hello)();
	virtual ~CJoTSDoc();
	
	HRESULT FinalConstruct();
	void    FinalRelease();



   BOOL OpenJobFile(LPCTSTR lpszPathName);
   BOOL			GetProcessInfo();

   // 	Job Record Support Properties
   CString		GetJobName();
   void			SetJobName(CString csJobName); 

   CString		GetCompanyName();
   void			SetCompanyName(CString csCustomerName);

   CString		GetProduct();
   void			SetProduct(CString csProduct);
 
   CString		GetMaxRePrints();
   void			SetMaxRePrints(CString csMaxRePrints);

   CString		GetMaxReScans();
   void			SetMaxReScans(CString csMaxReScans);



   int			GetLabelInformation();	
   int			m_nNumberOfLabels;
   int			m_nNumberOfDataSeries;

   CString		ExtractJobName(CString csJobPathName);
   
   // 	End Job Record Support Properties
   
   
   void	   SaveJob();
   void	   PreProcessInfo();
   void	   SaveJobAs(CString csJobName);

   CXMLFile			m_oXML;
   void			CreateNewJob(CString csFileName);
   JobInfo		*GetJobInfo();	
   CString		GetTCPAddress();
   CString		GetTCPPort();
   void			ReadJobInfo();   

private:
	CString		m_csOpenFileName;

	// Job Data Information
	CString		m_csJobName;
	CString		m_csCompanyName;
	CString		m_csProduct;
	CString		m_csMaxRePrints;
	CString		m_csMaxReScans;

	// End Job Data

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CJoTSDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOTSDOC_H__608FCFBF_7B3F_43F1_A7E8_7DAEE784B089__INCLUDED_)
