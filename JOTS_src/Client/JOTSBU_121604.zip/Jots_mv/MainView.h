// MainView.h : Declaration of the CMainView

#ifndef __MAINVIEW_H_
#define __MAINVIEW_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMainView
class ATL_NO_VTABLE CMainView : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMainView, &CLSID_MainView>,
	public IConnectionPointContainerImpl<CMainView>,
	public IDispatchImpl<IMainView, &IID_IMainView, &LIBID_JoTSLib>
{
public:
	CMainView()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MAINVIEW)
DECLARE_NOT_AGGREGATABLE(CMainView)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMainView)
	COM_INTERFACE_ENTRY(IMainView)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CMainView)
END_CONNECTION_POINT_MAP()


// IMainView
public:
};

#endif //__MAINVIEW_H_
