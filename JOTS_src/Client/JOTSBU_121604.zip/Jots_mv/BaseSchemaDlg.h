#if !defined(AFX_BASESCHEMADLG_H__B82DBE89_0D2B_46AB_AB86_EFCA6BE00596__INCLUDED_)
#define AFX_BASESCHEMADLG_H__B82DBE89_0D2B_46AB_AB86_EFCA6BE00596__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BaseSchemaDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

/////////////////////////////////////////////////////////////////////////////
// CBaseSchemaDlg dialog

class CBaseSchemaDlg : public CDialog
{
// Construction
public:
	CBaseSchemaDlg(CWnd* pParent = NULL);   // standard constructor
	CGridCtrl			m_Grid;
	void				InitGrid();
	void				InitControls();
	BOOL				IsModified(int nRow);
// Dialog Data
	//{{AFX_DATA(CBaseSchemaDlg)
	enum { IDD = IDD_BASE_SCHEMA };
	CStatic	m_lblTitle;
	CShadeButtonST	m_btnOK;
	CShadeButtonST	m_btnCancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBaseSchemaDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBaseSchemaDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnSetupCustomBasenumber();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CBaseSchemaDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BASESCHEMADLG_H__B82DBE89_0D2B_46AB_AB86_EFCA6BE00596__INCLUDED_)
