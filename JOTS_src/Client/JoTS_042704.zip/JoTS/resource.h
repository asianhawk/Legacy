//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by JoTSATL.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_AUTOATL                     102
#define IDR_APPLICATION                 103
#define IDR_DOCUMENT                    104
#define IDR_MAINFRAME                   128
#define IDR_AUTOATTYPE                  129
#define IDR_REGISTRY                    132
#define IDR_REGISTRY1                   133
#define ID_FILE_EMAIL_JOB               32772
#define ID_FILE_EMAIL_PRINTER_SETTINGS  32773
#define ID_FILE_PRINT_STATUS            32774
#define ID_FILE_PRINT_LOG               32775
#define ID_FILE_PURGE_AUDIT_LOG         32777
#define ID_FILE_PURGE_SEQUENCE_LOG      32778
#define ID_FILE_PURGE_ERROR_LOG         32779
#define ID_JOB_START                    32780
#define ID_JOB_PAUSE                    32781
#define ID_JOB_END                      32782
#define ID_JOB_TEMPLATE_SETTINGS        32783
#define ID_JOB_DATA_SOURCE_ODBC         32784
#define ID_JOB_DATA_SOURCE_CBASE_NUMBERING 32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
