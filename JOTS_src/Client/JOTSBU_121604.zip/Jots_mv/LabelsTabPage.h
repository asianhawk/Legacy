#if !defined(AFX_LABELSTABPAGE_H__6CF7789D_D6DD_42D9_B794_B1857D0045EC__INCLUDED_)
#define AFX_LABELSTABPAGE_H__6CF7789D_D6DD_42D9_B794_B1857D0045EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LabelsTabPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLabelsTabPage dialog
#include "tab control src/TabPageSSL.h"

class CLabelsTabPage : public CTabPageSSL
{
// Construction
public:
	CLabelsTabPage(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLabelsTabPage)
	enum { IDD = IDD_LABELS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLabelsTabPage)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLabelsTabPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CLabelsTabPage)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LABELSTABPAGE_H__6CF7789D_D6DD_42D9_B794_B1857D0045EC__INCLUDED_)
