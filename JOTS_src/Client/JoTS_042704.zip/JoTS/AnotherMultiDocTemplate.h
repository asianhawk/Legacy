// AnotherMultiDocTemplate.h: interface for the CMultiDocSingleViewTemplate class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ANOTHERMULTIDOCTEMPLATE_H__10BD8024_4292_11D4_B09F_0800690F6772__INCLUDED_)
#define AFX_ANOTHERMULTIDOCTEMPLATE_H__10BD8024_4292_11D4_B09F_0800690F6772__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAnotherMultiDocTemplate : public CMultiDocTemplate
{
	DECLARE_DYNAMIC(CAnotherMultiDocTemplate)

public:
	// Constructor.
	// Those information are directly passed to the
	// base class that will manage the document creation.
    CAnotherMultiDocTemplate(UINT nIDResource,
								CRuntimeClass* pDocClass,
								CRuntimeClass* pFrameClass,
								CRuntimeClass* pViewClass );

	CDocument* m_pDocument;

	virtual CDocument*	CreateNewDocument();
};

#endif // !defined(AFX_ANOTHERMULTIDOCTEMPLATE_H__10BD8024_4292_11D4_B09F_0800690F6772__INCLUDED_)
