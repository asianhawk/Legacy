#if !defined(AFX_DISPLAYLABELSDLG_H__BD6E5F1A_3ACD_42DE_99BF_5781152033C3__INCLUDED_)
#define AFX_DISPLAYLABELSDLG_H__BD6E5F1A_3ACD_42DE_99BF_5781152033C3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplayLabelsDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

/////////////////////////////////////////////////////////////////////////////
// CDisplayLabelsDlg dialog

#include "tooltip/PPTooltip.h"

class CDisplayLabelsDlg : public CDialog
{
// Construction
public:
	CDisplayLabelsDlg(CWnd* pParent = NULL);   // standard constructor
	BOOL IsModified();
// Dialog Data
	//{{AFX_DATA(CDisplayLabelsDlg)
	enum { IDD = IDD_MAIN_LABELS };
	CShadeButtonST	m_btnUpdate;
	CSpinButtonCtrl	m_spnMoveLabels;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayLabelsDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

public:
	CGridCtrl			m_Grid;
	void				InitGrid();
	JobInfo				*m_pJobInfo;
	void				UpdateGrid();
	void				ProcessScanCheck (int nRowID, int nColID);
	BOOL				VerifyGrid();
	void				SetCheckBox(int nRow, int nColumn, CString csValue );
	void				SetRotationAngle(int  nRow, int nCol, CString csAngle);
	BOOL				IsColSelected(int nCol);
	void				GetAllTemplates();
	void				ProcessTemplateCell(int nRowID, int nColID);
	void				ProcessRotationAngle(int nRowID, int nColID);
	void				DefineRotationAngles();
	BOOL				VerifyTemplates();
	HWND				m_hwndParent;
	CString				GetCurrentSelectedTemplate();
	void				SetCurrentSelectedTemplate(CString csTemplate);

private:
	CStringArray		m_csaTemplates,
						m_csaRotationAngles;
	CString				m_csCurrentTemplate;

protected:

	// Generated message map functions
	//{{AFX_MSG(CDisplayLabelsDlg)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/);
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLabelsCopy();
	afx_msg void OnLabelsDeletelabel();
	afx_msg void OnUpdateJobRecord();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int					m_nCurrentRow;
	CPPToolTip 		m_Tip;
	HICON			m_hIcon1;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPLAYLABELSDLG_H__BD6E5F1A_3ACD_42DE_99BF_5781152033C3__INCLUDED_)
