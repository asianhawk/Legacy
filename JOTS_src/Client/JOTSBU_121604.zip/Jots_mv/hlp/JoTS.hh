 
// Commands (ID_* and IDM_*) 
HID_BTN_TEST                            0x10003
HID_BTN_HOLD                            0x10003
HID_EDIT_WND                            0x1006E
HID_BTN_EXIT                            0x10444
HID_FILE_JOBS_NEW                       0x18004
HID_FILE_JOBS_OPEN                      0x18005
HID_FILE_IMPORT                         0x18006
HID_FILE_EXPORT                         0x18007
HID_RUN_SINGLE                          0x18008
HID_SETUP_MORPHOR_SERIAL                0x1800C
HID_SETUP_MORPHOR_NETWORK               0x1800D
HID_SETUP_SECURITY_USER                 0x1800F
HID_SETUP_SECURITY_ACCESS_RIGHTS        0x18010
HID_SETUP_DATASOURCES_ODBC              0x18015
HID_SETUP_DATASOURCES_FLAT_FILE         0x18016
HID_SETUP_SYSTEM                        0x18017
HID_SETUP_TEMPLATES_EDITOR              0x18019
HID_SETUP_SERIALIZATION                 0x1801A
HID_SETUP_CUSTOM_BASENUMBER             0x1801B
HID_SETUP_KEYWORDS                      0x1801C
HID_EDIT_JOB_NAME                       0x1801D
HID_EDIT_JOB_LABELS                     0x1801E
HID_EDIT_JOB_RUN                        0x1801F
HID_RUN_BATCH                           0x18020
HID_SETUP_PRINTER_VIEW                  0x18021
HID_SETUP_PRINTER_SAVE                  0x18022
HID_SETUP_PRINTER_LOAD                  0x18023
HID_SETUP_PRINTER_TEST                  0x18024
HID_SETUP_SCANNER_EDIT                  0x18025
HID_SETUP_SCANNER_DIAGNOSTIC            0x18026
HID_SETUP_PRINTER                       0x18027
HID_SETUP_TEMPLATE                      0x18028
HID_SETUP_LOGGING                       0x18029
 
// Prompts (IDP_*) 
HIDP_SOCKETS_INIT_FAILED                0x30068
 
// Resources (IDR_*) 
HIDR_JOTS                               0x20066
HIDR_APPLICATION                        0x20067
HIDR_DOCUMENT                           0x20069
HIDR_VIEW                               0x2006A
HIDR_JOBVIEW_TMPL                       0x2006C
HIDR_MAINVIEW                           0x2006D
HIDR_SERVICES                           0x2006F
HIDR_MAINFRAME                          0x20080
HIDR_JOTSTYPE                           0x20081
HIDR_MAINMENU                           0x2008A
HIDR_COLOREDITCTX                       0x2009D
 
// Dialogs (IDD_*) 
HIDD_ABOUTBOX                           0x20064
HIDD_FORMVIEW                           0x20065
HIDD_JOBVIEW_FORM                       0x2006B
HIDD_USERS_LIST                         0x20082
HIDD_ACCESS_RIGHTS                      0x2008B
HIDD_USER_ACCOUNT                       0x2008D
HIDD_LABELS                             0x2008E
HIDD_DIALOG1                            0x2008F
HIDD_DIALOG2                            0x20090
HIDD_MAIN_LABELS                        0x20091
HIDD_MAIN_TEMPLATES                     0x20092
HIDD_MAIN_RUN                           0x20093
HIDD_ADDJOB_STEP1                       0x20094
HIDD_ADDJOB_STEP2                       0x20095
HIDD_ADDJOB_STEP3                       0x20096
HIDD_ADDJOB_STEP4                       0x20097
HIDD_ADDJOB_STEP5                       0x20098
HIDD_ADDJOB_STEP6                       0x20099
HIDD_ADDJOB_STEP7                       0x2009A
HIDD_ADDJOB_STEP2A                      0x2009B
HIDD_ADDJOB_STEP8                       0x2009C
HIDD_DATA_SERIES                        0x2009D
HIDD_VARIABLE_DATA                      0x2009E
HIDD_DIALOG3                            0x2009F
HIDD_MESSAGE_BOX                        0x2009F
HIDD_SETUP_TCP                          0x200A2
HIDD_RUN                                0x200A3
 
// Frame Controls (IDW_*) 
