// MorphorTCPSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "MorphorTCPSetupDlg.h"
#include "Utilities.h"
#include "LMorphor3.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CMorphorTCPSetupDlg dialog


CMorphorTCPSetupDlg::CMorphorTCPSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMorphorTCPSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMorphorTCPSetupDlg)
	m_csTCPAddress = _T("");
	m_csTCPPort = _T("");
	m_csMessage = _T("");
	m_csLM3Command = _T("");
	//}}AFX_DATA_INIT
}


void CMorphorTCPSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMorphorTCPSetupDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, ID_BTN_TEST, m_btnTest);
	DDX_Control(pDX, IDC_CMB_CMDS, m_cmbLM3Cmds);
	DDX_Control(pDX, IDC_TXB_TEST, m_edtTestMessage);
	DDX_Text(pDX, IDC_TXB_TCP_ADDRESS, m_csTCPAddress);
	DDX_Text(pDX, IDC_TXB_TCP_PORT, m_csTCPPort);
	DDX_Text(pDX, IDC_TXB_TEST, m_csMessage);
	DDX_CBString(pDX, IDC_CMB_CMDS, m_csLM3Command);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMorphorTCPSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CMorphorTCPSetupDlg)
	ON_BN_CLICKED(ID_BTN_TEST, OnBtnTest)
	ON_EN_UPDATE(IDC_TXB_TEST, OnUpdateTxbTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMorphorTCPSetupDlg message handlers

BOOL CMorphorTCPSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitControls();
	GetTCPValues();
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CMorphorTCPSetupDlg::InitControls()
{

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
			
	
	GetDlgItem(IDC_LBL_TCP_ADDRESS)->SetFont(&font);
	GetDlgItem(IDC_LBL_TCP_PORT)->SetFont(&font);
	GetDlgItem(IDC_TXB_TCP_ADDRESS)->SetFont(&font);
	GetDlgItem(IDC_TXB_TCP_PORT)->SetFont(&font);
	GetDlgItem(IDC_LBL_CMDS)->SetFont(&font);
	GetDlgItem(IDC_LBL_RESPONSE)->SetFont(&font);
	GetDlgItem(IDC_CMB_CMDS)->SetFont(&font);
	GetDlgItem(IDC_TXB_TEST)->SetFont(&font);

	font.SetHeight(14);
	GetDlgItem(IDC_FRAME_TEST)->SetFont(&font);
	font.SetHeight(14);
	
	
	GetDlgItem(ID_BTN_TEST)->EnableWindow(TRUE);

	m_cmbLM3Cmds.AddString(LM3INQUIRY); 
	m_cmbLM3Cmds.AddString(LM3VERSION); 
	m_cmbLM3Cmds.AddString(LM3CONFIG); 
	m_cmbLM3Cmds.AddString(LM3RESET); 
	m_cmbLM3Cmds.AddString(LM3PASSTHRU); 

	m_cmbLM3Cmds.AddString(ABORTPASSTHRU); 
	m_cmbLM3Cmds.AddString(PRINTANDAPPLY); 
	m_cmbLM3Cmds.AddString(READFROMSCSANNER); 
	m_cmbLM3Cmds.AddString(DIGITALOUTPUT); 
	m_cmbLM3Cmds.AddString(DIGITALINPUT); 

	m_cmbLM3Cmds.AddString(RESETAPPLICATOR); 
	m_cmbLM3Cmds.AddString(PRINTSTATUS); 
	m_cmbLM3Cmds.AddString(QPRINTSTATUS); 

	m_btnOK.SetFont(&font);
	m_btnOK.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnOK.SetIcon(IDI_OK);
	m_btnOK.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnCancel.SetFont(&font);
	m_btnCancel.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnCancel.SetIcon(IDI_CANCEL1);
	m_btnCancel.SetAlign(CButtonST::ST_ALIGN_HORIZ);

	m_btnTest.SetFont(&font);
	m_btnTest.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnTest.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnTest.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnTest.SetIcon(IDI_CANCEL1);
//	m_btnTest.SetAlign(CButtonST::ST_ALIGN_HORIZ);



}

void CMorphorTCPSetupDlg::GetTCPValues()
{
CUtilities oUtil;
	if (!oUtil.GetTCPAddress(&m_csTCPAddress))
	{
		AfxMessageBox("TCP Address Not Defined");

	}
	if (!oUtil.GetTCPPort(&m_csTCPPort))
	{
		AfxMessageBox("TCP Port Not Defined");

	}
	UpdateData(FALSE);
}

void CMorphorTCPSetupDlg::OnOK() 
{
CUtilities *pUtil;

	pUtil = new CUtilities();

	
	if (!Verify())
		return;
	pUtil->SetTCPAddress(m_csTCPAddress);  
	pUtil->SetTCPPort(m_csTCPPort);
	delete pUtil;
	CDialog::OnOK();
}

BOOL CMorphorTCPSetupDlg::VerifyTCPAddress()
{
	UpdateData(TRUE);
	
	if (m_csTCPAddress.IsEmpty())
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CMorphorTCPSetupDlg::VerifyTCPPort()
{
	
	if (m_csTCPPort.IsEmpty())
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CMorphorTCPSetupDlg::Verify()
{
CUtilities *pUtil;
BOOL blnState=TRUE;

	UpdateData(TRUE);
	pUtil = new CUtilities();

	if (!VerifyTCPAddress())
	{
		pUtil->ErrorMessage("Invalid TCP Address"); 
		blnState=FALSE;
	}
	else if (!VerifyTCPPort())
	{

		pUtil->ErrorMessage("Invalid TCP Port"); 
		blnState=FALSE;


	}
	GetDlgItem(ID_BTN_TEST)->EnableWindow(blnState);
	delete pUtil;

	return blnState;
}

void CMorphorTCPSetupDlg::OnBtnTest() 
{
CString csBuffer;
CUtilities oUtil;

	if(!Verify())
		return;
	GetDlgItem(ID_BTN_TEST)->GetWindowText(csBuffer);

	if (csBuffer.Find("Test")!=-1)
	{
		if (m_csLM3Command.IsEmpty())
		{
			oUtil.ErrorMessage("Morphor Command Must Not Be Blank");
			return;


		}
		m_pMorphor = new CLMorphor3(&m_edtTestMessage);
		if(!m_pMorphor->ConnectLM3(m_csTCPAddress,m_csTCPPort))
		{
			return; 	

		}
		m_pMorphor->Transmit(m_csLM3Command);  // Transmit Std LM3 Identifier

		GetDlgItem(IDC_TXB_TEST)->EnableWindow(TRUE);

		GetDlgItem(ID_BTN_TEST)->SetWindowText("Close");
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDCANCEL)->EnableWindow(TRUE);

	}
	else
	{
		if (m_pMorphor)
			m_pMorphor->CloseChannel(); 
		
		m_pMorphor=NULL;
		GetDlgItem(ID_BTN_TEST)->SetWindowText("Test");
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
		GetDlgItem(IDC_TXB_TEST)->SetWindowText("");
		GetDlgItem(IDC_TXB_TEST)->EnableWindow(FALSE);


	}
}



void CMorphorTCPSetupDlg::UpdateMsgDisplay(CString csMessage)
{
	m_csMessage = csMessage;
	UpdateData(FALSE);

}

void CMorphorTCPSetupDlg::OnUpdateTxbTest() 
{

	
}
