#if !defined(AFX_MORPHORPROTOCOL_H__BB5858C7_CDBE_442F_A18E_9E3A4E27C6A1__INCLUDED_)
#define AFX_MORPHORPROTOCOL_H__BB5858C7_CDBE_442F_A18E_9E3A4E27C6A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MorphorProtocol.h : header file
//
const CString LM3INQUIRY	="!HI\n";
const CString LM3VERSION	="!HV\n";
const CString LM3CONFIG		="!HC\n";
const CString LM3RESET		="!HR\n";
const CString LM3PASSTHRU	="!PT,PRINTER\n";
const CString ABORTPASSTHRU		="!AP\n";

const CString LM3KILL			="!KILL\n";
const CString LM3UPDATE			="!UPDATE\n";


const CString PRINTANDAPPLY		="!PA";
const CString READFROMSCSANNER	="!RS";
const CString DIGITALOUTPUT		="!DO";
const CString DIGITALINPUT		="!HI";
const CString RESETAPPLICATOR	="!RA";
const CString PRINTSTATUS		="!PS";
const CString QPRINTSTATUS		="!QP";

const CString STARTAPPLICATORBIT_ON    = "!DO,START,1,0\n";
const CString STARTAPPLICATORBIT_OFF   = "!DO,START,0,0\n";

const CString STOPAPPLICATORBIT_ON    = "!DO,STOP,1,0\n";
const CString STOPAPPLICATORBIT_OFF   = "!DO,STOP,0,0\n";


const CString ESTOP_ON		    = "!DO,ESTOP,1,0\n";
const CString ESTOP_OFF		    = "!DO,ESTOP,0,0\n";


const CString APPLYLABELBIT_ON	    = "!DO,DEMAND,1,0\n";
const CString APPLYLABELBIT_OFF    = "!DO,DEMAND,0,0\n";

const CString ISMORPHORRDY		   = "!DI,RDY,1\n";
const CString ISPARTPRESENT		   = "!DI,PPRESENT,1\n";
const CString CYCLECOMPLETE		   = "!DI,CC,1\n";




/////////////////////////////////////////////////////////////////////////////
// CMorphorProtocol window

class CMorphorProtocol  
{
// Construction
public:
	CMorphorProtocol();
	CString HostInquiry();
	CString HostInquiry(CString *csExpectedResponse);

	CString Version();
	CString Version(CString *csExpectedResponse);

	CString GetDeviceConfig();
	CString GetDeviceConfig(CString *csExpectedResponse);

	CString Reset();
	CString Reset(CString *csExpectedResponse);

	CString ActivatePassThruMode();
	CString ActivatePassThruMode(CString *csExpectedResponse);

	CString DeActivatePassThruMode();
	CString DeActivatePassThruMode(CString *csExpectedResponse);
	
	CString PrintAndApply();
	CString PrintAndApply(CString *csExpectedResponse);

	CString ReadScanner();
	CString ReadScanner(CString *csExpectedResponse);

	CString GetDigitalInputs();
	CString	GetDigitalInputs(CString *csDigitalInputs);

	CString	SetDigitalOutputs(CString csDigitalOutputs);

	CString ResetApplicator();
	CString ResetApplicator(CString *csExpectedResponse);

	CString PrintStatus();
	CString PrintStatus(CString *csExpectedResponse);

	CString QueryPrintStatus();
	CString QueryPrintStatus(CString *csExpectedResponse);



// Attributes
public:

// Operations
public:


// Implementation
public:
	virtual ~CMorphorProtocol();

	// Generated message map functions
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MORPHORPROTOCOL_H__BB5858C7_CDBE_442F_A18E_9E3A4E27C6A1__INCLUDED_)
