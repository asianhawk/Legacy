// DefineNumOfIndexesPge.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "DefineNumOfIndexesPge.h"
#include "PropertyEx.h"
#include "Utilities.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


	// begin tool tip stuff

const char *NumberOfDataFactories_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *Serialized_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
	// end tool tip stuff


/////////////////////////////////////////////////////////////////////////////
// CDefineNumOfIndexesPge property page

IMPLEMENT_DYNCREATE(CDefineNumOfIndexesPge, CPropertyPage)

CDefineNumOfIndexesPge::CDefineNumOfIndexesPge() : CPropertyPage(CDefineNumOfIndexesPge::IDD)
{
	//{{AFX_DATA_INIT(CDefineNumOfIndexesPge)
	m_csNumberOfIndexes = _T("1");
	m_nSerializedData = 0;
	m_blnExternalDataSource = FALSE;
	//}}AFX_DATA_INIT
	m_csInstructions.LoadString(IDS_DEFINE_NUMBER_OF_INDEXES); 
}

CDefineNumOfIndexesPge::~CDefineNumOfIndexesPge()
{
	if (m_Tip)
	{
		m_Tip.RemoveAllTools();
		m_Tip.DestroyWindow();
	}

}

void CDefineNumOfIndexesPge::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDefineNumOfIndexesPge)
	DDX_Control(pDX, IDC_FRM, m_frmSerialedData);
	DDX_Control(pDX, IDC_OPT1_SERIALIZED_DATA, m_optSerializedData);
	DDX_Control(pDX, IDC_CHK_EXTERNAL, m_chkUseExternal);
	DDX_Control(pDX, IDC_SPIN_DATA_FACTORIES, m_spnNumberOfDataFactories);
	DDX_Control(pDX, IDC_TXB_NUMBER_OF_INDEXES, m_edtNumberOfIndexes);
	DDX_Text(pDX, IDC_LBL_INSTRUCTIONS, m_csInstructions);
	DDX_Text(pDX, IDC_TXB_NUMBER_OF_INDEXES, m_csNumberOfIndexes);
	DDX_Radio(pDX, IDC_OPT1_SERIALIZED_DATA, m_nSerializedData);
	DDX_Check(pDX, IDC_CHK_EXTERNAL, m_blnExternalDataSource);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDefineNumOfIndexesPge, CPropertyPage)
	//{{AFX_MSG_MAP(CDefineNumOfIndexesPge)
	ON_BN_CLICKED(IDC_OPT1_SERIALIZED_DATA, OnOpt1SerializedData)
	ON_BN_CLICKED(IDC_OPT1_NONSERIALIZED_DATA, OnOpt1NonserializedData)
	ON_BN_CLICKED(IDC_CHK_EXTERNAL, OnChkExternal)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDefineNumOfIndexesPge message handlers

BOOL CDefineNumOfIndexesPge::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	InitControls();
	
	m_Tip.Create(this);
	CreateToolTips();
	
	if (m_nSerializedData==0)
	{
		m_edtNumberOfIndexes.EnableWindow(TRUE); 	
	}
	else
		m_edtNumberOfIndexes.EnableWindow(FALSE); 	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


LRESULT CDefineNumOfIndexesPge::OnWizardNext() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
		
	UpdateData(TRUE);

	if (m_nSerializedData==0)
	{
		if (m_csNumberOfIndexes.IsEmpty())
		{
			AfxMessageBox("Number Of Indexes Not Defined");
			return -1;
		}
		if (!m_edtNumberOfIndexes.CheckIfValid(TRUE))
		{
			return -1;

		}
		parent->m_lngNumberOfSerializedIndexes=atoi(m_csNumberOfIndexes);
		parent->m_lngCurrentCountOfSerializedIndexes=0; 
	
		return IDD_ADDJOB_STEP3;
	}
	

	
	return CPropertyPage::OnWizardNext();
}

void CDefineNumOfIndexesPge::OnOpt1SerializedData() 
{
	UpdateData(TRUE);
	if (m_nSerializedData==0)
	{
		m_edtNumberOfIndexes.EnableWindow(TRUE); 
		m_edtNumberOfIndexes.SetWindowText("1"); 

	}
	else
	{

		m_edtNumberOfIndexes.EnableWindow(FALSE);
		m_edtNumberOfIndexes.SetWindowText(""); 

	}

}

void CDefineNumOfIndexesPge::OnOpt1NonserializedData() 
{
	OnOpt1SerializedData();
}



void CDefineNumOfIndexesPge::InitControls()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	GetDlgItem(IDC_LBL_INSTRUCTIONS)->SetFont(&font);
	GetDlgItem(IDC_LBL_INTERNAL_SERIAL)->SetFont(&font);
	GetDlgItem(IDC_OPT1_SERIALIZED_DATA)->SetFont(&font);
	GetDlgItem(IDC_OPT1_NONSERIALIZED_DATA)->SetFont(&font);
	GetDlgItem(IDC_CHK_EXTERNAL)->SetFont(&font);
	GetDlgItem(IDC_LBL_SERIALIZED_DATA_COUNT)->SetFont(&font);
	GetDlgItem(IDC_TXB_NUMBER_OF_INDEXES)->SetFont(&font);


	m_spnNumberOfDataFactories.SetBuddy(&m_edtNumberOfIndexes);
    m_spnNumberOfDataFactories.SetRange( 0, 10 );
    m_spnNumberOfDataFactories.SetPos( 1 );
	m_edtNumberOfIndexes.SetRange(0,10); 
	m_edtNumberOfIndexes.SetMaxWholeDigits(2);

	// use ODBC ?
	m_chkUseExternal.ShowWindow(TRUE);
	csTemp=pUtil->GetConfigValue("//Config/Options/UseODBC",FALSE);
	if(!csTemp.IsEmpty())
	{
		csTemp.MakeUpper();
		if ((csTemp.Find("Y")!=-1)||(csTemp.Find("T")))
		{
			m_chkUseExternal.ShowWindow(FALSE);
		}
	}
	
	delete pUtil;


}

void  CDefineNumOfIndexesPge::CreateToolTips()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;

	SetToolTipsProperties();
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard3/NumberofDataFactories",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",NumberOfDataFactories_DefTip);
	
	m_Tip.AddTool(&m_edtNumberOfIndexes, _T(csTemp), m_hIcon1);

	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard3/SerializedDataOption",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",Serialized_DefTip);

	
	m_Tip.AddTool(&m_optSerializedData, _T(csTemp), m_hIcon1);
	
	delete pUtil;
}

void  CDefineNumOfIndexesPge::SetToolTipsProperties()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;
char *conGradient1 =  "//Config/ToolTips/Gradient1";
char *conGradient2 =  "//Config/ToolTips/Gradient2";
char *conGradient3 =  "//Config/ToolTips/Gradient3";

	
	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);


	csTemp=pUtil->GetConfigValue("StyleSheet",FALSE); 
	if (csTemp.IsEmpty())
	{
		csTemp.LoadString(IDS_TIP_HTML_STYLE); 
		m_Tip.SetCssStyles(csTemp);
	}
	else
	{
		m_Tip.SetCssStyles(csTemp);
	}


	csTemp=pUtil->GetConfigValue(conGradient1,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad1=BEGINTIPCOLOR;
	}
	else
	{
		m_lngColorGrad1 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient2,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad2=MIDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad2 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient3,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad3=ENDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad3 = atol(csTemp);
	}



//	m_Tip.SetColorBk(m_lngColorGrad1,m_lngColorGrad2,m_lngColorGrad3);
	m_Tip.SetColorBk(DEFCOLOR);

//	m_Tip.SetEffectBk(CPPDrawManager::EFFECT_3HGRADIENT,10);
	m_Tip.SetDelayTime(PPTOOLTIP_TIME_FADEOUT,TOOLTIP_FADEOUT);

	
	delete pUtil;

}

BOOL CDefineNumOfIndexesPge::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	m_Tip.RelayEvent(pMsg); 
	return CPropertyPage::PreTranslateMessage(pMsg);
}



void CDefineNumOfIndexesPge::OnChkExternal() 
{
	// TODO: Add your control notification handler code here
	
}
