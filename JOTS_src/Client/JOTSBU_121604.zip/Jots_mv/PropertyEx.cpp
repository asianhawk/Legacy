// PropertyEx.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "PropertyEx.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyEx

IMPLEMENT_DYNAMIC(CPropertyEx, CPropertySheet)

CPropertyEx::CPropertyEx(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CPropertyEx::CPropertyEx(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CPropertyEx::~CPropertyEx()
{
}


BEGIN_MESSAGE_MAP(CPropertyEx, CPropertySheet)
	//{{AFX_MSG_MAP(CPropertyEx)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyEx message handlers
void CPropertyEx::Init()
{
	m_lngCurrentCountOfSerializedIndexes=0;
	m_lngNumberOfSerializedIndexes=0;
	m_nMaxNumberOfTemplates=0;
	m_nCurrentTemplateIndex=0;
	m_blnUniqueTemplates=FALSE;
	m_nBarCodePageID=0;
	m_csaDataDefinition.RemoveAll(); 
	m_csaTemplates.RemoveAll(); 
	m_strTemplatePath="";
	m_strTemplateFileExtension="";

	GetTemplateNames();


}

void CPropertyEx::GetTemplateNames()
{

CUtilities oUtil;



	oUtil.GetTemplates(&m_csaTemplates);

}

CString CPropertyEx::GetTemplatePath()
{
int nLength;
	
	nLength=m_strTemplatePath.GetLength();
	if (nLength<=1) return "";
	if (m_strTemplatePath.Mid(nLength-1,1)!="\\")
		m_strTemplatePath+=_T("\\");
	
	return m_strTemplatePath;


}

CString CPropertyEx::GetJobName()
{

	return m_csJobName;
}
void CPropertyEx::SetJobName(CString csJobName)
{
	
	m_csJobName=csJobName;
}
