// AddJobStep3.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep3.h"
#include "PropertyEx.h"
#include "CheckDgt.h"
#include "SequenceGen.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

	// begin tool tip stuff

const char *NameOfDataFactories_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *IsSerializedData_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");


const char *Allow_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *StartingSSN_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");

const char *BaseNumberSchema_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *CheckDigit_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");

const char *MaxSequenceValue_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *RollOverValue_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");


const char *FieldWidth_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *StepSize_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");

	// end tool tip stuff


/////////////////////////////////////////////////////////////////////////////
// CAddJobStep3 property page

IMPLEMENT_DYNCREATE(CAddJobStep3, CPropertyPage)

CAddJobStep3::CAddJobStep3() : CPropertyPage(CAddJobStep3::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep3)
	m_csSequenceName = _T("");
	m_csMaxFieldWidth = _T("");
	m_csMaxSequenceNumber = _T("");
	m_csStartingSerialNumber = _T("");
	m_blnAllowDuplicates = FALSE;
	m_csRollOverValue = _T("");
	m_txbStepSize = _T("");
	m_blnStatic = FALSE;
	//}}AFX_DATA_INIT
	m_csIndexName = "Data Factory Name:";
	m_csSequenceLabel = "Starting Sequence Value:";

}

CAddJobStep3::~CAddJobStep3()
{
	if (m_Tip)
	{
		m_Tip.RemoveAllTools();
		m_Tip.DestroyWindow();
	}
}

void CAddJobStep3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep3)
	DDX_Control(pDX, IDC_CHK_STATIC_VAR, m_chkIsStatic);
	DDX_Control(pDX, IDC_CHK_EXTERNAL_NO_DUPLICATES, m_chkAllowDuplicates);
	DDX_Control(pDX, IDC_SPN_STEPSIZE, m_spnStepSize);
	DDX_Control(pDX, IDC_SPN_WIDTH, m_spnFieldWidth);
	DDX_Control(pDX, IDC_TXB_STEP_SIZE, m_edtStepSize);
	DDX_Control(pDX, IDC_TXB_ROLL_VALUE, m_edtRollOverValue);
	DDX_Control(pDX, IDC_TXB_SSN, m_edtSSN);
	DDX_Control(pDX, IDC_TXB_MSN, m_edtMSN);
	DDX_Control(pDX, IDC_TXB_MAXWIDTH, m_edtMaxWidth);
	DDX_Control(pDX, IDC_TXB_INDEX_NAME, m_editSequenceName);
	DDX_Control(pDX, IDC_CMB_SCHEMA, m_cmbBaseNumber);
	DDX_Control(pDX, IDC_CMB_CHKDIGIT, m_cmbChkDigit);
	DDX_Text(pDX, IDC_TXB_INDEX_NAME, m_csSequenceName);
	DDX_Text(pDX, IDC_TXB_MAXWIDTH, m_csMaxFieldWidth);
	DDX_Text(pDX, IDC_TXB_MSN, m_csMaxSequenceNumber);
	DDX_Text(pDX, IDC_TXB_SSN, m_csStartingSerialNumber);
	DDX_Check(pDX, IDC_CHK_EXTERNAL_NO_DUPLICATES, m_blnAllowDuplicates);
	DDX_Text(pDX, IDC_TXB_ROLL_VALUE, m_csRollOverValue);
	DDX_Text(pDX, IDC_TXB_STEP_SIZE, m_txbStepSize);
	DDX_Check(pDX, IDC_CHK_STATIC_VAR, m_blnStatic);
	DDX_Text(pDX, IDC_LBL_SSN, m_csSequenceLabel);
	DDX_Text(pDX, IDC_LBL_INDEX_NAME, m_csIndexName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep3, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep3)
	ON_WM_HELPINFO()
	ON_BN_CLICKED(IDC_CHK_STATIC_VAR, OnChkStaticVar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep3 message handlers

BOOL CAddJobStep3::OnSetActive() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	

	

	return CPropertyPage::OnSetActive();
}

LRESULT CAddJobStep3::OnWizardBack() 
{
	// TODO: Add your specialized code here and/or call the base class
	CPropertyEx* parent = (CPropertyEx*)GetParent();


	if(parent->m_lastPageID==0)
	{	
		return IDD_ADDJOB_STEP2;
	}
	return CPropertyPage::OnWizardBack();
}

LRESULT CAddJobStep3::OnWizardNext() 
{
long nCount;
long nMaxCount;

	if (!VerifyData())
	{
		return -1;

	}

	CPropertyEx* parent = (CPropertyEx*)GetParent();
	parent->m_lngCurrentCountOfSerializedIndexes++;
	
	nCount=parent->m_lngCurrentCountOfSerializedIndexes;
	nMaxCount=parent->m_lngNumberOfSerializedIndexes;
	

	parent->m_csaDataDefinition.Add(m_csSequenceName);

	if (nCount<nMaxCount)
	{
		return IDD_ADDJOB_STEP3;
	}
		
	if (parent->m_nNumberOfLabels==1)
	{
		parent->m_nMaxNumberOfTemplates=1;
		parent->m_blnUniqueTemplates=TRUE;
		return IDD_ADDJOB_STEP6;

	}
	
	return CPropertyPage::OnWizardNext();
}

BOOL CAddJobStep3::VerifyData()
{
BOOL blnReturnState=TRUE;
int nCount=0;	
	UpdateData(TRUE);
CString csBaseSchema;
CUtilities *pUtil= new  CUtilities();

	if (m_csSequenceName.IsEmpty())
	{
		m_csErrorMessage.LoadString(IDS_ERR_DATA_NAME_NOT_DEF);
		pUtil->ErrorMessage(m_csErrorMessage,1);
		delete pUtil;
		return FALSE;
	
	}
	if (m_cmbBaseNumber.GetCurSel()==-1)
	{
		m_csErrorMessage.LoadString(IDS_ERR_BASE_NAME_NOT_DEF);
		pUtil->ErrorMessage(m_csErrorMessage);
		delete pUtil;
		return FALSE;
	}
	else
	{
		m_cmbBaseNumber.GetLBText(m_cmbBaseNumber.GetCurSel(),csBaseSchema);

	}
	if (m_cmbChkDigit.GetCurSel()==-1)
	{
		m_csErrorMessage.LoadString(IDS_ERR_NO_CHK_DIGIT);
		pUtil->ErrorMessage(m_csErrorMessage);
		delete pUtil;
		return FALSE;
	}
	
	if(pUtil->IsStringEmpty(m_csStartingSerialNumber,"Starting Sequence Value Can Not Be Blank"))
	{
		delete pUtil;
		return FALSE;
	}
	
	
	if (!m_blnStatic)
		if(pUtil->IsStringEmpty(m_csMaxSequenceNumber,"Maximum Sequence Value Can Not Be Blank"))
		{
			delete pUtil;
			return FALSE;
		}
	
	if (!m_blnStatic)
		if(pUtil->IsStringEmpty(m_csRollOverValue,"Roll Over Value Can Not Be Blank"))
		{
			delete pUtil;
			return FALSE;
		}

	if (!m_blnStatic)
		if(pUtil->IsStringEmpty(m_txbStepSize,"Step Size Value Can Not Be Blank"))
		{
			delete pUtil;
			return FALSE;
		}



	if (!m_blnStatic)
	{
		CSequenceGen *pSeqGen = new CSequenceGen();
		long lngStart=0,
			 lngEnd=0,
			 lngRollOver=0;
		pSeqGen->InitSeqGenerator(csBaseSchema,atoi(m_txbStepSize));
		if(!pSeqGen->GetBase10Equivalent(m_csStartingSerialNumber,lngStart, &m_csErrorMessage))
		{
			
			pUtil->ErrorMessage(m_csErrorMessage, "Error[1]: Starting Starting Serial Number");
			delete pUtil;
			return FALSE;
		}
		if(!pSeqGen->GetBase10Equivalent(m_csMaxSequenceNumber,lngEnd, &m_csErrorMessage))
		{
			pUtil->ErrorMessage(m_csErrorMessage, "Error[1]: Maximum Sequence Number");
			delete pUtil;
			return FALSE;
		}

		if(!pSeqGen->GetBase10Equivalent(m_csRollOverValue,lngRollOver, &m_csErrorMessage))
		{
			pUtil->ErrorMessage(m_csErrorMessage, "Error[1]: Roll Over Number");
			delete pUtil;
			return FALSE;
		}

		
		
		delete pSeqGen;		// Not Needed Anymore
			
		if (lngEnd<=lngStart)
		{
			pUtil->ErrorMessage("Maximum Sequence Value Can Not Be Larger Than Initial Sequence Value");
			delete pUtil;
			return FALSE;

		}
	
	}
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	for (nCount=0;nCount<MAXDATASERIES;nCount++)
	{
		if (parent->SerialData[nCount].Name.IsEmpty())
		{
			parent->SerialData[nCount].Name =m_csSequenceName; 		

			if (m_blnStatic) 
				parent->SerialData[nCount].Static  = "YES";
			else
				parent->SerialData[nCount].Static  = "NO";




			m_cmbBaseNumber.GetLBText(m_cmbBaseNumber.GetCurSel(),
				                      parent->SerialData[nCount].BaseNumberSchema);
			parent->SerialData[nCount].StartingSequencNumber = m_csStartingSerialNumber;  
			parent->SerialData[nCount].MaxSequenceNumber = m_csMaxSequenceNumber; 
			parent->SerialData[nCount].RollOverValue = m_csRollOverValue; 
			parent->SerialData[nCount].FieldWidth = m_csMaxFieldWidth; 
			parent->SerialData[nCount].StepSize = m_txbStepSize;
			if (m_blnAllowDuplicates) 
				parent->SerialData[nCount].AllowDuplicates = "YES";
			else
				parent->SerialData[nCount].AllowDuplicates = "NO";

			m_cmbChkDigit.GetLBText(m_cmbChkDigit.GetCurSel(),
									parent->SerialData[nCount].CheckDigit);



			break;

		}

	}
	delete pUtil;
	return TRUE;
}

void CAddJobStep3::InitControls()
{
CUtilities oUtil;
NumberBases *pNumberBases;	
int nNumberBaseCntr=0;

	// init vars
	m_csMaxFieldWidth="";
	m_csMaxSequenceNumber="";
	m_csSequenceName="";
	m_csStartingSerialNumber="";
	m_cmbBaseNumber.SetWindowText(""); 
	m_cmbChkDigit.SetWindowText("");

		
	pNumberBases = oUtil.GetNumberBases();
	
	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format label controls
	GetDlgItem(IDC_LBL_INDEX_NAME)->SetFont(&font);
	GetDlgItem(IDC_LBL_BASE_NUMBER)->SetFont(&font);
	GetDlgItem(IDC_LBL_SSN)->SetFont(&font);
	GetDlgItem(IDC_LBL_MAX_SSN)->SetFont(&font);
	GetDlgItem(IDC_LBL_ROLL_SSN)->SetFont(&font);
	GetDlgItem(IDC_LBL_FIELD_WIDTH)->SetFont(&font);
	GetDlgItem(IDC_CHK_EXTERNAL_NO_DUPLICATES)->SetFont(&font);
	GetDlgItem(IDC_LBL_CHK_DIGIT)->SetFont(&font);



	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_LIGHT); 


	// format edit controls
	GetDlgItem(IDC_TXB_INDEX_NAME)->SetFont(&font);
	GetDlgItem(IDC_CMB_SCHEMA)->SetFont(&font);
	GetDlgItem(IDC_TXB_SSN)->SetFont(&font);
	GetDlgItem(IDC_TXB_MSN)->SetFont(&font);
	GetDlgItem(IDC_TXB_ROLL_VALUE)->SetFont(&font);

	
	GetDlgItem(IDC_TXB_MAXWIDTH)->SetFont(&font);
	GetDlgItem(IDC_CMB_CHKDIGIT)->SetFont(&font);

	// Step Size

	GetDlgItem(IDC_LBL_STEP_SIZE)->SetFont(&font);
	GetDlgItem(IDC_TXB_STEP_SIZE)->SetFont(&font);

	//	Static or Fixed Value

	GetDlgItem(IDC_CHK_STATIC_VAR)->SetFont(&font);



	while (!pNumberBases[nNumberBaseCntr].BaseName.IsEmpty() )
	{

		m_cmbBaseNumber.AddString(pNumberBases[nNumberBaseCntr].BaseName); 
		nNumberBaseCntr++;	
	}


	m_cmbBaseNumber.SetCurSel(0);

	
	LoadCheckDigits();

	// Set up spin buttons

	m_spnFieldWidth.SetBuddy(&m_edtMaxWidth);
	m_spnFieldWidth.SetRange(1,30);
	m_spnFieldWidth.SetPos(4);

	m_spnStepSize.SetBuddy(&m_edtStepSize);
	m_spnStepSize.SetRange(-5000,5000);
	m_spnStepSize.SetPos(1);

}


BOOL CAddJobStep3::OnHelpInfo(HELPINFO* pHelpInfo) 
{
HWND hwnd;
	UINT iContextId = pHelpInfo->iCtrlId ;

    
	if (iContextId==1040)
	{

		return ::WinHelp(AfxGetMainWnd()->m_hWnd  ,"CHECKHELP.HLP",
				HELP_INDEX,0);

	}	
	
	
	
	hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
        HH_HELP_CONTEXT,iContextId);	

	if (hwnd==NULL)
	{
		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_DISPLAY_TOPIC,0);	
	}
	return TRUE;
}

void CAddJobStep3::LoadCheckDigits()
{
CString csTemp;

	m_cmbChkDigit.AddString((LPCTSTR)"NONE");
	csTemp.LoadString(IDS_CHECK_CHOICE1);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE2);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE3);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE4);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE5);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE6);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE7);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE8);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE9);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE10);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE12);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE13);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE14);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE15);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE16);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE17);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE18);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE19);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE20);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE21);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE22);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE23);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE24);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE25);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE26);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE27);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE28);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE29);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE30);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE31);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE32);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE33);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE34);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE35);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE36);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE37);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE38);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE39);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE40);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE41);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE42);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE43);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE44);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE45);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE46);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE47);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE48);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE49);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE50);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE51);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE52);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE53);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE54);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE55);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE56);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE57);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE108);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE58);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE59);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE60);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE61);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE109);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE62);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE63);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE64);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE65);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE66);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE67);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE68);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE69);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE70);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE71);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE72);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE73);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE74);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE75);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE76);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE77);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE78);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE79);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE80);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE81);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE82);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE83);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE84);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE85);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE86);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE87);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE88);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE89);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE90);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE91);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE92);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE93);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE94);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE95);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE96);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE97);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE98);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE99);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE100);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE101);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE102);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE103);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE104);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE105);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE106);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	csTemp.LoadString(IDS_CHECK_CHOICE107);
	m_cmbChkDigit.AddString((LPCTSTR)csTemp);
	// set the combo-box selection to the first element
	m_cmbChkDigit.SetCurSel(1);


}

void CAddJobStep3::OnChkStaticVar() 
{
	UpdateData(TRUE);
	if (m_blnStatic)
	{
		m_blnAllowDuplicates=FALSE;
		m_chkAllowDuplicates.EnableWindow(FALSE); 
		m_cmbBaseNumber.EnableWindow(FALSE); 
		m_edtMSN.EnableWindow(FALSE); 
		m_edtRollOverValue.EnableWindow(FALSE); 
		m_edtStepSize.EnableWindow(FALSE);
//		m_edtMaxWidth.EnableWindow(FALSE);
		m_csIndexName = "Keyword Name:";
		m_csSequenceLabel = "Keyword Value:";

	}
	else
	{
		m_chkAllowDuplicates.EnableWindow(TRUE); 
		m_cmbBaseNumber.EnableWindow(TRUE);
		m_edtMSN.EnableWindow(TRUE);
		m_edtRollOverValue.EnableWindow(TRUE); 
		m_edtStepSize.EnableWindow(TRUE);
//		m_edtMaxWidth.EnableWindow(TRUE);
		m_csIndexName = "Data Factory Name:";
		m_csSequenceLabel = "Starting Sequence Value:";
		
	}
	UpdateData(FALSE);
}

BOOL CAddJobStep3::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	m_Tip.RelayEvent(pMsg); 
	return CPropertyPage::PreTranslateMessage(pMsg);
}

void  CAddJobStep3::CreateToolTips()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;

	SetToolTipsProperties();


	// Data Factory Name
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/Name",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",NameOfDataFactories_DefTip);
	
	m_Tip.AddTool(&m_editSequenceName, _T(csTemp), m_hIcon1);

	// Is Serialized Data
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/IsSerializedData",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",IsSerializedData_DefTip);
	
	m_Tip.AddTool(&m_chkIsStatic, _T(csTemp), m_hIcon1);

	// Allow Duplicates
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/AllowDuplicates",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",Allow_DefTip);
	
	m_Tip.AddTool(&m_chkAllowDuplicates, _T(csTemp), m_hIcon1);
	
	// Starting Sequence Number
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/StartingSequenceNumber",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",StartingSSN_DefTip);
	
	m_Tip.AddTool(&m_edtSSN, _T(csTemp), m_hIcon1);


	// Base Number Schema
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/BaseNumberSchema",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",BaseNumberSchema_DefTip);
	
	m_Tip.AddTool(&m_cmbBaseNumber, _T(csTemp), m_hIcon1);	
	

	// Check Digit
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/CheckDigit",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",CheckDigit_DefTip);
	
	m_Tip.AddTool(&m_cmbChkDigit , _T(csTemp), m_hIcon1);		
	
	// Maximum Value
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/MaximumValue",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",MaxSequenceValue_DefTip);
	
	m_Tip.AddTool(&m_edtMSN , _T(csTemp), m_hIcon1);

	// Roll Over Value
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/RollOverValue",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",RollOverValue_DefTip);
	
	m_Tip.AddTool(&m_edtRollOverValue  , _T(csTemp), m_hIcon1);		
	
	// Field Width Value
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/FieldWidth",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",FieldWidth_DefTip);
	
	m_Tip.AddTool(&m_edtMaxWidth   , _T(csTemp), m_hIcon1);			

	// Step Size
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/DataFactoryDlg/StepSize",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",StepSize_DefTip);
	
	m_Tip.AddTool(&m_edtStepSize , _T(csTemp), m_hIcon1);			

	delete pUtil;
}

void  CAddJobStep3::SetToolTipsProperties()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;
char *conGradient1 =  "//Config/ToolTips/Gradient1";
char *conGradient2 =  "//Config/ToolTips/Gradient2";
char *conGradient3 =  "//Config/ToolTips/Gradient3";

	
	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);


	csTemp=pUtil->GetConfigValue("StyleSheet",FALSE); 
	if (csTemp.IsEmpty())
	{
		csTemp.LoadString(IDS_TIP_HTML_STYLE); 
		m_Tip.SetCssStyles(csTemp);
	}
	else
	{
		m_Tip.SetCssStyles(csTemp);
	}


	csTemp=pUtil->GetConfigValue(conGradient1,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad1=BEGINTIPCOLOR;
	}
	else
	{
		m_lngColorGrad1 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient2,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad2=MIDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad2 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient3,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad3=ENDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad3 = atol(csTemp);
	}



//	m_Tip.SetColorBk(m_lngColorGrad1,m_lngColorGrad2,m_lngColorGrad3);
	m_Tip.SetColorBk(DEFCOLOR);

//	m_Tip.SetEffectBk(CPPDrawManager::EFFECT_3HGRADIENT,10);
	m_Tip.SetDelayTime(PPTOOLTIP_TIME_FADEOUT,TOOLTIP_FADEOUT);

	
	delete pUtil;

}

BOOL CAddJobStep3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
		// clear vars
	InitControls();	

	m_Tip.Create(this);
	CreateToolTips();
	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
