// VariableDataDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "VariableDataDlg.h"
#include "ZebraZPL.h"
#include "Utilities.h"

#define	  DATAFACTORIES		3	

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	FIXEDROWS		1
#define	FIXEDCOLS		1

/////////////////////////////////////////////////////////////////////////////
// CVariableDataDlg dialog


CVariableDataDlg::CVariableDataDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVariableDataDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVariableDataDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTemplateIndex=0;
	m_blnModified=FALSE;
}

CVariableDataDlg::~CVariableDataDlg()
{
	m_Grid_BC.DeleteAllItems(); 
	m_Grid_HR.DeleteAllItems();
	m_Grid_Templates.DeleteAllItems(); 
}

void CVariableDataDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVariableDataDlg)
	DDX_Control(pDX, IDC_GRID_BC, m_Grid_BC);             // associate the grid window with a C++ object
	DDX_Control(pDX, IDC_GRID_HR, m_Grid_HR);             // associate the grid window with a C++ object
	DDX_Control(pDX, IDC_GRID_TEMPLATES, m_Grid_Templates);             // associate the grid window with a C++ object
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CVariableDataDlg, CDialog)
	//{{AFX_MSG_MAP(CVariableDataDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID_BC, OnBC_GridClick)
	ON_NOTIFY(NM_CLICK, IDC_GRID_HR, OnHR_GridClick)
	ON_NOTIFY(NM_CLICK, IDC_GRID_TEMPLATES, OnTemplates_GridClick)
	ON_WM_SHOWWINDOW()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVariableDataDlg message handlers

void CVariableDataDlg::OnBC_GridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
}

void CVariableDataDlg::OnHR_GridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    
}


void CVariableDataDlg::OnTemplates_GridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
static nLastIndex=0;  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

	if (pItem->iRow==0) return; 
	if (!m_Grid_Templates.GetItemText(pItem->iRow,0).IsEmpty())
	{
	
		// check for changes
		

		
		ScanForChanges();
		VerifyBCGrid();
		VerifyHRGrid();

		m_csCurrentName=m_Grid_Templates.GetItemText(pItem->iRow,0);
		m_nTemplateIndex=pItem->iRow-1;
		
		if (nLastIndex!=m_nTemplateIndex)
		{
			UpdateGrids();
			nLastIndex=m_nTemplateIndex;
		}
	}
}



void CVariableDataDlg::InitBC_Grid() 
{
CStringArray options;
int	nCount;
		
	m_Grid_BC.SetRowCount(MAXVARS);
	m_Grid_BC.SetColumnCount(4);
	m_Grid_BC.SetFixedRowCount(1);
	m_Grid_BC.SetFixedColumnCount(1);
	m_Grid_BC.SetSingleColSelection(FALSE);
	m_Grid_BC.SetSingleRowSelection(FALSE); 

    m_Grid_BC.SetItemText(0,0,"Name");
    m_Grid_BC.SetItemText(0,1,"Prefix");
    m_Grid_BC.SetItemText(0,2,"Suffix");
    m_Grid_BC.SetItemText(0,3,"Data");
	

	
	m_Grid_BC.SetColumnWidth(0,75);
	m_Grid_BC.SetColumnWidth(1,130);
	m_Grid_BC.SetColumnWidth(2,130);
	m_Grid_BC.SetColumnWidth(3,130);


	for (nCount=0;nCount<MAXVARS;nCount++)
	{
		m_Grid_BC.SetItemFormat(nCount,0,DT_CENTER|DT_VCENTER);
		m_Grid_BC.SetItemFormat(nCount,1,DT_CENTER|DT_VCENTER);
		m_Grid_BC.SetItemFormat(nCount,2,DT_CENTER|DT_VCENTER);
		m_Grid_BC.SetItemFormat(nCount,3,DT_CENTER|DT_VCENTER);
		m_Grid_BC.SetRowHeight(nCount,25); 

	}

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid_BC.SetFont(&font);
	m_Grid_BC.ExpandColumnsToFit(TRUE); 

}


void CVariableDataDlg::InitHR_Grid() 
{
CStringArray options;
int	nCount;
   




		
	m_Grid_HR.SetRowCount(MAXVARS);
	m_Grid_HR.SetColumnCount(4);
	m_Grid_HR.SetFixedRowCount(FIXEDROWS);
	m_Grid_HR.SetFixedColumnCount(1);
	m_Grid_HR.SetSingleColSelection(FALSE);
	m_Grid_HR.SetSingleRowSelection(FALSE); 


    m_Grid_HR.SetItemText(0,0,"Name");
    m_Grid_HR.SetItemText(0,1,"Prefix");
    m_Grid_HR.SetItemText(0,2,"Suffix");
    m_Grid_HR.SetItemText(0,3,"Data");
	

	
	m_Grid_HR.SetColumnWidth(0,75);
	m_Grid_HR.SetColumnWidth(1,130);
	m_Grid_HR.SetColumnWidth(2,130);
	m_Grid_HR.SetColumnWidth(3,130);


	for (nCount=0;nCount<MAXVARS;nCount++)
	{
		m_Grid_HR.SetItemFormat(nCount,0,DT_CENTER|DT_VCENTER);
		m_Grid_HR.SetItemFormat(nCount,1,DT_CENTER|DT_VCENTER);
		m_Grid_HR.SetItemFormat(nCount,2,DT_CENTER|DT_VCENTER);
		m_Grid_HR.SetItemFormat(nCount,3,DT_CENTER|DT_VCENTER);
		m_Grid_HR.SetRowHeight(nCount,25); 

	}

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid_HR.SetFont(&font);
	m_Grid_HR.ExpandColumnsToFit(TRUE);
	
}

void CVariableDataDlg::InitTemplates_Grid() 
{
CStringArray options;
int	nCount;
   




		
	m_Grid_Templates.SetRowCount(MAXTEMPLATES);
	m_Grid_Templates.SetColumnCount(1);
	m_Grid_Templates.SetFixedRowCount(FIXEDROWS);

	m_Grid_Templates.SetSingleColSelection(FALSE);
	m_Grid_Templates.SetSingleRowSelection(FALSE); 


    m_Grid_Templates.SetItemText(0,0,"Template");
	

	
	m_Grid_Templates.SetColumnWidth(0,150);


	for (nCount=0;nCount<MAXTEMPLATES;nCount++)
	{
		m_Grid_Templates.SetItemFormat(nCount,0,DT_CENTER|DT_VCENTER);
		if (nCount==0)
			m_Grid_Templates.SetRowHeight(nCount,25); 
		else
			m_Grid_Templates.SetRowHeight(nCount,20); 

	}

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid_Templates.SetFont(&font);




	
}


BOOL CVariableDataDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
		

	// format label controls
	GetDlgItem(IDC_LBL_BARCODE_DATA)->SetFont(&font);
	GetDlgItem(IDC_LBL_HR_DATA)->SetFont(&font);


	
	InitBC_Grid();
	InitHR_Grid();
	InitTemplates_Grid();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CVariableDataDlg::UpdateGrids()
{
int nCount=0;
	
	GetDataSeries();
	while (!m_pJobInfo->Templates[nCount].Name.IsEmpty())
	{
		m_Grid_Templates.SetItemText(nCount+FIXEDROWS,0,
			m_pJobInfo->Templates[nCount].Name );
		nCount++;
	}



	for (nCount=0;nCount<MAXVARS;nCount++)
	{
		
		if (!m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Name.IsEmpty())
		{		
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,0,
				m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Name );
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,1,
				m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Prefix);
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,2,
				m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Suffix);
//			m_Grid_BC.SetItemText(nCount+FIXEDROWS,3,
//				m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Data);
			ProcessDataFactoriesCell(nCount+FIXEDROWS, nCount);
	
		}
		else
		{
			if (m_Grid_BC.GetItemText(nCount+FIXEDROWS,0).IsEmpty()) break;  
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,0,"");
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,1,"");
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,2,"");
			m_Grid_BC.SetItemText(nCount+FIXEDROWS,3,"");

		}

	}
	m_Grid_BC.Refresh(); 


	for (nCount=0;nCount<MAXVARS;nCount++)
	{
		
		if (!m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nCount].Name.IsEmpty())
		{
		
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,0,
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nCount].Name );
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,1,
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nCount].Prefix);
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,2,
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nCount].Suffix);
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,3,
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nCount].Data);
		}
		else
		{
			if (m_Grid_HR.GetItemText(nCount+FIXEDROWS,0).IsEmpty()) break;  
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,0,"");
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,1,"");
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,2,"");
			m_Grid_HR.SetItemText(nCount+FIXEDROWS,3,"");



		}

	}
	UpdateData(FALSE);
	m_Grid_HR.Refresh(); 

	m_Grid_BC.SetModified(FALSE);
	m_Grid_HR.SetModified(FALSE);

}

BOOL CVariableDataDlg::VerifyGrids()
{
	if(!VerifyBCGrid())
		return FALSE;

	if(!VerifyHRGrid())
		return FALSE;

	return TRUE;
}

BOOL CVariableDataDlg::VerifyBCGrid()
{

CString csName;
CString csPrefix;	
CString csSuffix;
CString csData;


	for (int nID=0;nID<MAXVARS;nID++)
	{
		  
		csName.Format("%s",m_Grid_BC.GetItemText(nID+FIXEDROWS,0));

		
		if (!csName.IsEmpty())	// No need for a combo if only one data definition
		{


			for (int nColumn=0;nColumn<m_Grid_BC.GetColumnCount();nColumn++)
			{
				if( m_Grid_BC.IsCellSelected(nID+FIXEDROWS,nColumn) )
				{
					CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid_BC.GetCell(nID+FIXEDROWS,nColumn);
					pCell->EndEdit();  
				
				}
			}


			csPrefix.Format("%s",m_Grid_BC.GetItemText(nID+FIXEDROWS,1));
			csSuffix.Format("%s",m_Grid_BC.GetItemText(nID+FIXEDROWS,2));
			csData.Format("%s",m_Grid_BC.GetItemText(nID+FIXEDROWS,3));
			
			// Since there is as of 10/28/04 only 1 barcode allowed per template
//			m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nID].Name  = csName;
			m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nID].Prefix = csPrefix;
			m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nID].Suffix = csSuffix;
			m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nID].Data = csData;
			m_blnModified=TRUE;

		
		}
		else
			break;

	}

	return TRUE;
}

BOOL CVariableDataDlg::VerifyHRGrid()
{

CString csName;
CString csPrefix;	
CString csSuffix;
CString csData;


	for (int nID=0;nID<MAXVARS;nID++)
	{
		csName.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,0));
		if (!csName.IsEmpty())	// No need for a combo if only one data definition
		{


			for (int nColumn=0;nColumn<m_Grid_HR.GetColumnCount();nColumn++)
			{
				if( m_Grid_HR.IsCellSelected(nID+FIXEDROWS,nColumn) )
				{
					CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid_HR.GetCell(nID+FIXEDROWS,nColumn);
					pCell->EndEdit();  
				
				}
			}
			
			csPrefix.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,1));
			csSuffix.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,2));
			csData.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,3));

			if (m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Name.IsEmpty())
			{
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Name  = "";
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Prefix  = "";
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Suffix = "";
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Data = "";
			}
			else
			{
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Prefix  = csPrefix;
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Suffix =  csSuffix;
				if (!csData.IsEmpty()) 
					m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Data = csData;
			}
			m_blnModified=TRUE;
		
		}
		else if (!m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Name.IsEmpty())
		{

			csPrefix.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,1));
			csSuffix.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,2));
			csData.Format("%s",m_Grid_HR.GetItemText(nID+FIXEDROWS,3));

		
			m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Prefix  = csPrefix;
			m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Suffix =  csSuffix;
		
			if (!csData.IsEmpty()) 
				m_pJobInfo->Templates[m_nTemplateIndex].HRVars[nID].Data = csData;
			m_blnModified=TRUE;

		}
		else

			break;

	}

	return TRUE;

}

BOOL CVariableDataDlg::ScanForChanges()
{

CZebraZPL ZebraPrinter;
int nNumberOfBarCodeVars=0;
int nCount=0,
	nIndex=0,
	nMaxVarNameFoundIndex=0;
CStringArray csBCVars;
int nNumberOfBC_vars;
CString csTemp;
CString csFormat;

BOOL blnFound=FALSE;
	
	if (!m_csCurrentName.IsEmpty())
	{
		csBCVars.RemoveAll(); 
		ZebraPrinter.ReadTemplate(m_csCurrentName);
		ZebraPrinter.ScanForVars(); 
		nNumberOfBC_vars=ZebraPrinter.GetCountOfBarCodeVars();
		if (nNumberOfBC_vars==0) return TRUE;

		for (nCount=0;nCount<nNumberOfBC_vars;nCount++)
		{
			csBCVars.Add(ZebraPrinter.GetBCVar(nCount)); 

		}
		for (nCount=0;nCount<MAXVARS;nCount++)
		{
		  csTemp = m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Name;
		  if (csTemp.IsEmpty()) break; 	
		  blnFound=FALSE;			// one BC per label
		  for (nIndex=nMaxVarNameFoundIndex;nIndex<nNumberOfBC_vars;nIndex++)
		  {
				if (csBCVars.GetAt(nIndex)==csTemp)
				{
					blnFound=TRUE;
					break;
				}

		  }
		  if(!blnFound)break;
		  nMaxVarNameFoundIndex++;	// for the future where there may be more than
		}

		UpdateData(FALSE);
	}
	if(!blnFound)
	{
		// Bar Code Variables Always Require  A Data Factory
		// A Bar code variable without a data factory is static and should remove its []
		CUtilities *pUtil = new CUtilities();
		csFormat.LoadString(IDS_ERR_MISSING_DATA_FACTORY);
		if (csBCVars.GetSize()>0) 
		{
			csTemp.Format(csFormat,csBCVars.GetAt(nMaxVarNameFoundIndex));
			pUtil->ErrorMessage( csTemp,2); 
		}
		delete pUtil;
		return FALSE;
	}
	return TRUE;
}


BOOL CVariableDataDlg::IsModified()
{
CString csTemp;
int nID,
	nColumn;
	if (m_blnModified) return TRUE;
	for (nID=0;nID<MAXVARS;nID++)
	{
		for (nColumn=0;nColumn<m_Grid_BC.GetColumnCount();nColumn++)
		{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid_BC.GetCell(nID+FIXEDROWS,nColumn);
				csTemp.Empty(); 
				csTemp=pCell->GetText();
				if (csTemp.IsEmpty()) return FALSE; 

				if (pCell->IsModified())
					return TRUE;
				if( pCell->IsSelected() )
				{
					pCell->EndEdit();
					if (pCell->IsModified())
						return TRUE;
				}

		}
	}

	for (nID=0;nID<MAXVARS;nID++)
	{
		for (nColumn=0;nColumn<m_Grid_HR.GetColumnCount();nColumn++)
		{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid_HR.GetCell(nID+FIXEDROWS,nColumn);
				csTemp.Empty(); 
				csTemp=pCell->GetText();
				if (csTemp.IsEmpty()) return FALSE; 

				if (pCell->IsModified())
					return TRUE;
				if( pCell->IsSelected() )
				{
					pCell->EndEdit();
					if (pCell->IsModified())
						return TRUE;
				}

		}
	}
	
	
	
	return FALSE;
}

void CVariableDataDlg::GetDataSeries()
{
int nCount=0;
	m_csaDataSeries.RemoveAll();
	
	while (!m_pJobInfo->SerialData[nCount].Name.IsEmpty()) 
	{
	
		m_csaDataSeries.Add(m_pJobInfo->SerialData[nCount].Name); 
		nCount++;
	}
		


}

void CVariableDataDlg::ProcessDataFactoriesCell(int nRowID, int nCount)
{
CGridCellCombo *pCell;
CString csDataFactory = m_pJobInfo->Templates[m_nTemplateIndex].BCVars[nCount].Data; 

	// Data Series
	if (!m_Grid_BC.SetCellType(nRowID,DATAFACTORIES, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid_BC.GetCell(nRowID,DATAFACTORIES);
	pCell->SetOptions(m_csaDataSeries);
	pCell->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE

	m_Grid_BC.SetItemText(nRowID,DATAFACTORIES,csDataFactory);

}

