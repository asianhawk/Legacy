// AddJobStep5.cpp : implementation file
//



#include "stdafx.h"
#include "JoTS.h"
#include "AddJobStep5.h"
#include "PropertyEx.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


	// begin tool tip stuff

const char *LabelID_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Label ID:</font><br><t> - maximum 80 characters in length;<br><t> - optional field <br></td></tr></table>");
const char *TemplateID_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>Select Template:</font><br><t> - Select A Template From The List Box<br><t> - Current Selection Is Displayed <br><t> - Press The \"View\" Button To Examine Highlighted Template <br></td></tr></table>");
const char *TemplateView_DefTip = _T("<table><tr><td><icon idres=142 width=48 height=48></td><td><center><h2>Job Wizard</h2></center><br><hr color=green><br><font color=red size=12pt style=b>View Template:</font><br><t> - Press View Button To Examine Template<br><t> - Current Selection Is Displayed <br><t> - Template Is Not Editable <br></td></tr></table>");

	// end tool tip stuff



/////////////////////////////////////////////////////////////////////////////
// CAddJobStep5 property page

IMPLEMENT_DYNCREATE(CAddJobStep5, CPropertyPage)

CAddJobStep5::CAddJobStep5() : CPropertyPage(CAddJobStep5::IDD)
{
	//{{AFX_DATA_INIT(CAddJobStep5)
	m_blnVerify = FALSE;
	m_blnScanLabel = FALSE;
	m_csLabelOrder = _T("");
	m_optRotationType = 0;
	//}}AFX_DATA_INIT
	m_blnDisplayScannerPrompts=FALSE;
	m_blnDisplayRotatePrompts=FALSE;
	m_pColorWnd=NULL;

}

CAddJobStep5::~CAddJobStep5()
{
	if (m_pColorWnd)
	{
		m_pColorWnd->DestroyWindow();
		delete m_pColorWnd;
	}
	if (m_Tip)
	{
		m_Tip.RemoveAllTools();
		m_Tip.DestroyWindow();

	}
}

void CAddJobStep5::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddJobStep5)
	DDX_Control(pDX, IDC_BTN_VIEW_TEMPLATE, m_btnViewTemplate);
	DDX_Control(pDX, IDC_LBL_ORDER, m_lblLabelID);
	DDX_Control(pDX, IDC_CMB_ROTATION_ANGLE, m_cmbRotationAngle);
	DDX_Control(pDX, IDC_CMB_TEMPLATES, m_cmbTemplateName);
	DDX_Check(pDX, IDC_CHK_VERIFY, m_blnVerify);
	DDX_Check(pDX, IDC_CHK_SCAN_LABEL, m_blnScanLabel);
	DDX_Text(pDX, IDC_LBL_ORDER, m_csLabelOrder);
	DDX_Radio(pDX, IDC_CW, m_optRotationType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddJobStep5, CPropertyPage)
	//{{AFX_MSG_MAP(CAddJobStep5)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BTN_VIEW_TEMPLATE, OnBtnViewTemplate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddJobStep5 message handlers

BOOL CAddJobStep5::OnSetActive() 
{
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	

	return CPropertyPage::OnSetActive();
}

LRESULT CAddJobStep5::OnWizardNext() 
{
CString csBuffer;
int nCount;
int nMaxCount,
	nTemplateIndex;
	UpdateData(TRUE);
	CPropertyEx* parent = (CPropertyEx*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	nTemplateIndex=m_cmbTemplateName.GetCurSel(); 
	
	if (parent->m_blnUniqueTemplates)
	{
		
		for (nCount=0;nCount<parent->m_nNumberOfLabels;nCount++)
		{
			parent->LabelData[nCount].PrintOrder = nCount+1;
			m_cmbTemplateName.GetLBText(nTemplateIndex,parent->LabelData[nCount].TemplateName);
			if (m_blnScanLabel) 
				parent->LabelData[nCount].ScanLabel   = "YES";
			else
				parent->LabelData[nCount].ScanLabel   = "NO";


			if (m_blnVerify) 
				parent->LabelData[nCount].VerifyLabel    = "YES";
			else
				parent->LabelData[nCount].VerifyLabel   = "NO";


			m_cmbRotationAngle.GetLBText(m_cmbRotationAngle.GetCurSel(),csBuffer);
			if (m_optRotationType==CW_ROTATION) 
			{

				parent->LabelData[nCount].RotationAngle.Format("%d", atoi(csBuffer)*1);  
			}
			else
			{
				parent->LabelData[nCount].RotationAngle.Format("%d", atoi(csBuffer)*-1);  


			}


		}

	}
	else
	{
		nCount=parent->m_nCurrentTemplateIndex;

		parent->LabelData[nCount].PrintOrder= nCount;
		m_cmbTemplateName.GetLBText(nTemplateIndex,parent->LabelData[nCount].TemplateName);
		if (m_blnScanLabel) 
			parent->LabelData[nCount].ScanLabel   = "YES";
		else
			parent->LabelData[nCount].ScanLabel   = "NO";


		if (m_blnVerify) 
			parent->LabelData[nCount].VerifyLabel    = "YES";
		else
			parent->LabelData[nCount].VerifyLabel   = "NO";
		
		m_cmbRotationAngle.GetLBText(m_cmbRotationAngle.GetCurSel(),csBuffer);
		if (m_optRotationType==CW_ROTATION) 
		{

			parent->LabelData[nCount].RotationAngle.Format("%d", atoi(csBuffer)*1);  
		}
		else
		{
			parent->LabelData[nCount].RotationAngle.Format("%d", atoi(csBuffer)*-1);  


		}

		

		
		
		nMaxCount=parent->m_nNumberOfLabels;
		parent->m_nCurrentTemplateIndex++;

		if (parent->m_nCurrentTemplateIndex<nMaxCount)
		{
			CString csTemp;
			csTemp.Format("%d",parent->m_nCurrentTemplateIndex+1);
			GetDlgItem(IDC_LBL_ORDER)->SetWindowText(csTemp);
			return IDD_ADDJOB_STEP5;
		}


	}
	return CPropertyPage::OnWizardNext();
}


void CAddJobStep5::InitControls()
{
int nTemplateCount,
	nMaxTemplates;

	m_cmbTemplateName.ResetContent(); 




	CPropertyEx* parent = (CPropertyEx*)GetParent();
	if ((parent->m_blnUniqueTemplates)||(parent->m_nNumberOfLabels==1) )
	{
		GetDlgItem(IDC_LBL_ORDER)->ShowWindow(TRUE);
		GetDlgItem(IDC_LBL_LABEL_ORDER)->ShowWindow(TRUE);
		GetDlgItem(IDC_LBL_ORDER)->SetWindowText("1");

	}
	else
	{
		GetDlgItem(IDC_LBL_ORDER)->ShowWindow(TRUE);
		GetDlgItem(IDC_LBL_LABEL_ORDER)->ShowWindow(TRUE);

	}

	nMaxTemplates=parent->m_csaTemplates.GetSize();

	for (nTemplateCount=0;nTemplateCount<nMaxTemplates;nTemplateCount++)
	{
		m_cmbTemplateName.AddString(parent->m_csaTemplates.GetAt(nTemplateCount));  

	}
	m_cmbTemplateName.SetCurSel(0); 


	m_csLabelOrder.Format("%d",parent->m_nCurrentTemplateIndex+1);
//	UpdateData(FALSE);


}

BOOL CAddJobStep5::OnInitDialog() 
{
CUtilities *pUtil;
	CPropertyPage::OnInitDialog();

	CAutoFont font("Arial");

	InitControls();


	m_stdFont.SetFaceName(_T("Arial"));
	m_stdFont.SetHeight(16);
	m_stdFont.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	m_stdFont.SetWeight(FW_BOLD); 
		
	m_ViewFont.SetFaceName(_T("Arial"));
	m_ViewFont.SetHeight(12);
	m_ViewFont.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	m_ViewFont.SetWeight(FW_BOLD); 
	m_ViewFont.SetItalic(TRUE);

	// format label controls
	GetDlgItem(IDC_LBL_LABEL_ORDER)->SetFont(&m_stdFont);
	GetDlgItem(IDC_LBL_ORDER)->SetFont(&m_stdFont);

	GetDlgItem(IDC_LBL_SELECT_TEMPLATE)->SetFont(&m_stdFont);
	GetDlgItem(IDC_LBL_SCAN_TEMPLATE)->SetFont(&m_stdFont);
	GetDlgItem(IDC_LBL_VERIFY_LABEL)->SetFont(&m_stdFont);
	
	GetDlgItem(IDC_LBL_ROTATION_ANGLE)->SetFont(&m_stdFont);
	
	// combo boxes
	
	GetDlgItem(IDC_CMB_TEMPLATES)->SetFont(&m_stdFont);
	GetDlgItem(IDC_CMB_ROTATION_ANGLE)->SetFont(&m_stdFont);

	// opt boxes
	
	GetDlgItem(IDC_CW)->SetFont(&m_stdFont);
	GetDlgItem(IDC_CCW)->SetFont(&m_stdFont);




	
	CPropertyEx* parent = (CPropertyEx*)GetParent();
	m_csLabelOrder.Format("%d",parent->m_nCurrentTemplateIndex+1);

	m_cmbRotationAngle.SetCurSel(0); 
	
	pUtil = new CUtilities();
	m_blnDisplayScannerPrompts = pUtil->IsScannerUsed(MORPHOR_BC_SCANNER_ID);
	m_blnDisplayRotatePrompts = pUtil->IsSupportRotation();
	
	delete pUtil;
	DisplayScannerControls(m_blnDisplayScannerPrompts);
	DisplayRotationControls(m_blnDisplayRotatePrompts);


		// Create the tool tip
	m_Tip.Create(this);
	SetToolTipsProperties();

	CreateToolTips();

	UpdateData(FALSE);

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CAddJobStep5::DisplayScannerControls(BOOL blnVisible)
{
	GetDlgItem(IDC_LBL_SCAN_TEMPLATE)->ShowWindow(blnVisible);
	GetDlgItem(IDC_CHK_SCAN_LABEL)->ShowWindow(blnVisible);
	GetDlgItem(IDC_LBL_VERIFY_LABEL)->ShowWindow(blnVisible);
	GetDlgItem(IDC_CHK_VERIFY)->ShowWindow(blnVisible);


}

		
void CAddJobStep5::DisplayRotationControls(BOOL blnVisible)
{
	GetDlgItem(IDC_LBL_ROTATION_ANGLE)->ShowWindow(blnVisible);
	GetDlgItem(IDC_CMB_ROTATION_ANGLE)->ShowWindow(blnVisible);
	GetDlgItem(IDC_CW)->ShowWindow(blnVisible);
	GetDlgItem(IDC_CCW)->ShowWindow(blnVisible);
	GetDlgItem(IDC_LBL_ROT_FRAME)->ShowWindow(blnVisible);


}

BOOL CAddJobStep5::PreTranslateMessage(MSG* pMsg) 
{
	m_Tip.RelayEvent(pMsg);	
	return CPropertyPage::PreTranslateMessage(pMsg);
}

void  CAddJobStep5::SetToolTipsProperties()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;
char *conGradient1 =  "//Config/ToolTips/Gradient1";
char *conGradient2 =  "//Config/ToolTips/Gradient2";
char *conGradient3 =  "//Config/ToolTips/Gradient3";

	
	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);


	csTemp=pUtil->GetConfigValue("StyleSheet",FALSE); 
	if (csTemp.IsEmpty())
	{
		csTemp.LoadString(IDS_TIP_HTML_STYLE); 
		m_Tip.SetCssStyles(csTemp);
	}
	else
	{
		m_Tip.SetCssStyles(csTemp);
	}


	csTemp=pUtil->GetConfigValue(conGradient1,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad1=BEGINTIPCOLOR;
	}
	else
	{
		m_lngColorGrad1 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient2,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad2=MIDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad2 = atol(csTemp);
	}

	csTemp=pUtil->GetConfigValue(conGradient3,FALSE); 
	if (csTemp.IsEmpty())
	{
		m_lngColorGrad3=ENDTIPCOLOR;
	}
	else
	{
		m_lngColorGrad3 = atol(csTemp);
	}



//	m_Tip.SetColorBk(m_lngColorGrad1,m_lngColorGrad2,m_lngColorGrad3);
	m_Tip.SetColorBk(DEFCOLOR);

//	m_Tip.SetEffectBk(CPPDrawManager::EFFECT_3HGRADIENT,10);
	m_Tip.SetDelayTime(PPTOOLTIP_TIME_FADEOUT,TOOLTIP_FADEOUT);

	
	delete pUtil;

}

void  CAddJobStep5::CreateToolTips()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;


	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard2/LabelID",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",LabelID_DefTip);
	
	m_Tip.AddTool(&m_lblLabelID, _T(csTemp), m_hIcon1);


	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard2/TemplateTIP",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",TemplateID_DefTip);
	
	m_Tip.AddTool(&m_cmbTemplateName, _T(csTemp), m_hIcon1);
	
	
	csTemp=pUtil->GetConfigValue("//Config/ToolTips/JobWizard2/TemplateView",FALSE); 
	if (csTemp.IsEmpty())
		csTemp.Format("%s",TemplateView_DefTip);
	
	m_Tip.AddTool(&m_btnViewTemplate, _T(csTemp), m_hIcon1);
	
	
	
	delete pUtil;
}


void CAddJobStep5::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	m_btnViewTemplate.SetFont(&m_ViewFont,TRUE); 


	
	// Do not call CPropertyPage::OnPaint() for painting messages
}

void CAddJobStep5::OnBtnViewTemplate() 
{

CString csInput;
CString csFileName;
CUtilities *pUtil=new CUtilities();
CString csTemplateDir;
CString csTemp;

	m_btnViewTemplate.GetWindowText(csTemp);
	csTemp.MakeUpper(); 
	if (csTemp.Find("VIEW")!=-1)
	{
		DisplayScannerControls(FALSE);
		DisplayRotationControls(FALSE);
		
		GetDlgItem(IDC_LBL_ROT_FRAME)->ShowWindow(TRUE);
		
		pUtil->GetZebraPrinterTemplateDirectory(&csTemplateDir);
		if (csTemplateDir.IsEmpty())
		{
			pUtil->ErrorMessage("Template Directory Not Found"); 

		}
		delete pUtil;		
		

		m_cmbTemplateName.GetWindowText(csFileName); 
		csFileName = csTemplateDir +	csFileName;  

		CStdioFile f;
		if (!f.Open(csFileName, CFile::modeRead | CFile::typeText))
		{
		 AfxMessageBox("Can't open that file");
		 return;
		}

		CString t;
		while (f.ReadString(t))
		{
		 csInput+=t;
		 csInput+="\n"; // ReadString strips these
		}

		f.Close();

		DisplayTemplate(csInput);

		m_btnViewTemplate.SetWindowText("Close");  
		m_cmbTemplateName.EnableWindow(FALSE); 
	}
	else
	{
			m_btnViewTemplate.SetWindowText("View");  
			m_pColorWnd->DestroyWindow();
			if(m_pColorWnd)			//playing it safe
			{
				delete m_pColorWnd;
				m_pColorWnd=NULL;
			}
			DisplayScannerControls(m_blnDisplayScannerPrompts);
			DisplayRotationControls(m_blnDisplayRotatePrompts);
			m_cmbTemplateName.EnableWindow(TRUE); 
				

	}

	
}
void CAddJobStep5::DisplayTemplate(CString csTemplate)
{

	CRect frameRect;
	GetDlgItem(IDC_LBL_ROT_FRAME)->GetWindowRect(frameRect);
	ScreenToClient(frameRect);
	frameRect.InflateRect(-2,-2);


	CString keywordsFile = "c:\\JoTS\\Keywords.ini";
	long iTabSize = 4;   // number of spaces in a tab. tabs are always spaces.
	int iFontSize = 100; //font size * 10 (I.E. 100 = 10pt)
	CString csFontName = "Courier New";
   
   
	m_pColorWnd = new ColorEditWnd(this,			      // parent window
		                           frameRect,			   // initial size and position
		                           ID_EDIT_WND,	      // id value
		                           iTabSize,		
		                           iFontSize,		
		                           csFontName);


   // put a little space between the chars
   m_pColorWnd->SetCharXSpacing(2);

   // we'll use a custom colorizer
   m_pColorWnd->SetColorizer(&m_colorizer);

   m_pColorWnd->SetHighlightColor(RGB(0,0,0));
   m_pColorWnd->SetReadOnly(TRUE);

 //  m_pColorWnd->SetSelection(0,0,10,40);
 //  m_pColorWnd->ReplaceSelText("#this is a comment\nThis is some text\n\n@:label\nThat was a label...\nHere's a special sequence:\n@+\nmore text ");

   m_pColorWnd->ClearUndoHistory();

   // load the keywords file
   m_colorizer.LoadKeywordFile(keywordsFile);

   m_pColorWnd->SetFocus();

   m_pColorWnd->LoadText(csTemplate);


}

LRESULT CAddJobStep5::OnWizardBack() 
{

	
	return IDD_ADDJOB_STEP2;
}
