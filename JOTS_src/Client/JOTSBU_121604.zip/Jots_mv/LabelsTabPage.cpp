// LabelsTabPage.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "LabelsTabPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLabelsTabPage dialog


CLabelsTabPage::CLabelsTabPage(CWnd* pParent /*=NULL*/)
	: CTabPageSSL(CLabelsTabPage::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CLabelsTabPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLabelsTabPage::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CLabelsTabPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLabelsTabPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLabelsTabPage, CDialog)
	//{{AFX_MSG_MAP(CLabelsTabPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CLabelsTabPage, CDialog)
	//{{AFX_DISPATCH_MAP(CLabelsTabPage)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ILabelsTabPage to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {8FFCF187-F58B-4C72-8FC2-E567657C1BEE}
static const IID IID_ILabelsTabPage =
{ 0x8ffcf187, 0xf58b, 0x4c72, { 0x8f, 0xc2, 0xe5, 0x67, 0x65, 0x7c, 0x1b, 0xee } };

BEGIN_INTERFACE_MAP(CLabelsTabPage, CDialog)
	INTERFACE_PART(CLabelsTabPage, IID_ILabelsTabPage, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLabelsTabPage message handlers
