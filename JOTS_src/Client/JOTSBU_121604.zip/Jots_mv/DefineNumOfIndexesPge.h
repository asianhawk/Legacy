#if !defined(AFX_DEFINENUMOFINDEXESPGE_H__8B458D50_4B71_4107_BDFF_2075381B5652__INCLUDED_)
#define AFX_DEFINENUMOFINDEXESPGE_H__8B458D50_4B71_4107_BDFF_2075381B5652__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DefineNumOfIndexesPge.h : header file
//
#include "tooltip/PPTooltip.h"
#include "Edit Class Ex/amsEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CDefineNumOfIndexesPge dialog

class CDefineNumOfIndexesPge : public CPropertyPage
{
	DECLARE_DYNCREATE(CDefineNumOfIndexesPge)

// Construction
public:
	CDefineNumOfIndexesPge();
	~CDefineNumOfIndexesPge();
	void						InitControls();
	void						CreateToolTips();
	void						SetToolTipsProperties();
// Dialog Data
	//{{AFX_DATA(CDefineNumOfIndexesPge)
	enum { IDD = IDD_ADDJOB_STEP2A };
	CButton	m_frmSerialedData;
	CButton	m_optSerializedData;
	CButton	m_chkUseExternal;
	CSpinButtonCtrl	m_spnNumberOfDataFactories;
	CAMSNumericEdit	m_edtNumberOfIndexes;
	CString	m_csInstructions;
	CString	m_csNumberOfIndexes;
	int		m_nSerializedData;
	BOOL	m_blnExternalDataSource;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDefineNumOfIndexesPge)
	public:
	virtual LRESULT OnWizardNext();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDefineNumOfIndexesPge)
	virtual BOOL OnInitDialog();
	afx_msg void OnOpt1SerializedData();
	afx_msg void OnOpt1NonserializedData();
	afx_msg void OnChkExternal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CPPToolTip 		m_Tip;
	HICON			m_hIcon1;
	long			m_lngColorGrad1;
	long			m_lngColorGrad2;
	long			m_lngColorGrad3;


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEFINENUMOFINDEXESPGE_H__8B458D50_4B71_4107_BDFF_2075381B5652__INCLUDED_)
