// JoTS_ComSimDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS_ComSim.h"
#include "JoTS_ComSimDlg.h"
#include "DlgProxy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
			//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlg dialog

IMPLEMENT_DYNAMIC(CJoTS_ComSimDlg, CDialog);

CJoTS_ComSimDlg::CJoTS_ComSimDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CJoTS_ComSimDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJoTS_ComSimDlg)
	m_csResponseMsg = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAutoProxy = NULL;
}

CJoTS_ComSimDlg::~CJoTS_ComSimDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
		m_pAutoProxy->m_pDialog = NULL;
}

void CJoTS_ComSimDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJoTS_ComSimDlg)
	DDX_Control(pDX, IDC_CMB_RESPONSES, m_cmbResponses);
	DDX_Control(pDX, IDC_BTN_TX_RESP, m_btnTransmit);
	DDX_Control(pDX, IDC_TXB_DISPLAY, m_edtDisplay);
	DDX_CBString(pDX, IDC_CMB_RESPONSES, m_csResponseMsg);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CJoTS_ComSimDlg, CDialog)
	//{{AFX_MSG_MAP(CJoTS_ComSimDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_OPEN_COM_PORT, OnBtnOpenComPort)
	ON_BN_CLICKED(IDC_BTN_TX_RESP, OnBtnTxResp)
	//}}AFX_MSG_MAP
	ON_WM_SERIAL(OnSerialMsg)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlg message handlers

BOOL CJoTS_ComSimDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	m_cmbResponses.AddString("OK");
	m_cmbResponses.AddString("APPERROR");


	m_edtDisplay.EnableWindow(FALSE); 
	m_cmbResponses.EnableWindow(FALSE); 
	m_btnTransmit.EnableWindow(FALSE);
	

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CJoTS_ComSimDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CJoTS_ComSimDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CJoTS_ComSimDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CJoTS_ComSimDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CJoTS_ComSimDlg::OnClose() 
{
	if (CanExit())
		CDialog::OnClose();
}

void CJoTS_ComSimDlg::OnOK() 
{
	if (CanExit())
		CDialog::OnOK();
}

void CJoTS_ComSimDlg::OnCancel() 
{
	if (CanExit())
		CDialog::OnCancel();
}

BOOL CJoTS_ComSimDlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	return TRUE;
}

void CJoTS_ComSimDlg::OnBtnOpenComPort() 
{

	if(m_pComPort.Open("COM2",this))
	{
		AfxMessageBox("Com Port Did Not Open");
	}
	m_pComPort.Setup(9600,8,NOPARITY,ONESTOPBIT); 
	m_edtDisplay.EnableWindow(TRUE);  
	m_btnTransmit.EnableWindow(TRUE);
	m_cmbResponses.EnableWindow(TRUE); 
	
}

LRESULT CJoTS_ComSimDlg::OnSerialMsg (WPARAM wParam, LPARAM /*lParam*/)
{
	CSerial::EEvent eEvent = CSerial::EEvent(LOWORD(wParam));
	CSerial::EError eError = CSerial::EError(HIWORD(wParam));

	if (eError)
		DisplayEvent(_T("An internal error occurred."));

	if (eEvent & CSerial::EEventBreak)
		DisplayEvent(_T("Break detected on input."));

	if (eEvent & CSerial::EEventError)
		DisplayEvent(_T("A line-status error occurred."));
	
	if (eEvent & CSerial::EEventRcvEv)
		DisplayEvent(_T("Event character has been received."));

	if (eEvent & CSerial::EEventRing)
		DisplayEvent(_T("Ring detected"));
	
	if (eEvent & CSerial::EEventSend)
		DisplayEvent(_T("All data is send"));
	
//	if (eEvent & CSerial::EEventCTS)
//		DisplayEventSetting(_T("CTS signal change"), _T("CTS"), m_serial.GetCTS());
//	
//	if (eEvent & CSerial::EEventDSR)
//		DisplayEventSetting(_T("DSR signal change"), _T("DSR"), m_serial.GetDSR());
//	
//	if (eEvent & CSerial::EEventRLSD)
//		DisplayEventSetting(_T("RLSD signal change"), _T("RLSD"), m_serial.GetRLSD());
	
	if (eEvent & CSerial::EEventRecv)
	{
		// Create a clean buffer
		DWORD dwRead;
		char szData[5000];
		const int nBuflen = sizeof(szData)-1;

		// Obtain the data from the serial port
		do
		{
			m_pComPort.Read(szData,nBuflen,&dwRead);
			szData[dwRead] = '\0';

			// Scan the string for unwanted characters
			for (DWORD dwChar=0; dwChar<dwRead; dwChar++)
			{
				if (!isprint(szData[dwChar]) && !isspace(szData[dwChar]))
				{
					szData[dwChar] = '.';
				}
			}

#ifdef _UNICODE
			// Convert the ANSI data to Unicode
			LPTSTR lpszData = LPTSTR(_alloca((dwRead+1)*sizeof(TCHAR)));
			if (!::MultiByteToWideChar(CP_ACP, 0, szData, -1, lpszData, dwRead+1))
				return 0;

			// Display the fetched string
			DisplayData(lpszData);
#else
			// Display the fetched string
			DisplayData(szData);
#endif
		} while (dwRead == nBuflen);
	}

	return 0;
}

void CJoTS_ComSimDlg::DisplayEvent (LPCTSTR lpszMsg)
{
	// Display the text
	TCHAR tszMsg[5000];
	wsprintf(tszMsg,_T("[%s]"), lpszMsg);
	m_edtDisplay.SetSel(-1,-1);
	m_edtDisplay.ReplaceSel(tszMsg);
}

void CJoTS_ComSimDlg::DisplayEventSetting (LPCTSTR lpszMsg, LPCTSTR lpszSetting, bool fOn)
{
	TCHAR tszMsg[5000];
	wsprintf(tszMsg,_T("%s (%s=%s)"), lpszMsg, lpszSetting, (fOn?_T("on"):_T("off")));
	DisplayEvent(tszMsg);
}

void CJoTS_ComSimDlg::DisplayData (LPCTSTR pszData)
{
CString csBuffer,
		csPrev;
	SetForegroundWindow();
	// Format the selection as default text
//	TCHAR tszMsg[5000];
//	wsprintf(tszMsg,_T("[%s]"), pszData);
	m_edtDisplay.SetSel(-1,-1);

	m_edtDisplay.GetWindowText(csBuffer); 
	
	csBuffer += pszData;
	csBuffer.Replace("XZ","XZ\n");
	

	m_edtDisplay.SetWindowText(csBuffer); ;
}

void CJoTS_ComSimDlg::OnBtnTxResp() 
{
char Output[50];
	memset(Output,'\0',sizeof(Output));

	UpdateData(TRUE);
	if(!m_csResponseMsg.IsEmpty())  
	{
		strcpy(Output,m_csResponseMsg);
		m_pComPort.Write(Output,0,0,INFINITE);

	}
	
}
