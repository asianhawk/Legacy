// JoTS_ComSimDlg.h : header file
//

#if !defined(AFX_JOTS_COMSIMDLG_H__7F103F14_6BC9_4F92_BE7B_2DCA644EC5CB__INCLUDED_)
#define AFX_JOTS_COMSIMDLG_H__7F103F14_6BC9_4F92_BE7B_2DCA644EC5CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJoTS_ComSimDlgAutoProxy;
#include "CommClasses/SerialMFC.h"

/////////////////////////////////////////////////////////////////////////////
// CJoTS_ComSimDlg dialog

class CJoTS_ComSimDlg : public CDialog
{
	DECLARE_DYNAMIC(CJoTS_ComSimDlg);
	friend class CJoTS_ComSimDlgAutoProxy;

// Construction
public:
	CJoTS_ComSimDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CJoTS_ComSimDlg();

// Dialog Data
	//{{AFX_DATA(CJoTS_ComSimDlg)
	enum { IDD = IDD_JOTS_COMSIM_DIALOG };
	CComboBox	m_cmbResponses;
	CButton	m_btnTransmit;
	CEdit	m_edtDisplay;
	CString	m_csResponseMsg;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJoTS_ComSimDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CJoTS_ComSimDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CJoTS_ComSimDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnBtnOpenComPort();
	afx_msg void OnBtnTxResp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnSerialMsg (WPARAM wParam, LPARAM lParam);
public:
	CSerialMFC  m_pComPort;
	void DisplayEvent (LPCTSTR lpszMsg);
	void DisplayEventSetting (LPCTSTR lpszMsg, LPCTSTR lpszSetting, bool fOn);
	void DisplayData (LPCTSTR pszData);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JOTS_COMSIMDLG_H__7F103F14_6BC9_4F92_BE7B_2DCA644EC5CB__INCLUDED_)
