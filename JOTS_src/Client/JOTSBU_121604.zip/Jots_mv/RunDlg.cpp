// RunDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "RunDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CHKUSERRESPONSEINTERVAL	3000
#define TIMERID_1	100

/////////////////////////////////////////////////////////////////////////////
// CRunDlg dialog


CRunDlg::CRunDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRunDlg::IDD, pParent)
{
	EnableAutomation();
	m_csStatus= _T("");
	m_blnJobHold = FALSE;
	m_blnExit = FALSE;

}


void CRunDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CRunDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRunDlg)
	DDX_Control(pDX, ID_BTN_EXIT, m_btnExit);
	DDX_Control(pDX, IDC_LBL_LABEL_COUNT, m_lblCount);
	DDX_Control(pDX, ID_BTN_HOLD, m_btnHold);
	DDX_Text(pDX, IDC_LBL_STATUS_MSG, m_csStatus);
	DDX_Text(pDX, IDC_TXB_LABEL_COUNT, m_csLabelCount);
	DDX_Text(pDX, IDC_TXB_CURRENT_INDEX, m_csCurrentIndex);
	DDX_Text(pDX, IDC_TXB_CURRENT_BARCODE_VALUE, m_csBarCodeValue);
	DDX_Text(pDX, IDC_TXB_STEP_SIZE, m_csStepSize);
	DDX_Text(pDX, IDC_TXB_SCANNED_BARCODE_VALUE, m_csScannedBarcode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRunDlg, CDialog)
	//{{AFX_MSG_MAP(CRunDlg)
	ON_BN_CLICKED(ID_BTN_HOLD, OnBtnHold)
	ON_WM_TIMER()
	ON_BN_CLICKED(ID_BTN_EXIT, OnBtnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CRunDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CRunDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IRunDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {7AF56342-89E1-420D-A167-490D442981C5}
static const IID IID_IRunDlg =
{ 0x7af56342, 0x89e1, 0x420d, { 0xa1, 0x67, 0x49, 0xd, 0x44, 0x29, 0x81, 0xc5 } };

BEGIN_INTERFACE_MAP(CRunDlg, CDialog)
	INTERFACE_PART(CRunDlg, IID_IRunDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRunDlg message handlers

void CRunDlg::SetStatus(CString csStatus)
{
	m_csStatus = csStatus;
}

CString CRunDlg::GetStatus()
{
	return m_csStatus;
}

void CRunDlg::UpdateDisplay()
{
	UpdateData(FALSE);
	UpdateWindow();
	YieldToWindows();
	 
	
}

void CRunDlg::OnBtnHold() 
{
CString csCaption;
	
	UpdateData(TRUE);
	m_btnHold.GetWindowText(csCaption);
	if (csCaption.Find("Hold")!=-1)
	{
		KillTimer(TIMERID_1);
		m_blnJobHold = TRUE;
		m_btnHold.SetWindowText("Run");
	}
	else
	{
		SetTimer(TIMERID_1,CHKUSERRESPONSEINTERVAL,NULL);
		m_blnJobHold = FALSE;	
		m_btnHold.SetWindowText("Hold");
		
	}
	
}

BOOL CRunDlg::GetHoldStatus()
{
	return m_blnJobHold;

}

void CRunDlg::Init()
{
	SetTimer(TIMERID_1,CHKUSERRESPONSEINTERVAL,NULL);
}

void CRunDlg::OnTimer(UINT nIDEvent) 
{
	UpdateData(TRUE);
	if (nIDEvent==TIMERID_1)
	{
		KillTimer(TIMERID_1);
		YieldToWindows();
		SetTimer(TIMERID_1,CHKUSERRESPONSEINTERVAL,NULL);

	}
	
	CDialog::OnTimer(nIDEvent);

	if (m_blnExit)
	{
		KillTimer(TIMERID_1);
		CDialog::OnOK();
	}
}

void CRunDlg::YieldToWindows ( void )
{


	// Process existing messages in the application's message queue.
	// When the queue is empty, do clean up and return.
	
	MSG msg;

	while ( ::PeekMessage(&msg,NULL,0,0,PM_NOREMOVE) )
	{
		
		if (!AfxGetThread()->PumpMessage())
			return;
	}

}

void CRunDlg::OnBtnExit() 
{
	m_blnExit=TRUE;
	
}
BOOL CRunDlg::ExitRun()
{
	return m_blnExit;


}

BOOL CRunDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitControls();
	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRunDlg::InitControls()
{
short	shBtnColor = 30;	
	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format label controls
	GetDlgItem(IDC_LBL_STATUS)->SetFont(&font);
	GetDlgItem(IDC_LBL_STATUS_MSG)->SetFont(&font);
	
//	GetDlgItem(ID_BTN_HOLD)->SetFont(&font);
//	GetDlgItem(ID_BTN_EXIT)->SetFont(&font);

	GetDlgItem(IDC_LBL_LABEL_COUNT)->SetFont(&font);
	GetDlgItem(IDC_TXB_LABEL_COUNT)->SetFont(&font);	

	GetDlgItem(IDC_LBL_CURRENT_PRODUCT_INDEX)->SetFont(&font);
	GetDlgItem(IDC_TXB_CURRENT_INDEX)->SetFont(&font);	


	GetDlgItem(IDC_LBL_CURRENT_BARCODE_VALUE)->SetFont(&font);
	GetDlgItem(IDC_TXB_CURRENT_BARCODE_VALUE)->SetFont(&font);	

	GetDlgItem(IDC_LBL_STEP_SIZE)->SetFont(&font);
	GetDlgItem(IDC_TXB_STEP_SIZE)->SetFont(&font);	

	GetDlgItem(IDC_LBL_SCANNED_BARCODE_VALUE)->SetFont(&font);
	GetDlgItem(IDC_TXB_SCANNED_BARCODE_VALUE)->SetFont(&font);	


	m_btnHold.SetFont(&font);
	m_btnHold.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnHold.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnHold.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));


	m_btnExit.SetFont(&font);
	m_btnExit.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnExit.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnExit.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnExit.SetIcon(IDI_EXIT, (int)BTNST_AUTO_GRAY);
	m_btnExit.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btnExit.SetAlign(CButtonST::ST_ALIGN_HORIZ);





}
