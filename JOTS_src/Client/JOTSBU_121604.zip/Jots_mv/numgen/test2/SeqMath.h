//  SeqMath.h - header file for math functions for CString objects
// $History: SeqMath.h $
//
//*****************  Version 2  *****************
//User: Neil.vaneps  Date: 10/11/01   Time: 11:36a
//Updated in $/C++ Code/Label System/Numgen
//Exported functions in SeqAdd.cpp and SeqMath.cpp to help eliminate
//duplicity.
//
//*****************  Version 1  *****************
//User: Neil.vaneps  Date: 10/04/01   Time: 6:34p
//Created in $/C++ Code/Label System/Numgen
//

#define AFX_MFC_EXT_TYPE __declspec( dllimport )
// Trim off any leading or trailing blanks from a CString object
void AFX_MFC_EXT_TYPE Trim(CString & s);

// Convert a character array to a CString object
void AFX_MFC_EXT_TYPE CnvrtStr(char str[], int len, CString & s);

// Add two CString objects
CString AFX_MFC_EXT_TYPE AddCStrs(CString & Num1,CString & Num2);

// Add two CString Float objects
CString AFX_MFC_EXT_TYPE AddCStrsFL(CString & Num1, CString & Num2);

// Subtract two CString objects.  N1 and N2 are
// positive and N1 is greater than N2
CString AFX_MFC_EXT_TYPE SubCStrs(CString & N1, CString & N2);

// Subtract two CString Float objects.  N1 and N2 are
// positive floats.
CString AFX_MFC_EXT_TYPE SubCStrsFL(CString & N1, CString & N2);

// Multiply two CString objects
CString AFX_MFC_EXT_TYPE MultCStrs(CString & Num1, CString & Num2);

// Multiply two CString Float objects
CString AFX_MFC_EXT_TYPE MultCStrsFL(CString & Num1, CString & Num2);

// Divide two CString objects
// INPUT:    Dividend and Divisor
// OUTPUT:	 Quotient and Remainder
//           0 is returned if Dividend and Divisor are equal
//           1 is returned if Dividend > Divisor
//           2 is returned if Dividend < Divisor
int AFX_MFC_EXT_TYPE DivCStrs(CString & Dividend, CString & Divisor, CString & Quotient, CString & Remainder);

// Divide two CString Float objects
// INPUT:   Dividend and Divisor
// OUTPUT:  Quotient as a Float CString
CString AFX_MFC_EXT_TYPE DivCStrsFL(CString & Dividend, CString & Divisor);


// Compare two CString base 10 objects and return:
//    0 if equal
//    1 if Num1 > Num2
//    2 if Num2 > Num1
int AFX_MFC_EXT_TYPE Compare(CString & Num1, CString & Num2);

// Compare two CString Float base 10 objects and return:
//    0 if equal
//    1 if Num1 > Num2
//    2 if Num2 > Num1
int AFX_MFC_EXT_TYPE CompareFL(CString & Num1, CString & Num2);

