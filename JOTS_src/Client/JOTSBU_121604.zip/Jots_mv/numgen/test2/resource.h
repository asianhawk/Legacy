//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test2.rc
//
#define ID_BTN_GSNUM                    3
#define ID_BTN_BATCH                    4
#define ID_BTN_SEQUTIL                  5
#define IDD_TEST2_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_TXB_STRAT_NUM               1000
#define IDC_TXB_GEN_NUM                 1001
#define IDC_TXB_QTY                     1002
#define IDC_LBL_STATUS                  1003
#define IDC_LBL_STATUS_MESSAGE          1004
#define IDC_TXB_FWIDTH                  1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
