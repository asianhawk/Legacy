// JoTS.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "JoTS.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "JoTSDoc.h"
//#include "JoTSView.h"
#include <initguid.h>
#include "JoTS_i.c"
#include "JobView.h"
#include "JobWizard.h"

#include "PrinterDiagnosticDlg.h"
#include "SingleInstance/SingleInstance.h"
#include "UpdateM3Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJoTSApp

BEGIN_MESSAGE_MAP(CJoTSApp, CWinApp)
	//{{AFX_MSG_MAP(CJoTSApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_SETUP_SECURITY_USER, OnSetupSecurityUser)
	ON_COMMAND(ID_SETUP_SYSTEMCONFIGURATION, OnSetupSystemconfiguration)
	ON_COMMAND(ID_SETUP_CUSTOM_BASENUMBER, OnSetupCustomBasenumber)
	ON_COMMAND(ID_SETUP_TEMPLATES_EDITOR, OnSetupTemplatesEditor)
	ON_COMMAND(ID_SETUP_PRINTER_VIEW, OnSetupPrinterView)
	ON_COMMAND(ID_SETUP_MORPHOR_UPDATEAIK, OnUpdateAIK)

	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJoTSApp construction

CJoTSApp::CJoTSApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CJoTSApp object


//CComObjectGlobal<CJoTSApp> theApp;

/////////////////////////////////////////////////////////////////////////////
// CJoTSApp initialization

BOOL CJoTSApp::InitInstance()
{

//	if (!AfxOleInit())
//	{
//		AfxMessageBox("OLE Init Failed");
//		return FALSE;
//	}
//	COleTemplateServer::RegisterAll();
CString csInstanceName;
char	strComputerName[100];
unsigned long    lngSize=100;
	GetComputerName(strComputerName,&lngSize);
	csInstanceName.Format("JoTS_APPLICATION_%s",strComputerName); 
	
	if (IsInstancePresent(csInstanceName,SI_SYSTEM_UNIQUE))
	{
		AfxMessageBox("Application Already Running. Check Task Manager");
		return FALSE;
	}
	else
	{
		CFileFind ff;
		if (ff.FindFile("c:\\JoTS.dat")!=0)
		{

			DeleteFile("c:\\JoTS.dat");

		}

	}

	if (!IsSystemIntegrityOK()) return FALSE;

	if (false == _Module.m_bATLInited)
		return FALSE;

	_Module.UpdateRegistryFromResource(IDR_JOTS, TRUE);
	_Module.RegisterServer(TRUE);


	
	
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Computype"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

		
	CAnotherMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CAnotherMultiDocTemplate(
		IDR_MAINMENU,
		RUNTIME_CLASS(CJoTSDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CJobView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;


	// This code replaces the MFC created menus with 
	// the Ownerdrawn versions 
	pDocTemplate->m_hMenuShared=pMainFrame->NewMenu();
	pMainFrame->m_hMenuDefault=pMainFrame->NewDefaultMenu();

	// This simulates a window being opened if you don't have
	// a default window displayed at startup
	pMainFrame->OnUpdateFrameMenu(pMainFrame->m_hMenuDefault);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		return TRUE;
	}



	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(SW_MAXIMIZE /* m_nCmdShow */);
	pMainFrame->UpdateWindow();

	return TRUE;
}

BOOL CJoTSApp::IsSystemIntegrityOK()
{
	// System Integrity Checks

	CUtilities *pUtil = new CUtilities();
	if (!pUtil->IsConfigFileValid("c:\\JOTS\\Config\\JoTSConfig.xml"))
	{
		pUtil->ErrorMessage("JOTS Configuration File Not Found");
		delete pUtil;
		return FALSE;

	}

	if (!pUtil->IsXMLFile_FormatOK ("c:\\JOTS\\Config\\JoTSConfig.xml"))
	{
		delete pUtil;
		return FALSE;

	}

	if (!pUtil->IsValidTemplateLocation())
	{
		delete pUtil;
		return FALSE;
	}

	if (!pUtil->IsValidJobsLocation())
	{
		delete pUtil;
		return FALSE;
	}

	
	delete pUtil;


	// End System Integrity Checks
	
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CJoTSApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CJoTSApp message handlers


	
CJoTSModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_Application, CJoTSApp)
OBJECT_ENTRY(CLSID_JobRecord, CJoTSDoc)
//OBJECT_ENTRY(CLSID_View, CJoTSView)
OBJECT_ENTRY(CLSID_Main, CJobView)
END_OBJECT_MAP()



CJoTSModule::CJoTSModule()
{
	m_bATLInited = TRUE;

	HRESULT hRes = CoInitialize(NULL);
	if (FAILED(hRes))
		exit(1);

	_Module.Init(ObjectMap, GetModuleHandle(NULL));
	_Module.dwThreadID = GetCurrentThreadId();

	LPTSTR lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
	TCHAR szTokens[] = _T("-/");

	BOOL bRun = TRUE;
	LPCTSTR lpszToken = _Module.FindOneOf(lpCmdLine, szTokens);
	while (lpszToken != NULL)
	{
		if (lstrcmpi(lpszToken, _T("UnregServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_JOTS, FALSE);
			_Module.UnregisterServer(TRUE); //TRUE means typelib is unreg'd
			bRun = FALSE;
			break;
		}
		if (lstrcmpi(lpszToken, _T("RegServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_JOTS, TRUE);
			_Module.RegisterServer(TRUE);
			bRun = FALSE;
			break;
		}
		lpszToken = _Module.FindOneOf(lpszToken, szTokens);
	}

	if (!bRun)
	{
		_Module.Term();
		CoUninitialize();
		exit(0);
	}

	hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE);
	if (FAILED(hRes))
	{
		CoUninitialize();
		exit(1);
	}	
}

CJoTSModule::~CJoTSModule()
{
	if (m_bATLInited)
	{

		_Module.RevokeClassObjects();
		_Module.Term();
		CoUninitialize();
	}
}



LONG CJoTSModule::Unlock()
{
	AfxOleUnlockApp();
	return 0;
}

LONG CJoTSModule::Lock()
{
	AfxOleLockApp();
	return 1;
}
LPCTSTR CJoTSModule::FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
	while (*p1 != NULL)
	{
		LPCTSTR p = p2;
		while (*p != NULL)
		{
			if (*p1 == *p)
				return CharNext(p1);
			p = CharNext(p);
		}
		p1++;
	}
	return NULL;
}




STDMETHODIMP CJoTSApp::get_ActiveDocument(IJobRecord **pVal)
{
	METHOD_PROLOGUE_ATL

	CMDIChildWnd* pChild = ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive();
	if (!pChild) 
		return E_FAIL;
	
	ASSERT_KINDOF(CMDIChildWnd, pChild);
CComObject<CJoTSDoc>* pDoc = dynamic_cast<CComObject<CJoTSDoc>*>(pChild->GetActiveDocument());
	return pDoc->QueryInterface(IID_IJobRecord, reinterpret_cast<void**>(pVal));
}

STDMETHODIMP CJoTSApp::get_Visible(BOOL *pVal)
{
	METHOD_PROLOGUE_ATL

	CWnd* pMainWnd = AfxGetMainWnd();
	ASSERT(pMainWnd);
	*pVal = pMainWnd->IsWindowVisible();

	return S_OK;
}

STDMETHODIMP CJoTSApp::put_Visible(BOOL newVal)
{
	METHOD_PROLOGUE_ATL

	CWnd* pMainWnd = AfxGetMainWnd();
	ASSERT(pMainWnd);
	if (newVal)
		pMainWnd->ShowWindow(SW_SHOW);
	else
		pMainWnd->ShowWindow(SW_HIDE);
	pMainWnd->UpdateWindow();


	return S_OK;
}


void CJoTSApp::OnFileNew() 
{
	// Dynamically create a new CFuchiaDocument.
	// The document will continue to create itself
	// in the constructor.
//	IMPLEMENT_CREATE_DOCUMENT;

//	CJobWizard objWizard;
//
//	objWizard.CreateNewJob(); 
}

void CJoTSApp::OnFileOpen() 
{
CString csJobFileName;
CUtilities *pUtil;

	// prompt the user (with all document templates)

CString csJobsDirectory;

   pUtil = new CUtilities();
   if (!pUtil->GetJobsDirectory(&csJobsDirectory))
   {
		delete pUtil;
		return;
   }

   CFileDialog fileDlg(TRUE, NULL, NULL, 
	                   OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY, 
					   "Job Files (*.xml)|*.xml||");


   fileDlg.m_ofn.lpstrTitle = "Select Job File";
   fileDlg.m_ofn.lpstrInitialDir=csJobsDirectory;

	// Call DoModal
	if ( fileDlg.DoModal() == IDOK)
	{
		csJobFileName = fileDlg.GetPathName(); // This is your selected file name with path
		if (csJobFileName.IsEmpty())
		{
			AfxMessageBox("No File Name Selected");

		}
	}

	if (!csJobFileName.IsEmpty())
		OpenDocumentFile(csJobFileName);
	delete pUtil;
}


CDocument* CJoTSApp::OpenDocumentFile(LPCTSTR lpszFileName) 
{
	// Dynamically create a new CDocument.
	// The document will continue to create itself
	// in the constructor.
	IMPLEMENT_CREATE_DOCUMENT;

	// Open an existing document
    CWaitCursor wait;
    if ( !pDoc->OpenJobFile( lpszFileName ) )
    {
        // Unable to open the document.
        TRACE( "Unable to open the document \
				in %s at %d.\n", THIS_FILE, __LINE__ );
        // We must delete the document instance.
		pDoc->Release();
        return NULL;
    }
    // Set the document file path and name.
    pDoc->SetPathName(lpszFileName);
	pDoc->GetProcessInfo();
	return pDoc;
}

int CJoTSApp::ExitInstance() 
{

	return CWinApp::ExitInstance();
}

STDMETHODIMP CJoTSApp::Terminate()
{
CFileFind ff;
	METHOD_PROLOGUE_ATL

	if (ff.FindFile("c:\\JoTS.dat")!=0)
	{
		DeleteFile("c:\\JoTS.dat");

	}

   ExitInstance();
   AfxPostQuitMessage(0);
  
   
   return S_OK;
}



STDMETHODIMP CJoTSApp::get_Services(IMain* *pVal)
{
	METHOD_PROLOGUE_ATL

	CMDIChildWnd* pChild = ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive();
	if (!pChild) 
		return E_FAIL;
	
	ASSERT_KINDOF(CMDIChildWnd, pChild);
	CComObject<CJobView>* pView = dynamic_cast<CComObject<CJobView>*>(pChild->GetActiveView());
	return pView->QueryInterface(IID_IMain, reinterpret_cast<void**>(pVal));
}

void CJoTSApp::WinHelp( DWORD dwData, UINT nCmd )
{
DWORD i;

DWORD numHelpIDs = (sizeof(aMenuHelpIDs)/sizeof(DWORD))/2 - 1;

	switch (nCmd)
	{
		case HELP_CONTEXT:
		
		 // If it is a help context command, search for the
		 // control ID in the array.
		 for (i= 0; i < numHelpIDs*2; i+=2)
		 {
		   if (aMenuHelpIDs[i] == LOWORD (dwData) )
		   {
			 i++;  // pass the help context id to HTMLHelp
			 HtmlHelp(m_pMainWnd->m_hWnd,"JoTSHelp.chm",
				HH_HELP_CONTEXT,aMenuHelpIDs[i]);
			 return;
		   }
		 }

		 // If the control ID cannot be found,
		 // display the default topic.
		 if (i == numHelpIDs*2)
		 HtmlHelp(m_pMainWnd->m_hWnd,"JoTSHelp.chm",HH_DISPLAY_TOPIC,0);
		 break;
		default:
		 HtmlHelp(m_pMainWnd->m_hWnd,"JoTSHelp.chm",HH_DISPLAY_TOPIC,0);

	}

}

void CJoTSApp::OnHelp() 
{

 HtmlHelp(m_pMainWnd->m_hWnd,"JoTSHelp.chm",HH_DISPLAY_TOPIC,0);
	
}

void CJoTSApp::OnSetupSecurityUser() 
{
	CUserAccountDlg *pDlg = new CUserAccountDlg();

	pDlg->DoModal();
	delete pDlg;
	
}

void CJoTSApp::OnSetupSystemconfiguration() 
{
	CConfigDlg *pDlg = new 	CConfigDlg();

	pDlg->DoModal(); 
	delete pDlg;

}

void CJoTSApp::OnSetupCustomBasenumber() 
{
CBaseSchemaDlg *pDlg = new CBaseSchemaDlg();

	pDlg = new CBaseSchemaDlg();
	
	pDlg->DoModal();
	
	delete pDlg;
	
}

void CJoTSApp::OnSetupTemplatesEditor() 
{
	CTemplateEditorDlg *pDlg = new CTemplateEditorDlg();

	pDlg->DoModal();
	delete pDlg;
	
}

void CJoTSApp::OnSetupPrinterView() 
{
CPrinterDiagnosticDlg *pDlg = new CPrinterDiagnosticDlg();

	pDlg->DoModal();
	

	delete pDlg;
	
	
}

void CJoTSApp::OnUpdateAIK()
{
CUpdateM3Dlg *pDlg = new CUpdateM3Dlg();

	pDlg->DoModal(); 

}
