// AnotherMultiDocTemplate.cpp: implementation of the CAnotherMultiDocTemplate class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AnotherMultiDocTemplate.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNAMIC(CAnotherMultiDocTemplate, CMultiDocTemplate)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// Constructor.  Those information are directly passed to the
// base class that will manage the document creation.
CAnotherMultiDocTemplate::CAnotherMultiDocTemplate(	
		UINT nIDResource,
		CRuntimeClass* pDocClass,
		CRuntimeClass* pFrameClass,
		CRuntimeClass* pViewClass)
	  : CMultiDocTemplate( nIDResource, pDocClass, pFrameClass, pViewClass)
{
}

/////////////////////////////////////////////////////////////////////////////
// CMultiDocTemplate commands

CDocument*
CAnotherMultiDocTemplate::CreateNewDocument()
{
	// default implementation constructs one from CRuntimeClass
	if (m_pDocClass == NULL)
	{
		TRACE0("Error: you must override CDocTemplate::CreateNewDocument.\n");
		ASSERT(FALSE);
		return NULL;
	}
//	BdL Begin; Document has already been created!
//--CDocument*-pD-=-(CDocument*)m_pDocClass->CreateObject();--------
//  BdL End
	if (m_pDocument == NULL)
	{
		TRACE1("Warning: Dynamic create of document type %hs failed.\n",
			m_pDocClass->m_lpszClassName);
		return NULL;
	}
	ASSERT_KINDOF(CDocument, m_pDocument);
	AddDocument(m_pDocument);
	return m_pDocument;
}
