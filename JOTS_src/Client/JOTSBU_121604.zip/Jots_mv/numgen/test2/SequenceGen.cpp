
#include "stdafx.h"
#include "SequenceGen.h"





CSequenceGen::CSequenceGen()
{

	m_lng_tx = 1;
	memset(m_cs_tx_id,'\0',sizeof(m_cs_tx_id));
	memset(m_cs_begin_samp,'\0',sizeof(m_cs_begin_samp));
	memset(m_cs_end_samp,'\0',sizeof(m_cs_end_samp));
	memset(m_cs_error,'\0',sizeof(m_cs_error));
	memset(m_cs_quantity,'\0',sizeof(m_cs_quantity));
	memset(m_cs_start10,'\0',sizeof(m_cs_start10));
	memset(m_cs_end10,'\0',sizeof(m_cs_end10));
	memset(m_cs_omit,'\0',sizeof(m_cs_omit));
	memset(m_cs_btypefile,'\0',sizeof(m_cs_btypefile));


	m_csBaseTypePath = "c:\\JoTS\\Config\\basetype.txt";

	m_lng_type = atol((const char *)"0");
	m_lng_msglen=-1;
}

CSequenceGen::CSequenceGen(CString csBaseTypePath)
{

	m_lng_tx = 1;
	memset(m_cs_tx_id,'\0',sizeof(m_cs_tx_id));
	memset(m_cs_begin_samp,'\0',sizeof(m_cs_begin_samp));
	memset(m_cs_end_samp,'\0',sizeof(m_cs_end_samp));
	memset(m_cs_error,'\0',sizeof(m_cs_error));
	memset(m_cs_quantity,'\0',sizeof(m_cs_quantity));
	memset(m_cs_start10,'\0',sizeof(m_cs_start10));
	memset(m_cs_end10,'\0',sizeof(m_cs_end10));
	memset(m_cs_omit,'\0',sizeof(m_cs_omit));
	memset(m_cs_btypefile,'\0',sizeof(m_cs_btypefile));
	
	if (!csBaseTypePath.IsEmpty()) 
		strcpy(m_cs_btypefile,csBaseTypePath);

	m_lng_type = atol((const char *)"0");
	m_lng_msglen=-1;


}

void CSequenceGen::InitSeqGenerator(CString csTable, long lngFieldWidth)
{

	if (csTable.IsEmpty()) 
	{
		AfxMessageBox("Base Type Not Defined");
		return;
	}
		
	if (lngFieldWidth<=0)
	{
		AfxMessageBox("Field Width Must Be Greate Than Zero");
		return;

	}

	SetFieldWidth(lngFieldWidth);
	
	strcpy(m_cs_table,csTable);
	m_lng_base = csTable.GetLength();


}

void CSequenceGen::InitSeqGenerator(CString csTable, CString csFieldWidth)
{

	if (csTable.IsEmpty()) 
	{
		AfxMessageBox("Base Type Not Defined");
		return;
	}
		
	if (csFieldWidth.IsEmpty())
	{
		AfxMessageBox("Field Width Not Defined");
		return;

	}

	SetFieldWidth(csFieldWidth);
	
	strcpy(m_cs_table,csTable);
	m_lng_base = csTable.GetLength();


}




CString CSequenceGen::GetNextSerialNumber(CString csCurrentValue)
{

	m_lng_tx = 1;
	strcpy(m_cs_tx_id,"\0");
	strcpy(m_cs_begin_samp,"\0");
	strcpy(m_cs_end_samp,  "\0");
	strcpy(m_cs_error,"\0");
	strcpy(m_cs_start,"\0");

	strcpy(m_cs_quantity,"\0");//m_csQty);
	strcpy(m_cs_start10,"\0");
	strcpy(m_cs_end10,"\0");
	strcpy(m_cs_omit,"\0");

//	strcpy(m_cs_end,csCurrentValue);
	
	strcpy(m_cs_end,"\0");
	strcpy(m_cs_start,csCurrentValue);
	if (m_lng_type!=1)
	{
		CString csTest=GetBasePath();
		int nLength= csTest.GetLength(); 
		
		if (csTest.IsEmpty())
		{
			m_lng_process_status=0;
			return "Base Path Not Defined";
		}
	}
	
	Sequence_Generator	(	m_lng_tx,
								m_cs_tx_id,
								&m_lng_tx_status,
								&m_lng_process_status,
								m_lng_base,
								m_lng_type,
								m_cs_table,
								m_cs_begin_samp,
								m_cs_end_samp,
								m_cs_start,
								m_cs_end,
								m_cs_quantity,
								m_cs_start10,
								m_cs_end10,
								m_cs_omit,
								m_lng_msglen,
								m_cs_error,
								GetBasePath());



	return m_cs_end;
}


BOOL CSequenceGen::GetNextSerialNumber(CString csCurrentValue, CString *csNextValue)
{
int nLength;
	m_lng_tx = 1;
	strcpy(m_cs_tx_id,"\0");
	strcpy(m_cs_begin_samp,"\0");
	strcpy(m_cs_end_samp,  "\0");
	strcpy(m_cs_error,"\0");
	strcpy(m_cs_start,"\0");

	strcpy(m_cs_quantity,"2");//m_csQty);
	strcpy(m_cs_start10,"\0");
	strcpy(m_cs_end10,"\0");
	strcpy(m_cs_omit,"\0");

//	strcpy(m_cs_end,csCurrentValue);
	
	strcpy(m_cs_start,"\0");
//	strcpy(m_cs_start,csCurrentValue);
	strcpy(m_cs_end,csCurrentValue);

	if (m_lng_type!=1)
	{
		CString csTest=GetBasePath();
		nLength= csTest.GetLength(); 
		
		if (csTest.IsEmpty())
		{
			m_lng_process_status=0;
			return FALSE;
		}
	}
		



		
		Sequence_Generator	(	m_lng_tx,
								m_cs_tx_id,
								&m_lng_tx_status,
								&m_lng_process_status,
								m_lng_base,
								m_lng_type,
								m_cs_table,
								m_cs_begin_samp,
								m_cs_end_samp,
								m_cs_start,
								m_cs_end,
								m_cs_quantity,
								m_cs_start10,
								m_cs_end10,
								m_cs_omit,
								m_lng_msglen,
								m_cs_error,
								GetBasePath());


	if (GetStatusMessage().Find("Successful")!=-1)
	{
		if (m_cs_quantity[0]=='\0')
			*csNextValue=m_cs_end;
		else
			*csNextValue=m_cs_start;
		return TRUE;
	}
	else
		if (m_lng_process_status==9)
		{
			int nStep=atoi(m_cs_quantity);
			CString csBuffer;
			for (int nCount=0;nCount<m_lng_msglen;nCount++)
			{
				if (nStep==2)
				{
					csBuffer+=m_cs_table[m_lng_base-1];

				}
				else
					csBuffer+=m_cs_table[0];

			}
			*csNextValue=csBuffer;
			return TRUE;
	
		}
	return FALSE;
}

CString CSequenceGen::GetStatusMessage()
{
CString csStatusMessage;
	switch (m_lng_process_status)
	{
		case 0:
			csStatusMessage = "General Error";
			break;
		case 1:
			csStatusMessage = "Successful";
			break;
		case 6:
			csStatusMessage = "Invalid Base Or Numbering Type";
			break;
		case 7:
			csStatusMessage = "Invalid Message Length";
			break;
		case 8:
			csStatusMessage = "Invalid Character Or Message";
			break;
		case 9:
			csStatusMessage = "Value Of End Number Greater Than Max Value";
			break;
		case 12:
			csStatusMessage = "End Number Is Smaller That Start Number";
			break;
		case 14:
			csStatusMessage = "Invalid Characters In Quantity";
			break;
		case 17:
			csStatusMessage = "Message Length Was Not Entered";
			break;
		default:
			csStatusMessage = "Unknown Error";
			break;

	}

	return csStatusMessage;

}

BOOL CSequenceGen::IsError()
{
	if (m_lng_process_status==1)
		return FALSE;

	return TRUE;


}

void CSequenceGen::SetBasePath(CString csBasePath)
{
	strcpy(m_cs_btypefile,csBasePath);

}
char *CSequenceGen::GetBasePath()
{

	return m_cs_btypefile;
}

void CSequenceGen::PadString(CString *csValue, int nWidth)
{
CString csBuffer;
CString csFormat;
	
	csFormat.Format("%d",nWidth); 
	csFormat= CString("%0") + csFormat +"s";
	csBuffer.Format(csFormat,*csValue);
	
	*csValue = csBuffer;

}

long CSequenceGen::GetFieldWidth()
{

	return m_lng_msglen;
}

void CSequenceGen::SetFieldWidth(CString csFieldWidth)
{

	m_lng_msglen = atol(csFieldWidth);
}
void CSequenceGen::SetFieldWidth(long lngFieldWidth)
{
	m_lng_msglen = lngFieldWidth;

}