#ifndef __SIMULATOR_H
#define __SIMULATOR_H


extern void OpenLogFile();
extern void CloseLogFile();
extern void LogInfo(CString strBuffer);
#endif