// DataSeriesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "DataSeriesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataSeriesDlg dialog

	// define grid column value
#define	DATASETSERIES		0
#define	STATICINDEX			1
#define	BASENUMBER			2
#define	FIELDWIDTH			3
#define STEPSIZE			4
#define	STARTINGSEQVALUE	5
#define	MAXIMUMSEQVALUE		6
#define	ROLLOVERVALUE		7
#define	CHKDIGITCOL			8
#define	ALLOWDUPLICATES		9
#define COLUMNCOUNT			10

CDataSeriesDlg::CDataSeriesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDataSeriesDlg::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CDataSeriesDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDataSeriesDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CDataSeriesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataSeriesDlg)
	DDX_Control(pDX, IDC_BYN_UPDATE, m_btnUpdate);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataSeriesDlg, CDialog)
	//{{AFX_MSG_MAP(CDataSeriesDlg)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	ON_NOTIFY(NM_RCLICK,IDC_GRID, OnRMClick)
	ON_WM_HELPINFO()
	ON_COMMAND(ID_DATASERIES_COPY, OnDataseriesCopy)
	ON_COMMAND(ID_DATASERIES_DELETE, OnDataseriesDelete)
	ON_BN_CLICKED(IDC_BYN_UPDATE, OnBtnUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CDataSeriesDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CDataSeriesDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IDataSeriesDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {AC9D56D4-A1FA-4345-B537-DACADC9DF365}
static const IID IID_IDataSeriesDlg =
{ 0xac9d56d4, 0xa1fa, 0x4345, { 0xb5, 0x37, 0xda, 0xca, 0xdc, 0x9d, 0xf3, 0x65 } };

BEGIN_INTERFACE_MAP(CDataSeriesDlg, CDialog)
	INTERFACE_PART(CDataSeriesDlg, IID_IDataSeriesDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataSeriesDlg message handlers


void CDataSeriesDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    

	if ((pItem->iRow>=m_Grid.GetFixedRowCount())&&(pItem->iColumn==ALLOWDUPLICATES))
	{
			ProcessScanCheck(pItem->iRow,ALLOWDUPLICATES);

	}


}



void CDataSeriesDlg::OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
 
CRect rect;

	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;


	if (pItem->iRow>m_Grid.GetFixedRowCount()-1)
	{
		m_nCurrentRow=pItem->iRow;//-(m_Grid.GetFixedRowCount()-1);

		m_Grid.GetCellRect(pItem->iRow,pItem->iColumn,&rect );
	
		ClientToScreen(&rect);
      
		CMenu menuTreePopupMaster;
		menuTreePopupMaster.LoadMenu(IDR_POPUP_DATASERIES);

		CMenu* pMenuTreePopup = menuTreePopupMaster.GetSubMenu(0);
		pMenuTreePopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_CENTERALIGN, rect.right   ,rect.bottom , this , NULL);
	}


}



void CDataSeriesDlg::InitGrid() 
{
CStringArray options;
int	nCount;

	m_Grid.SetFixedRowCount(2);
	m_Grid.SetFixedColumnCount(0);
	m_Grid.SetRowCount(MAXDATASERIES+m_Grid.GetFixedRowCount());
	m_Grid.SetColumnCount(10);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	m_Grid.SetFixedColumnSelection(FALSE);
	m_Grid.SetFixedRowSelection(FALSE);
	m_Grid.SetEditable(TRUE);
	m_Grid.SetSingleColSelection(FALSE);


    m_Grid.SetItemText(1,DATASETSERIES,"Name");

    m_Grid.SetItemText(1,STATICINDEX,"Static");
	

    m_Grid.SetItemText(0,BASENUMBER,"Base #");
    m_Grid.SetItemText(1,BASENUMBER,"Schema");
    
    m_Grid.SetItemText(0,FIELDWIDTH,"Field ");
    m_Grid.SetItemText(1,FIELDWIDTH,"Width");
	
    m_Grid.SetItemText(0,STEPSIZE,"Step ");
    m_Grid.SetItemText(1,STEPSIZE,"Size");

	
	m_Grid.SetItemText(0,STARTINGSEQVALUE,"Starting");
    m_Grid.SetItemText(1,STARTINGSEQVALUE,"Index Value");

    m_Grid.SetItemText(0,MAXIMUMSEQVALUE,"Maximum");
    m_Grid.SetItemText(1,MAXIMUMSEQVALUE,"Index Value");
	
    m_Grid.SetItemText(0,ROLLOVERVALUE,"Roll Over");
	m_Grid.SetItemText(1,ROLLOVERVALUE,"Value");

    m_Grid.SetItemText(0,CHKDIGITCOL,"Check Digit");
	m_Grid.SetItemText(1,CHKDIGITCOL,"Type");

    m_Grid.SetItemText(0,ALLOWDUPLICATES,"Allow");
	m_Grid.SetItemText(1,ALLOWDUPLICATES,"Duplicates");


	for (nCount=0;nCount<MAXDATASERIES;nCount++)
	{
		for (int nCol=0;nCol<COLUMNCOUNT;nCol++)
		{
			m_Grid.SetItemFormat(nCount,nCol,DT_CENTER|DT_VCENTER);
		}
		m_Grid.SetRowHeight(nCount,25); 
	}

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);

	GetCheckDigits();
	GetBaseNumberSchemas();
	
	m_Grid.ExpandColumnsToFit(TRUE); 


	
}


BOOL CDataSeriesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitGrid();	
	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format btn control
	
	m_btnUpdate.SetFont(&font);
	m_btnUpdate.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnUpdate.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnUpdate.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnUpdate.SetIcon(IDI_OK);
//	m_btnUpdate.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDataSeriesDlg::UpdateGrid()
{
	GV_ITEM Item;
	Item.mask = GVIF_TEXT;
//	Item.col = SCANCOLUMN;
	Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);
	Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);


CStringArray options;	
CUtilities oUtil;
	
	
	for (int nID=0;nID<MAXDATASERIES;nID++)
	{

		if (!m_pJobInfo->SerialData[nID].Name.IsEmpty())	// No need for a combo if only one data definition
		{
			

			m_Grid.SetItemText(nID+2,DATASETSERIES, _T(m_pJobInfo->SerialData[nID].Name ));
			m_Grid.SetItemText(nID+2,STATICINDEX, _T(m_pJobInfo->SerialData[nID].Static));

	
			ProcessBaseNumbers(nID);

			
			m_Grid.SetItemText(nID+2,BASENUMBER, _T(m_pJobInfo->SerialData[nID].BaseNumberSchema));
			m_Grid.SetItemText(nID+2,FIELDWIDTH, _T(m_pJobInfo->SerialData[nID].FieldWidth));
			m_Grid.SetItemText(nID+2,STEPSIZE, _T(m_pJobInfo->SerialData[nID].StepSize));

		


			m_Grid.SetItemText(nID+2,STARTINGSEQVALUE, _T(m_pJobInfo->SerialData[nID].StartingSequencNumber ));
			m_Grid.SetItemText(nID+2,MAXIMUMSEQVALUE, _T(m_pJobInfo->SerialData[nID].MaxSequenceNumber));
			
			m_Grid.SetItemText(nID+2,ROLLOVERVALUE, _T(m_pJobInfo->SerialData[nID].RollOverValue ));


			// CheckDigits
			if (!m_Grid.SetCellType(nID+2,CHKDIGITCOL, RUNTIME_CLASS(CGridCellCombo)))
				return;
			CGridCellCombo *pCell_ChkDgt = (CGridCellCombo*) m_Grid.GetCell(nID+2,CHKDIGITCOL);

			
			pCell_ChkDgt->SetOptions(m_csaChkDigitName);
			pCell_ChkDgt->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
			m_Grid.SetItemText(nID+2,CHKDIGITCOL, _T(m_pJobInfo->SerialData[nID].CheckDigit  ));


			if (!m_Grid.SetCellType(nID+2,ALLOWDUPLICATES, RUNTIME_CLASS(CGridCellCheck)))
				return;
			
			SetCheckBox(nID+2,ALLOWDUPLICATES,m_pJobInfo->SerialData[nID].AllowDuplicates);


		}
		else
			break;

	}
	m_Grid.SetModified(FALSE); 
}


void CDataSeriesDlg::GetCheckDigits()
{
int nBaseCntr=0;
CString csChkDigitName;

	m_csaChkDigitName.RemoveAll(); 
	for (nBaseCntr=2128;nBaseCntr<=2223;nBaseCntr++ )
	{
			
		csChkDigitName.LoadString(nBaseCntr); 
		m_csaChkDigitName.Add( _T(csChkDigitName));
		nBaseCntr++;


	}

	for (nBaseCntr=2240;nBaseCntr<=2243;nBaseCntr++ )
	{
			
		csChkDigitName.LoadString(nBaseCntr); 
		m_csaChkDigitName.Add( _T(csChkDigitName));
		nBaseCntr++;

	}

}


void CDataSeriesDlg::GetBaseNumberSchemas()
{
CUtilities *pUtil = new 	CUtilities();
NumberBases		*pNumberBases;	
int nBaseCntr=0;

	pNumberBases =  pUtil->GetNumberBases();
	while (!pNumberBases[nBaseCntr].BaseName.IsEmpty())
	{
			
		m_csaBaseSchema.Add( _T(pNumberBases[nBaseCntr].BaseName));
		nBaseCntr++;


	}
	delete pUtil;
}



void CDataSeriesDlg::VerifyGrid()
{
CString csName;
CString csStatic;	
CString csBaseNumberSchema;
CString csFieldWidth;
CString csStepSize;
CString csStartingSequencNumber;
CString csMaxSequenceNumber;	
CString csRollOverValue;
CString csCheckDigit;
CString csAllowDuplicates;



	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		  
		if (m_Grid.GetItemText(nID+2,DATASETSERIES).IsEmpty())	break;

		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			if( m_Grid.IsCellSelected(nID+2,nColumn) )
			{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nColumn);
				pCell->EndEdit();  
			
			}
		}
		
		
		csName.Format("%s",m_Grid.GetItemText(nID+2,DATASETSERIES));
		csStatic.Format("%s",m_Grid.GetItemText(nID+2,STATICINDEX));
		csBaseNumberSchema.Format("%s",m_Grid.GetItemText(nID+2,BASENUMBER));
		csFieldWidth.Format("%s",m_Grid.GetItemText(nID+2,FIELDWIDTH));
		csStepSize.Format("%s",m_Grid.GetItemText(nID+2,STEPSIZE));

		csStartingSequencNumber.Format("%s",m_Grid.GetItemText(nID+2,STARTINGSEQVALUE));
		csMaxSequenceNumber.Format("%s",m_Grid.GetItemText(nID+2,MAXIMUMSEQVALUE));
		csRollOverValue.Format("%s",m_Grid.GetItemText(nID+2,ROLLOVERVALUE));
		csCheckDigit.Format("%s",m_Grid.GetItemText(nID+2,CHKDIGITCOL));
		csAllowDuplicates.Format("%s",m_Grid.GetItemText(nID+2,ALLOWDUPLICATES));

		
		
		if (!csName.IsEmpty())	// No need for a combo if only one data definition
		{
			m_pJobInfo->SerialData[nID].Name = csName;
			m_pJobInfo->SerialData[nID].Static = csStatic;
			m_pJobInfo->SerialData[nID].BaseNumberSchema = csBaseNumberSchema;
			m_pJobInfo->SerialData[nID].FieldWidth = csFieldWidth;
			m_pJobInfo->SerialData[nID].StepSize  = csStepSize;


			m_pJobInfo->SerialData[nID].StartingSequencNumber = csStartingSequencNumber;
			m_pJobInfo->SerialData[nID].MaxSequenceNumber = csMaxSequenceNumber;
			m_pJobInfo->SerialData[nID].RollOverValue = csRollOverValue;
			m_pJobInfo->SerialData[nID].CheckDigit = csCheckDigit;

		
			CGridCellCheck *pCell = (CGridCellCheck*) m_Grid.GetCell(nID+2,ALLOWDUPLICATES);
			if (pCell->GetCheck())
			{
				m_pJobInfo->SerialData[nID].AllowDuplicates ="YES"; 
			}
			else
			{
				m_pJobInfo->SerialData[nID].AllowDuplicates ="NO"; 
			}
			
			
	
		
		}
		else
			break;

	}
	m_Grid.SetModified(FALSE); 
}

BOOL CDataSeriesDlg::IsModified()
{
CString csTemp;

	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		for (int nColumn=0;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
				CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nColumn);
				csTemp.Empty(); 
				csTemp=pCell->GetText();
				if (csTemp.IsEmpty()) return FALSE; 

				if (pCell->IsModified())
					return TRUE;
				if( pCell->IsSelected() )
				{
					pCell->EndEdit();
					if (pCell->IsModified())
						return TRUE;
				}

		}
	}
	return FALSE;
}

BOOL CDataSeriesDlg::IsColSelected(int nCol)
{
CString csTemp;

	for (int nID=0;nID<MAXDATASERIES;nID++)
	{
		if (m_Grid.GetItemText(nID+2,0).IsEmpty()) return FALSE;  
		
		CGridDefaultCell *pCell = (CGridDefaultCell*) m_Grid.GetCell(nID+2,nCol);
		csTemp.Empty(); 
		csTemp=pCell->GetText();
		if (csTemp.IsEmpty()&&(nCol==0)) return FALSE; 

		if( pCell->IsSelected() )
		{
		//	delete pCell;	
			return TRUE;
		}
	//	delete pCell;
	}
		
	return FALSE;
}


void CDataSeriesDlg::SetCheckBox(int nRow, int nColumn, CString csValue )
{

 GV_ITEM Item;
	
   Item.crBkClr = RGB(255,255,255);             


	
	m_Grid.SetCellType(nRow,nColumn, RUNTIME_CLASS(CGridCellCheck));
	CGridCellCheck *pCell = (CGridCellCheck*) m_Grid.GetCell(nRow,nColumn);


    Item.mask = GVIF_TEXT;
	Item.row = nRow;
	Item.col = nColumn;
	
	csValue.MakeUpper(); 
	if (csValue.Find("Y")!=-1)
	{
		Item.strText = "YES";
		Item.crFgClr = RGB(0,0,255);    
		pCell->SetCheck(TRUE);

	}
	else
	{
		Item.strText = "NO";
		Item.crFgClr = RGB(255,0,0);    
		pCell->SetCheck(FALSE); 


	}
    Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
	m_Grid.SetItem(&Item);
	m_Grid.Refresh();  
	

}

void CDataSeriesDlg::ProcessScanCheck (int nRowID, int nColID)
{
BOOL blnResetToFALSE=FALSE;
	GV_ITEM Item;
    Item.crBkClr = RGB(255,255,255);             // or - m_Grid.SetItemBkColour(row, col, clr);

	if (nRowID<m_Grid.GetFixedRowCount())return;
	if (m_Grid.GetItemText(nRowID,0).IsEmpty())
	{


		CGridCellCheck* pCell = (CGridCellCheck*) m_Grid.GetCell(nRowID,nColID);
		pCell->SetCheck(FALSE);
		m_Grid.Refresh(); 	
		return;    
	}
	
	

	CGridCellCheck* pCell = (CGridCellCheck*) m_Grid.GetCell(nRowID,nColID);
	
	

    Item.mask = GVIF_TEXT;
	Item.row = nRowID;
	Item.col = nColID;



	if(pCell->GetCheck()==1)
	{
		Item.strText = "YES";
        Item.crFgClr = RGB(0,0,255);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    

	}
	else
	{

        Item.strText = "N0";
        Item.crFgClr = RGB(255,0,0);    // or - m_Grid.SetItemFgColour(row, col, RGB(255,0,0));				    
	}
    Item.mask    |= (GVIF_BKCLR|GVIF_FGCLR);
    m_Grid.SetItem(&Item);
	m_Grid.Refresh(); 
	   	 

}



void CDataSeriesDlg::WinHelp(DWORD dwData, UINT nCmd) 
{

	
}

BOOL CDataSeriesDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{

HWND hwnd;

	


	if (IsColSelected(DATASETSERIES))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_INDEX_NAME);	

		return TRUE;	

	}
	
	if (IsColSelected(STATICINDEX))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_STATIC_INDEX);	

		return TRUE;	

	}


	if (IsColSelected(BASENUMBER))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_CMB_SCHEMA);	

		return TRUE;	

	}
	
	if (IsColSelected(FIELDWIDTH))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_MAXWIDTH);	

		return TRUE;	

	}

	
	if (IsColSelected(STEPSIZE))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_STEP_SIZE);	

		return TRUE;	

	}

	
	
	if (IsColSelected(STARTINGSEQVALUE))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_SSN);	

		return TRUE;	

	}

	if (IsColSelected(MAXIMUMSEQVALUE))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_MSN);	

		return TRUE;	

	}


	if (IsColSelected(ROLLOVERVALUE))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_ROLL_VALUE);	

		return TRUE;	

	}

	
	if (IsColSelected(CHKDIGITCOL))
	{

		return ::WinHelp(AfxGetMainWnd()->m_hWnd  ,"CHECKHELP.HLP",
				HELP_INDEX,0);

	}

	if (IsColSelected(ALLOWDUPLICATES))
	{

		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_CHK_EXTERNAL_NO_DUPLICATES);	

		return TRUE;	

	}



		hwnd=HtmlHelp(AfxGetMainWnd()->m_hWnd  ,"JoTSHelp.chm",
			HH_HELP_CONTEXT,HIDC_TXB_DATA_SERIES);	

		return TRUE;	
}

void CDataSeriesDlg::OnDataseriesCopy() 
{
int nCount=0;
int nRow;
CString csTemp;
BOOL blnFoundBlankRow=FALSE;
	for (nCount=0;nCount<MAXDATASERIES;nCount++)
	{
		nRow=nCount+m_Grid.GetFixedRowCount(); 
		if (m_Grid.GetItemText(nRow,0).IsEmpty()) 
		{
			blnFoundBlankRow=TRUE;
			break;
		}

	}
	nCount=m_Grid.GetRowCount();
	if (nRow>=m_Grid.GetRowCount()) 
	{
		nCount=m_Grid.InsertRow(NULL,-1); 
		for (int nCol=0;nCol<COLUMNCOUNT;nCol++)
		{
			m_Grid.SetItemFormat(nCount,nCol,DT_CENTER|DT_VCENTER);
		}
		m_Grid.SetRowHeight(nCount,25); 

	}

	
	if ((blnFoundBlankRow)&&(nRow<MAXDATASERIES))
	{
		csTemp=m_Grid.GetItemText(m_nCurrentRow,DATASETSERIES); 
		m_Grid.SetItemText(nRow,DATASETSERIES,csTemp);

		csTemp=m_Grid.GetItemText(m_nCurrentRow,STATICINDEX); 
		m_Grid.SetItemText(nRow,STATICINDEX,csTemp);


		ProcessBaseNumbers(nRow-m_Grid.GetFixedRowCount());
		csTemp=m_Grid.GetItemText(m_nCurrentRow,BASENUMBER); 
		m_Grid.SetItemText(nRow,BASENUMBER, csTemp);

		csTemp=m_Grid.GetItemText(m_nCurrentRow,STEPSIZE); 
		m_Grid.SetItemText(nRow,STEPSIZE,csTemp);


		csTemp=m_Grid.GetItemText(m_nCurrentRow,FIELDWIDTH); 
		m_Grid.SetItemText(nRow,FIELDWIDTH,csTemp);

		csTemp=m_Grid.GetItemText(m_nCurrentRow,STARTINGSEQVALUE); 
		m_Grid.SetItemText(nRow,STARTINGSEQVALUE,csTemp);

		csTemp=m_Grid.GetItemText(m_nCurrentRow,MAXIMUMSEQVALUE); 
		m_Grid.SetItemText(nRow,MAXIMUMSEQVALUE,csTemp);
		
		csTemp=m_Grid.GetItemText(m_nCurrentRow,ROLLOVERVALUE); 
		m_Grid.SetItemText(nRow,ROLLOVERVALUE,csTemp);


		

		// CheckDigits
		
		if (!m_Grid.SetCellType(nRow,CHKDIGITCOL, RUNTIME_CLASS(CGridCellCombo)))
			return;
		CGridCellCombo *pCell_ChkDgt = (CGridCellCombo*) m_Grid.GetCell(nRow,CHKDIGITCOL);

		
		pCell_ChkDgt->SetOptions(m_csaChkDigitName);
		pCell_ChkDgt->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	

		csTemp=m_Grid.GetItemText(m_nCurrentRow,CHKDIGITCOL); 
		
		m_Grid.SetItemText(nRow,CHKDIGITCOL,csTemp);


		if (!m_Grid.SetCellType(nRow,ALLOWDUPLICATES, RUNTIME_CLASS(CGridCellCheck)))
			return;
		
		csTemp=m_Grid.GetItemText(m_nCurrentRow,ALLOWDUPLICATES);
		SetCheckBox(nRow,ALLOWDUPLICATES,csTemp);

	}
	m_Grid.Refresh();
	m_Grid.ExpandColumnsToFit(TRUE);
}

void CDataSeriesDlg::OnDataseriesDelete() 
{
	// Do not delete first row
	if (m_nCurrentRow>m_Grid.GetFixedRowCount())
	{
		m_Grid.DeleteRow(m_nCurrentRow);
		m_Grid.Refresh(); 
		m_Grid.ExpandColumnsToFit(TRUE);
	}
		
}


void CDataSeriesDlg::ProcessBaseNumbers(int nRowID)
{

CGridCellCombo *pCell;


	// Templates
	if (!m_Grid.SetCellType(nRowID+m_Grid.GetFixedRowCount(),
		BASENUMBER, RUNTIME_CLASS(CGridCellCombo)))
		return;
	pCell = (CGridCellCombo*) m_Grid.GetCell(nRowID+2,BASENUMBER);
	pCell->SetOptions(m_csaBaseSchema);
	pCell->SetStyle(CBS_DROPDOWN); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


}

void CDataSeriesDlg::OnBtnUpdate() 
{
//	if (!VerifyGrid())return;

	VerifyGrid();
	::SendMessage(m_hwndParent,UWM_UPDATE_TEMPLATE,0,0); 

	
}
