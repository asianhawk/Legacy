// ComPortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "ComPortDlg.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComPortDlg dialog


CComPortDlg::CComPortDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CComPortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComPortDlg)
	m_csBaudRate = _T("");
	m_csComPortID = _T("");
	m_csDataBits = _T("");
	m_csParity = _T("");
	m_csStopBits = _T("");
	//}}AFX_DATA_INIT
}


void CComPortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComPortDlg)
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDC_CMB_STOP_BITS, m_cmbStopBits);
	DDX_Control(pDX, IDC_CMB_PARITY, m_cmbParity);
	DDX_Control(pDX, IDC_CMB_DATA_BITS, m_cmbDataBits);
	DDX_Control(pDX, IDC_CMB_BAUDRATE, m_cmbBaudRate);
	DDX_Control(pDX, IDC_CMB_COM_PORT, m_cmbComPortID);
	DDX_CBString(pDX, IDC_CMB_BAUDRATE, m_csBaudRate);
	DDX_CBString(pDX, IDC_CMB_COM_PORT, m_csComPortID);
	DDX_CBString(pDX, IDC_CMB_DATA_BITS, m_csDataBits);
	DDX_CBString(pDX, IDC_CMB_PARITY, m_csParity);
	DDX_CBString(pDX, IDC_CMB_STOP_BITS, m_csStopBits);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComPortDlg, CDialog)
	//{{AFX_MSG_MAP(CComPortDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComPortDlg message handlers


void CComPortDlg::InitControls()
{
CString csTemp;

	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
		

	// format controls
	GetDlgItem(IDC_LBL_COMPORT)->SetFont(&font);
	GetDlgItem(IDC_CMB_COM_PORT)->SetFont(&font);
	
	for (int nCount=1;nCount<=12;nCount++)
	{
		csTemp.Format("COM%d",nCount); 
		m_cmbComPortID.AddString(csTemp);
	}

	GetDlgItem(IDC_LBL_BAUDRATE)->SetFont(&font);
	GetDlgItem(IDC_CMB_BAUDRATE)->SetFont(&font);
	m_cmbBaudRate.AddString("1200");
	m_cmbBaudRate.AddString("2400");
	m_cmbBaudRate.AddString("9600");
	m_cmbBaudRate.AddString("19200");
	m_cmbBaudRate.AddString("38400");
	m_cmbBaudRate.AddString("57600");
	m_cmbBaudRate.AddString("115200");



	GetDlgItem(IDC_LBL_PARITY)->SetFont(&font);
	GetDlgItem(IDC_CMB_PARITY)->SetFont(&font);
	m_cmbParity.AddString("None");
	m_cmbParity.AddString("Even");
	m_cmbParity.AddString("Odd");




	GetDlgItem(IDC_LBL_DATA_BITS)->SetFont(&font);
	GetDlgItem(IDC_CMB_DATA_BITS)->SetFont(&font);
	m_cmbDataBits.AddString("8");
	m_cmbDataBits.AddString("7");



	GetDlgItem(IDC_LBL_STOP_BITS)->SetFont(&font);
	GetDlgItem(IDC_CMB_STOP_BITS)->SetFont(&font);
	m_cmbStopBits.AddString("1");
	m_cmbStopBits.AddString("2");

	// format label controls
	
	m_btnOK.SetFont(&font);
	m_btnOK.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnOK.SetIcon(IDI_OK);
	m_btnOK.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnCancel.SetFont(&font);
	m_btnCancel.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnCancel.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnCancel.SetIcon(IDI_CANCEL1);
	m_btnCancel.SetAlign(CButtonST::ST_ALIGN_HORIZ);



}

BOOL CComPortDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitControls();	
	GetComPortData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CComPortDlg::GetComPortData()
{
CUtilities oUtils;
SerialPortData PortData;


	oUtils.GetComPortInfo(&PortData);
	
	m_csComPortID = PortData.Name;
	m_csBaudRate = PortData.BaudRate; 
	m_csParity = PortData.Parity;
	m_csDataBits.Format("%d",PortData.Wordlength);
	m_csStopBits.Format("%d",PortData.StopBits); 
	UpdateData(FALSE);

}

void CComPortDlg::SetComPortData()
{


}

void CComPortDlg::OnOK() 
{
CUtilities oUtils;
SerialPortData PortData;
	UpdateData(TRUE);
	
	if (m_csComPortID.IsEmpty())
	{
		oUtils.ErrorMessage("Com Port Not Defined");
		return;
	}
	PortData.Name = m_csComPortID;

	if (m_csBaudRate.IsEmpty())
	{
		oUtils.ErrorMessage("Baud Rate Not Defined");
		return;
	}
	PortData.BaudRate  = m_csBaudRate;

	if (m_csParity.IsEmpty())
	{
		oUtils.ErrorMessage("Parity Not Defined");
		return;
	}
	PortData.Parity  = m_csParity;
	
	if (m_csDataBits.IsEmpty())
	{
		oUtils.ErrorMessage("Data Bits Not Defined");
		return;
	}
	PortData.Wordlength   = atoi(m_csDataBits);


	if (m_csStopBits.IsEmpty())
	{
		oUtils.ErrorMessage("Stop Bit(s) Not Defined");
		return;
	}
	PortData.StopBits    = atoi(m_csStopBits);

	if(!oUtils.SetComPortInfo(PortData))
		return;

	CDialog::OnOK();
}
