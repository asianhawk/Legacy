#if !defined(AFX_ADDJOBSTEP4_H__4CE123E6_D57B_4868_A4D8_E12EFCC6B2C2__INCLUDED_)
#define AFX_ADDJOBSTEP4_H__4CE123E6_D57B_4868_A4D8_E12EFCC6B2C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddJobStep4.h : header file
//
#include "Edit Class Ex/amsEdit.h"
/////////////////////////////////////////////////////////////////////////////
// CAddJobStep4 dialog

class CAddJobStep4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddJobStep4)

// Construction
public:
	CAddJobStep4();
	~CAddJobStep4();

// Dialog Data
	//{{AFX_DATA(CAddJobStep4)
	enum { IDD = IDD_ADDJOB_STEP4 };
	BOOL	m_blnUTemplate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddJobStep4)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddJobStep4)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void				InitControls();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDJOBSTEP4_H__4CE123E6_D57B_4868_A4D8_E12EFCC6B2C2__INCLUDED_)
