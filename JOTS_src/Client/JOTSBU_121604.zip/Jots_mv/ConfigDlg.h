#if !defined(AFX_CONFIGDLG_H__39340962_2E81_4061_AA6D_BF9CF8E0113F__INCLUDED_)
#define AFX_CONFIGDLG_H__39340962_2E81_4061_AA6D_BF9CF8E0113F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfigDlg.h : header file
//
#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"
#include "GridCtrl_src/GridCellCombo.h"

#include "GridBtnCell_src\BtnDataBase.h"

#include "Btns/BtnST.h"
#include "Btns/ShadeButtonST.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog

class CConfigDlg : public CDialog
{
// Construction
public:
	CConfigDlg(CWnd* pParent = NULL);   // standard constructor
	~CConfigDlg();
	CGridCtrl			m_Grid;
	
	CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls
	
	void				InitGrid();
	void				InitControls();
	BOOL				IsModified(int nRow);
	void				SetUpScrollButton(int nRow, int nCol);
	void				SetUpComboBtns(int nRow, int nCol, CStringArray &csaArray);
	void				SetUpGridBtn(int nRow, int nCol);

// Dialog Data
	//{{AFX_DATA(CConfigDlg)
	enum { IDD = IDD_DLG_CONFIGURATION };
	CShadeButtonST	m_btnOK;
	CShadeButtonST	m_btnCancel;
	CStatic	m_lblTitle;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfigDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConfigDlg)
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CConfigDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGDLG_H__39340962_2E81_4061_AA6D_BF9CF8E0113F__INCLUDED_)
