#if !defined(AFX_TCPCOMM_H__813D56BE_83B1_43DB_9982_77323F25817C__INCLUDED_)
#define AFX_TCPCOMM_H__813D56BE_83B1_43DB_9982_77323F25817C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TCPComm.h : header file
//

class CLMorphor3;

/////////////////////////////////////////////////////////////////////////////
// CTCPComm command target

class CTCPComm : public CSocket
{
// Attributes
public:

// Operations
public:
	CTCPComm(CLMorphor3 *pMorphor);
	virtual ~CTCPComm();
	CLMorphor3 *m_pMorphor;
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTCPComm)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CTCPComm)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
//	CLMorphor3 *m_pMorphor;
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPCOMM_H__813D56BE_83B1_43DB_9982_77323F25817C__INCLUDED_)
