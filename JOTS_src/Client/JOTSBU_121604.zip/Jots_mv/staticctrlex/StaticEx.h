/////////////////////////////////////////////////////////////////////////////
// StaticEx.hxx : header file - implementation file is StaticEx.cxx
//
// Copyright (C) 1996 Bill Berry
// All rights reserved.
//
// This class is freely distributable as long as the copyright accompanies 
// the header and implementaion sources.
//
// Modification History:
//
// Modification History:
//
// Bill Berry	November 1996		Created
//              March    1998           Update
// Ted Sarma    September 2002		Cleanup and defect fixes
//
// March update now includes Paul DiLascia's code from MSJ which
// allows the control to be used as a web link.
//
// Description:
//
//  Extended CStatic class. Allows easy customization of the following:
//
//      1. COLORREF CStaticEx::bkColor( COLORREF crColor )
//         - Sets back ground color of the control
//
//      2. COLORREF CStaticEx::textColor( COLORREF crColor )
//         - Sets text or foreground color of the control
//
//      3. COLORREF bkColor() const
//         - Returns back ground color of control
//
//      4. COLORREF textColor() const
//         - Returns text (or foreground) color of control
//
//
#if !defined(AFX_STATICEX_H__CC617FC0_4FE2_11D1_9E2E_40E806C10000__INCLUDED_)
#define AFX_STATICEX_H__CC617FC0_4FE2_11D1_9E2E_40E806C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

typedef void (*CWND_INIT_FUNCTION)();

/////////////////////////////////////////////////////////////////////////////
// CStaticEx window

class CStaticEx : public CStatic
{
// Construction
public:
	CStaticEx();

// Copy Semantics

   // Block copy construction...
   //
   // No m_hWnd defined for object. 
   //
private:
   CStaticEx( const CStaticEx& ); 

public:
   // Allow basics to be copied...
   CStaticEx& operator = ( const CStaticEx& );

public:
    DECLARE_DYNCREATE( CStaticEx )

// Attributes

    // Font control
    //
    void setFont( const LOGFONT* lpLogFont );

    void setFont( LONG fontHeight      = -8, 
                  LONG fontWeight      = FW_NORMAL,
                  UCHAR pitchAndFamily = DEFAULT_PITCH | FF_DONTCARE,
                  LPCSTR faceName      = _T("MS Sans Serif" ) );
    
    // Control coloring of the static object
    //
    COLORREF bkColor  ( COLORREF );    
    COLORREF bkColor()   const { return m_crBkColor;   }   
    
    COLORREF textColor( COLORREF );
    COLORREF textColor() const { return m_crTextColor; }


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStaticEx)
	//}}AFX_VIRTUAL

// Implementation
	virtual ~CStaticEx();

	// Generated message map functions
protected:
	//{{AFX_MSG(CStaticEx)
	//}}AFX_MSG

	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
    
	DECLARE_MESSAGE_MAP()

    // Customize your brush
    //
    virtual BOOL CreateBrushType();

private:

    UINT     m_wm_message;          // the windows message event
                                    // initialize the m_showThisCwnd object

    WPARAM   m_msg_flags;           // data to send on click events

    CBrush   m_brBkGround;          // the back ground brush

    COLORREF m_crBkColor;
    COLORREF m_crTextColor;
    COLORREF m_crOnClickColor;
    CFont*   m_pCFont;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATICEX_H__CC617FC0_4FE2_11D1_9E2E_40E806C10000__INCLUDED_)
