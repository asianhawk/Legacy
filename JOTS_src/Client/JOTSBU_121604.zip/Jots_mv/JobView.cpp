// JobView.cpp : implementation file
//


#include "stdafx.h"
#include "JoTS.h"
#include "JoTSDoc.h"
#include "JobView.h"
#include "DisplayTemplatesDlg.h"
#include "DisplayLabelsDlg.h"
#include "DataSeriesDlg.h"
#include "VariableDataDlg.h"

#include "MainRunDlg.h"

#include "MorphorTCPSetupDlg.h"


#include "JobWizard.h"
#include "Utilities.h"

#include "RunDlg.h"

#include "MainFrm.h"


#include "Thread1.h"
#include "Thread2.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



#define LABELS_DLG					0
#define TEMPLATES_EDIT_DLG			1
#define TEMPLATEVARS_DLG			2
#define DATAFACTORIES_DLG			3

/////////////////////////////////////////////////////////////////////////////
// CJobView

#define ID_TABCTRL	1111			// id for the CTabCtrl


IMPLEMENT_DYNCREATE_ATL(CJobView, CFormView)

CJobView::CJobView()
	: CFormView(CJobView::IDD)
{
	EnableAutomation();
	m_tabMain = NULL;
	//{{AFX_DATA_INIT(CJobView)
	m_csJobName = _T("");
	m_csProductDescription = _T("");
	m_csCompanyName = _T("");
	m_csMaxRePrints = _T("");
	m_csMaxReScans = _T("");
	//}}AFX_DATA_INIT
	m_blnNewJob=TRUE;
	m_nRunDlgIndex=0;
	m_blnRunOleMode=FALSE;
	m_lngRunStatus=-1;
	m_pProcessJob=NULL;
	m_dwThread=0;
	m_nViewState=0;
}

CJobView::~CJobView()
{
		if (m_tabMain)
		delete m_tabMain;
	int num = m_DlgArray.GetSize();

	for (int i = 0; i < num; i++)
	{
		if (m_DlgArray[i])
			delete m_DlgArray[i];
	}
	m_DlgArray.RemoveAll(); 

}

void CJobView::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CFormView::OnFinalRelease();
}

void CJobView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJobView)
	DDX_Control(pDX, IDC_TXB_RESCANS, m_txbMaxReScans);
	DDX_Control(pDX, IDC_TXB_REPRINTS, m_txbMaxRePrints);
	DDX_Control(pDX, IDC_TXB_COMPANY, m_txbCompanyName);
	DDX_Control(pDX, IDC_TXB_PRODUCT, m_txbProductDescription);
	DDX_Control(pDX, IDC_TXB_JOB_NAME, m_txbJobName);
	DDX_Text(pDX, IDC_TXB_JOB_NAME, m_csJobName);
	DDX_Text(pDX, IDC_TXB_PRODUCT, m_csProductDescription);
	DDX_Text(pDX, IDC_TXB_COMPANY, m_csCompanyName);
	DDX_Text(pDX, IDC_TXB_REPRINTS, m_csMaxRePrints);
	DDX_Text(pDX, IDC_TXB_RESCANS, m_csMaxReScans);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJobView, CFormView)
	//{{AFX_MSG_MAP(CJobView)
	ON_COMMAND(ID_SETUP_SECURITY_ACCESS_RIGHTS, OnSetupSecurityAccessRights)
	ON_COMMAND(ID_SETUP_SECURITY_USER, OnSetupUserAccount)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_FILE_JOBS_OPEN, OnFileJobsOpen)
	ON_COMMAND(ID_FILE_JOBS_NEW, OnFileJobsNew)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_RUN_SINGLE, OnRunSingle)
	ON_COMMAND(ID_SETUP_MORPHOR_NETWORK, OnSetupMorphorNetwork)
	ON_COMMAND(ID_FILE_CLOSE, OnFileClose)
	ON_COMMAND(ID_EDIT_JOB_INFORMATION, OnEditJobInformation)
	ON_COMMAND(ID_EDIT_JOB_LABELS, OnEditJobLabels)
	ON_COMMAND(ID_EDIT_DATA_SERIES, OnEditDataSeries)
	ON_COMMAND(ID_EDIT_TEMPLATES, OnEditTemplates)
	ON_COMMAND(ID_EDIT_VARIABLE_DATA, OnEditVariableData)
	ON_COMMAND(ID_SETUP_SYSTEMCONFIGURATION, OnSetupSystemconfiguration)
	ON_COMMAND(ID_SETUP_CUSTOM_BASENUMBER, OnSetupCustomBasenumber)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
		ON_UPDATE_COMMAND_UI(ID_FILE_JOBS_NEW,OnUpdateRunSingle)
		ON_UPDATE_COMMAND_UI(ID_FILE_SAVE,OnUpdateRunSingle)
		ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS,OnUpdateRunSingle)
		ON_UPDATE_COMMAND_UI(ID_RUN_SINGLE,OnUpdateRunSingle)
		ON_UPDATE_COMMAND_UI(ID_APP_EXIT,OnUpdateRunSingle)
		ON_UPDATE_COMMAND_UI(ID_FILE_CLOSE,OnUpdateRunSingle)
	ON_MESSAGE(UWM_RESET_VIEW, OnReset)
	ON_MESSAGE(UWM_UPDATE_TEMPLATE, OnUpdateTemplates)
//	ON_COMMAND(ID_APP_EXIT, OnAppExit)
	//}}AFX_MSG_MAP
	ON_NOTIFY(TCN_SELCHANGE, ID_TABCTRL, OnTabSelChange)
	ON_NOTIFY(TCN_SELCHANGING, ID_TABCTRL, OnTabSelChanging)

END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CJobView, CFormView)
	//{{AFX_DISPATCH_MAP(CJobView)
	DISP_PROPERTY_EX(CJobView, "Product", GetProduct, SetProduct, VT_BSTR)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IJobView to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {F9498455-5223-4C6E-BE82-DBE882916E4A}
static const IID IID_IJobView =
{ 0xf9498455, 0x5223, 0x4c6e, { 0xbe, 0x82, 0xdb, 0xe8, 0x82, 0x91, 0x6e, 0x4a } };

BEGIN_INTERFACE_MAP(CJobView, CFormView)
	INTERFACE_PART(CJobView, IID_IJobView, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJobView diagnostics

#ifdef _DEBUG
void CJobView::AssertValid() const
{
	CFormView::AssertValid();
}

void CJobView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJobView message handlers


void CJobView::OnDraw(CDC* pDC) 
{
CString csJobName;

	if(m_blnNewJob)
	{
		CJoTSDoc* pDoc = GetDocument();
		csJobName=pDoc->GetJobName(); 
		if (!csJobName.IsEmpty())
		{
			m_blnNewJob=FALSE;
			UpDateJobView();
			
		}
	}
	OnTabSelChange(NULL,NULL);
}


CJoTSDoc* CJobView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJoTSDoc)));
	return (CJoTSDoc*)m_pDocument;
}

void CJobView::OnSetupSecurityAccessRights() 
{

	CAccessRightsDlg *pDlg = new CAccessRightsDlg();
	pDlg->DoModal();
	
	delete pDlg;

}

void CJobView::OnSetupUserAccount() 
{
	CUserAccountDlg *pDlg = new CUserAccountDlg();
	pDlg->DoModal();

	delete pDlg;
	
}

BOOL CJobView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CFormView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);


}


int CJobView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_tabMain = new CTabCtrl;
	ASSERT(m_tabMain);

		
	if (m_tabMain->Create(
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, 
		CRect(0, 0, 0, 0), this, ID_TABCTRL) == FALSE)
		return -1;

	// Create all pages for the tab control.
	CreatePages();
	

	
	
	
	return 0;
}


void CJobView::CreatePages()
{


	// Create page 1 and add it to dialog array
	
	CDialog*	dlg;
	// Create page one and add it to dialog array.

	m_DisplayDlg = new CDisplayLabelsDlg;
	m_DisplayDlg->m_hwndParent = GetSafeHwnd();
	m_DlgArray.Add(m_DisplayDlg);
	VERIFY(m_DisplayDlg->Create(IDD_MAIN_LABELS, m_tabMain));


	// Create page two and add it to dialog array.
	

	m_TemplatesDlg = new CDisplayTemplatesDlg;
	m_TemplatesDlg->m_hwndParent = GetSafeHwnd(); 
	m_DlgArray.Add(m_TemplatesDlg);
	VERIFY(m_TemplatesDlg->Create(IDD_MAIN_TEMPLATES, m_tabMain));	
	
	


	// Create page 3 and add it to dialog array.

	m_VariableDataDlg = new CVariableDataDlg;


	m_DlgArray.Add(m_VariableDataDlg);
	VERIFY(m_VariableDataDlg->Create(IDD_VARIABLE_DATA, m_tabMain));





	// Create page 4 and add it to dialog array.

	m_DataSeriesDlg = new CDataSeriesDlg;
	m_DataSeriesDlg->m_hwndParent = GetSafeHwnd();
	m_DlgArray.Add(m_DataSeriesDlg);
	VERIFY(m_DataSeriesDlg->Create(IDD_DATA_SERIES, m_tabMain));




	// Create page 5 and add it to dialog array.


	m_XMLTreeDlg = new CXMLTreeDlg();
	m_DlgArray.Add(m_XMLTreeDlg);
	VERIFY(m_XMLTreeDlg->Create(IDD_XML_TREE, m_tabMain));

	
	m_Tip.Create(this);
	m_Tip.AddTool(m_DisplayDlg,"Test"); 

	// Determine the tab text.  The tab text can be found from the 
	// dialog template.

	m_imageList.Create (IDB_BITMAP2, 19, 1, RGB(255,255,255));
	m_tabMain->SetImageList(&m_imageList); 

	m_hIcon1 = (HICON)::LoadImage(AfxFindResourceHandle(MAKEINTRESOURCE(IDI_ICON_INFORMATION), RT_GROUP_ICON), MAKEINTRESOURCE(IDI_ICON_INFORMATION), IMAGE_ICON, 0, 0, 0);
	CString csTip;
	csTip.LoadString(IDS_TIP_JOB_NAME); 
	
	char str[50];
	TC_ITEM tci;
	
	tci.mask	= TCIF_IMAGE|TCIF_TEXT;
//	tci.mask = TCIF_TEXT;
//	tci.iImage	= -1;
	for (int i = 0; i < m_DlgArray.GetSize(); i++)
	{	
		// Get the caption from dialog template and insert this caption
		// to the tab control.
		dlg = m_DlgArray[i];
		dlg->GetWindowText(str, sizeof(str));
		tci.pszText	= str;
		tci.iImage = i;
		m_tabMain->InsertItem(i, &tci);
	


		// Remove caption from the dialog box because no caption is allowed
		// for pages in the tab control.
		dlg->ModifyStyle(WS_CAPTION, 0);

		// IMPORTANT: Why sending a WM_NCACTIVATE message to the dialog box?
		// When writing this sample, we found a problem which is related to
		// the edit control refuses to give up the input focus when mouse is 
		// being clicked on some other edit control.  This problem only 
		// happens when title bar is found from a dialog resource.  And we
		// need the title bar because it is the text in the tab control.  
		// Sending a WM_NCACTIVATE message seems to fix the problem.
		dlg->SendMessage(WM_NCACTIVATE, TRUE);
		
//		if (i!=4)
		dlg->EnableWindow(FALSE); 






	}



}

void CJobView::OnSize(UINT nType, int cx, int cy) 
{
	// For the future when auto scaling is implemented.
/*
RECT rect;	
int nLeft=0,
    nRight,
	nBottom;
	rect.left = rect.right = rect.top = rect.bottom =0; 
	CFormView::OnSize(nType, cx, cy);
	if (m_txbJobName.m_hWnd) 
	{
		m_txbJobName.GetRect(&rect);
		ClientToScreen(&rect);
		nLeft=rect.left; 
	}
	if (m_txbMaxRePrints.m_hWnd) 
	{
		m_txbMaxRePrints.GetRect(&rect);
		ClientToScreen(&rect);
		nRight=rect.left; 
	}
*/	
	m_tabMain->MoveWindow(10, 140, cx-15, (int) cy*.7);
	
}

void CJobView::OnTabSelChange(NMHDR* pnmhdr, LRESULT* pResult)
{
	// Get the rectangle size of the tab control so we know the position 

	// and size of the page that will be shown.
	RECT rc;
	m_tabMain->GetItemRect (0, &rc);

	// Call GetCurSel() will return the index of the page that is newly
	// selected.  This page will be visible soon.
	int sel_index = m_tabMain->GetCurSel();

	if(sel_index>=0)
	{

		m_DlgArray[sel_index]->SetWindowPos (
			NULL, 
			rc.left /*+ 5*/, rc.bottom /*+ 5*/, 0, 0, 
			SWP_NOSIZE | SWP_NOZORDER | SWP_SHOWWINDOW);
		
		// Set input focus to this page.
		m_DlgArray[sel_index]->SetFocus();
	
	}


//	*pResult = TRUE;	// no return value according to online documentation
}	


void CJobView::OnTabSelChanging(NMHDR* pnmhdr, LRESULT* pResult)
{

	// Call GetCurSel() here will return the index of the page that
	// will be hidden soon.  This is NOT the newly selected page when 
	// OnTabSelChange() is called.
	int sel_index = m_tabMain->GetCurSel();
	if (sel_index>=0)
	{
		m_DlgArray[sel_index]->ShowWindow(SW_HIDE);
		*pResult = FALSE;		// return FALSE to allow seletion to change
	}

}

void CJobView::OnFileJobsOpen() 
{
CString csJobFileName;
CUtilities *pUtil;
CString csJobsDirectory;

   m_blnNewJob = FALSE;

   pUtil = new CUtilities();
   if (!pUtil->GetJobsDirectory(&csJobsDirectory))
   {

		delete pUtil;
		return;
   }
   CFileDialog fileDlg(TRUE, NULL, NULL, 
	                   OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY, 
					   "Job Files (*.xml)|*.xml||", this);


   fileDlg.m_ofn.lpstrTitle = "Select Job File";
   fileDlg.m_ofn.lpstrInitialDir=csJobsDirectory;

	// Call DoModal
	if ( fileDlg.DoModal() == IDOK)
	{
		csJobFileName = fileDlg.GetPathName(); // This is your selected file name with path
		if (csJobFileName.IsEmpty())
		{
			AfxMessageBox("No File Name Selected");

		}
	}

	if (!csJobFileName.IsEmpty())
	{
		m_pDoc=(CJoTSDoc*)AfxGetApp()->OpenDocumentFile(csJobFileName);

		if (m_pDoc)
			m_blnNewJob=TRUE;
	}
	delete pUtil;

    	 

}


BOOL CJobView::OnFileJobsOpen(CString csJobName) 
{
CString csJobFileName;
CUtilities oUtil;

	m_blnNewJob = FALSE;
	csJobFileName = csJobName;

	if (!oUtil.IsFileValid(csJobName))
	{

		return FALSE;

	}

	if (!csJobFileName.IsEmpty()) 
	{
		m_pDoc=(CJoTSDoc*)AfxGetApp()->OpenDocumentFile(csJobFileName);
		
		if (m_pDoc)
			m_blnNewJob=TRUE;
	}
	return m_blnNewJob;

}




void CJobView::OnFileJobsNew() 
{
CJobWizard objWizard;
CUtilities *pUtil;
CString csJobsDirectory,
		csTemp,
		csErrorMsg;


	objWizard.CreateNewJob(); 
//	csTemp=objWizard.m_udfJobInfo.Name;
	csTemp=objWizard.GetJobName() ;

	csTemp.MakeLower();
	csTemp.Replace(".xml",""); 
	if (!csTemp.IsEmpty())
	{
	   pUtil = new CUtilities();
	   if (!pUtil->GetJobsDirectory(&csJobsDirectory))
	   {
		  delete pUtil;
		  return;
	   }
 	  
	   csTemp=csJobsDirectory+csTemp+".xml";
	   if(pUtil->IsFileValid(csTemp))
		  OnFileJobsOpen(csTemp);
	   else
	   {
		   csErrorMsg.Format("New Job File [%s] Not Found",csTemp);
	 	   pUtil->ErrorMessage(csErrorMsg,"File Not Found");

	   }


	  delete pUtil;

	}
}

void CJobView::OnFileSave() 
{



    
	
	m_DisplayDlg->UpdateData(TRUE);
	m_DataSeriesDlg->UpdateData(TRUE);
	m_VariableDataDlg->UpdateData(TRUE); 
	


	// Process Tabbed Dialogs for Updates

	if(!m_DisplayDlg->VerifyGrid())
		return;

	m_DataSeriesDlg->VerifyGrid();


	if (!m_VariableDataDlg->VerifyGrids())
		return;
	else
		m_VariableDataDlg->UpdateGrids();
	
	m_TemplatesDlg->SetModified(FALSE);  

	CJoTSDoc* pDoc = GetDocument();

	UpdateJobHeaderInfo();
	pDoc->SaveJob(); 
	
	
}
BOOL CJobView::UpdateJobHeaderInfo()
{
CString csJobName;

	CJoTSDoc* pDoc = GetDocument();
	csJobName = pDoc->GetJobName()   ; 

	if (!csJobName.IsEmpty())	
	{
		csJobName+=".xml";
	CUtilities *pUtil = new CUtilities();

		UpdateData(TRUE);
		pDoc->m_oXML.GetJobInfo()->Name = m_csJobName; 
		pDoc->m_oXML.GetJobInfo()->Customer =m_csCompanyName ;
		pDoc->m_oXML.GetJobInfo()->ProductDescription = m_csProductDescription; 
		pDoc->m_oXML.GetJobInfo()->Reprints =m_csMaxRePrints;
		pDoc->m_oXML.GetJobInfo()->Rescans  =m_csMaxReScans;		
//		pUtil->SetJobFileInfo(&pDoc->m_oXML,pDoc->GetJobInfo());
		pUtil->SetJobFileInfo(pDoc);
		delete pUtil;
	}

	return TRUE;


}

void CJobView::UpDateJobView()
{
CString csBuffer;
//LabelInfo *pLabelInfo;
	
	CJoTSDoc* pDoc = GetDocument();
	
	m_csJobName=pDoc->GetJobName();
	m_csCompanyName=pDoc->GetCompanyName();

	m_csProductDescription=pDoc->GetProduct();  
	m_csMaxReScans = pDoc->GetMaxReScans();
	m_csMaxRePrints = pDoc->GetMaxRePrints(); 



	m_DisplayDlg->m_pJobInfo=pDoc->m_oXML.GetJobInfo();	
	m_DisplayDlg->UpdateGrid();

	m_DataSeriesDlg->m_pJobInfo=pDoc->m_oXML.GetJobInfo();
	m_DataSeriesDlg->UpdateGrid();


	m_TemplatesDlg->m_pJobInfo=pDoc->m_oXML.GetJobInfo();
	m_TemplatesDlg->UpdateCombo();


	m_VariableDataDlg->m_pJobInfo = pDoc->m_oXML.GetJobInfo(); 


	m_VariableDataDlg->UpdateGrids();

    m_XMLTreeDlg->m_pJobInfo=pDoc->m_oXML.GetJobInfo();	

	m_XMLTreeDlg->BuildTree();
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
		

	// format label controls
	GetDlgItem(IDC_LBL_JOBNAME)->SetFont(&font);
	GetDlgItem(IDC_LBL_COMPANY)->SetFont(&font);
	GetDlgItem(IDC_LBL_PRODUCT)->SetFont(&font);
	GetDlgItem(IDC_LBL_REPRINTS)->SetFont(&font);
	GetDlgItem(IDC_LBL_RESCANS)->SetFont(&font);





	font.SetFaceName(_T("Arial"));
	font.SetHeight(16);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	
	
	// format text controls

	GetDlgItem(IDC_TXB_JOB_NAME)->SetFont(&font);
	GetDlgItem(IDC_TXB_COMPANY)->SetFont(&font);
	GetDlgItem(IDC_TXB_PRODUCT)->SetFont(&font);

	GetDlgItem(IDC_TXB_REPRINTS)->SetFont(&font);
	GetDlgItem(IDC_TXB_RESCANS)->SetFont(&font);


	UpdateData(FALSE);


}


void CJobView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();




}

BOOL CJobView::PreCreateWindow(CREATESTRUCT& cs) 
{

 

	return CFormView::PreCreateWindow(cs);
}


void CJobView::OnFileSaveAs() 
{
CString csJobFileName,
		csJobsDirectory;
CUtilities *pUtil;

  CFileDialog fileDlg(FALSE, NULL, NULL, 
	                   OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY, 
					   "Job Files (*.xml)|*.xml||");


   pUtil = new CUtilities();
   if (!pUtil->GetJobsDirectory(&csJobsDirectory))
   {

		delete pUtil;
		return;
   }

  
  
  
   fileDlg.m_ofn.lpstrTitle = "Select Job Record";
   fileDlg.m_ofn.lpstrInitialDir = csJobsDirectory;

	// Call DoModal
	if ( fileDlg.DoModal() == IDOK)
	{
		csJobFileName = fileDlg.GetPathName(); // This is your selected file name with path
		if (csJobFileName.IsEmpty())
		{
			AfxMessageBox("No File Name Selected");
			return;

		}
	}




	m_DisplayDlg->UpdateData(TRUE);
	m_DataSeriesDlg->UpdateData(TRUE);
	m_VariableDataDlg->UpdateData(TRUE); 
	


	// Process Tabbed Dialogs for Updates

	m_DisplayDlg->VerifyGrid();
	m_DataSeriesDlg->VerifyGrid();

	if (!m_VariableDataDlg->VerifyGrids())
		return;

	CJoTSDoc* pDoc = GetDocument();

	pDoc->SaveJobAs(csJobFileName); 
	m_TemplatesDlg->SetModified(FALSE);
	delete pUtil;
	
}

STDMETHODIMP CJobView::OpenJobDlg()
{
	METHOD_PROLOGUE_ATL


	OnFileJobsOpen();
	

	return S_OK;
}

STDMETHODIMP CJobView::CloseJob()
{
	METHOD_PROLOGUE_ATL

	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CJobView::get_ProductDescription(BSTR *pVal)
{
CString csProduct;

	METHOD_PROLOGUE_ATL


    if (m_pDoc)
		csProduct = m_pDoc->GetProduct(); 

	if (!csProduct.IsEmpty())
		*pVal = csProduct.AllocSysString();
	
	return S_OK;
}

STDMETHODIMP CJobView::put_ProductDescription(BSTR newVal)
{
	METHOD_PROLOGUE_ATL

	return S_OK;
}

BSTR CJobView::GetProduct() 
{

	return m_csProductDescription.AllocSysString();
}

void CJobView::SetProduct(LPCTSTR lpszNewValue) 
{
	// TODO: Add your property handler here

}

STDMETHODIMP CJobView::OpenJob(BSTR newVal, BOOL *blnIsOpen)
{
CString csJobName;
	METHOD_PROLOGUE_ATL


   		
	csJobName.Format("%S",newVal);    	
	if (OnFileJobsOpen(csJobName))
	{
		*blnIsOpen = TRUE;
	}
	else
	{
		*blnIsOpen = FALSE;

	}
	return S_OK;
}


void CJobView::CheckForJobRecordChanges() 
{
BOOL blnSaveJob=FALSE;
CUtilities *pUtil=NULL;
CString csTemp;
	// Save Everything First
	pUtil = new CUtilities();

	
	
	if(m_DisplayDlg->IsModified())
	{
		csTemp.LoadString(IDS_CHANGE_LABELS) ;
		blnSaveJob=pUtil->UserResponse(csTemp) ;

	}

	if(m_DataSeriesDlg->IsModified())
	{
		csTemp.LoadString(IDS_CHANGE_DATA_FACTORIES) ;
		blnSaveJob=pUtil->UserResponse(csTemp) ;

	}
	if(m_TemplatesDlg->IsModified())
	{
		csTemp.LoadString(IDS_CHANGE_TEMPLATE_VARS) ;
		blnSaveJob=pUtil->UserResponse(csTemp);
		m_TemplatesDlg->SetModified(FALSE);


	}
	


	if (blnSaveJob)
		OnFileSave();

	delete pUtil;

}

BOOL CJobView::CheckJobReferentialIntegrity()
{
BOOL blnValidData=TRUE;
CString csTemp;

	if(!m_DisplayDlg->VerifyTemplates())
	{
		CUtilities *pUtil = new CUtilities();
		csTemp.LoadString(IDS_INVALID_TEMPLATE) ;
		pUtil->ErrorMessage(csTemp) ;
		blnValidData=FALSE;
		delete pUtil;
	}


	CUtilities *pUtil = new CUtilities();
	CJoTSDoc* pDoc = GetDocument();
	if(!pUtil->IsJobRecordOK(pDoc->GetJobInfo())) 
	{
		delete pUtil;
		return FALSE;
	}

	return blnValidData;
}

void CJobView::OnUpdateRunSingle(CCmdUI* pCmdUI) 
{
	if(m_nViewState==1)
	{
		pCmdUI->Enable(FALSE); 	
	}
	else
	{
		pCmdUI->Enable(TRUE); 	
	}

}

void CJobView::OnRunSingle() 
{


CLMorphor3 *pMorphor=NULL;
CString csTCPAddress;
CString csTCPPort;
CProcessJob *pProcessJob=NULL;
CString csTemp;
CJoTSDoc* pDoc;

	if (!m_blnRunOleMode)
	{
		CheckForJobRecordChanges();

		if (!CheckJobReferentialIntegrity())
			return;
		DisplayRunJobView();
		pDoc = GetDocument();

	}
	else
		pDoc = m_pDoc;
;
	if (pDoc)
	{
		pDoc->PreProcessInfo();
		pMorphor= new CLMorphor3();
//		pMorphor->SetConnectionType(TCPCONNECTION);

		pMorphor->SetConnectionType(SERIALCONNECTION);
		pMorphor->SetModeType(CMDLANGINTERPRET);

		pProcessJob = new CProcessJob(pDoc,pMorphor);
		if (!m_blnRunOleMode) 
			pProcessJob->SetRunDlg((CRunDlg*)m_DlgArray[m_nRunDlgIndex-1]); 

		// PROMPT_FOR_QTY
		CUtilities *pUtil = new CUtilities();

		if (!m_blnRunOleMode) 
		{		
			csTemp=pUtil->GetConfigValue(PROMPT_FOR_QTY);
			csTemp.MakeUpper();
			if (csTemp.Find("Y")!=-1)
			{

				AfxMessageBox("Input Label Qty");
				pProcessJob->SetMaxItems(10);

			}
			else
				pProcessJob->SetMaxItems(-1);

		}
		else
			pProcessJob->SetMaxItems(-1);



		if (!pMorphor->OpenChannel())
		{
			if (pProcessJob)
				delete pProcessJob;

			if (pMorphor)
				delete pMorphor;
			
			delete pUtil;
			
			return;
		}
		if(!pMorphor->IsMorphorReady())
		{
			pMorphor->CloseChannel();

			
			if (!m_blnRunOleMode)
			{
				CString csErrMessage;
				csErrMessage.LoadString(IDS_ERR_CONNECTING_TO_MORPHOR); 
				pUtil->ErrorMessage(csErrMessage,"Unable To Connect To Morphor"); 
			}
			RestoreJobView();
			
			
			delete pUtil;
			return;
	
		}
		RedrawWindow();
		m_nViewState=1;
		if (m_blnRunOleMode)
			pProcessJob->AutoPrint();
		else
			pProcessJob->Run();

			

		pMorphor->CloseChannel();
	}
	if (pProcessJob)
		delete pProcessJob;

	if (pMorphor)
		delete pMorphor;

	if (!m_blnRunOleMode)
	{
		RestoreJobView();
		m_DataSeriesDlg->UpdateGrid();
	}
	m_nViewState=0;
}

void CJobView::OnSetupMorphorNetwork() 
{
CMorphorTCPSetupDlg *pDlg;

	pDlg = new CMorphorTCPSetupDlg();

	pDlg->DoModal();

	delete pDlg;
	
}

void CJobView::OnFileClose() 
{
int nResponse=0;
CString csTemp; 
	CUtilities *pUtil = new CUtilities();
	if(m_DisplayDlg->IsModified() )
	{
		if(pUtil->UserResponse("Label Data Has Been Modified!.Save Changes?"))
		{
			
			OnFileSave();	

		}
		
	}
	else if (m_DataSeriesDlg->IsModified())
	{
		if(pUtil->UserResponse("Data Definition Records Have Been Modified!.Save Changes?"))
		{
			OnFileSave();	

		}


	}
	else if (m_VariableDataDlg->IsModified())
	{
//		if(pUtil->UserResponse("Template Variables Have Been Modified!.Save Changes?"))
//		{
			OnFileSave();	

//		}

	}
	else if(m_TemplatesDlg->IsModified())
	{
		csTemp.LoadString(IDS_CHANGE_TEMPLATE_VARS) ;

		if(pUtil->UserResponse("Template Variables Have Been Modified!.Save Changes?"))
		{
			OnFileSave();	

		}
		m_TemplatesDlg->SetModified(FALSE); 

	}



	CJoTSDoc* pDoc = GetDocument();
	pDoc->OnCloseDocument();
	delete pUtil;
}

void CJobView::OnEditJobInformation() 
{

//	m_txbJobName.SetReadOnly(FALSE);  
//	GetDlgItem(IDC_TXB_JOB_NAME)->EnableWindow(TRUE);
	
	m_txbCompanyName.SetReadOnly(FALSE);  
	GetDlgItem(IDC_TXB_COMPANY)->EnableWindow(TRUE);

	m_txbProductDescription.SetReadOnly(FALSE);  
	GetDlgItem(IDC_TXB_PRODUCT)->EnableWindow(TRUE);


	m_txbMaxRePrints.SetReadOnly(FALSE);  
	GetDlgItem(IDC_TXB_REPRINTS)->EnableWindow(TRUE);

	m_txbMaxReScans.SetReadOnly(FALSE);  
	GetDlgItem(IDC_TXB_RESCANS)->EnableWindow(TRUE);

	m_txbCompanyName.SetFocus();  

	
}

void CJobView::OnEditJobLabels() 
{
	// LABELS_DLG

	UnLockTab(LABELS_DLG);



		
}

void CJobView::OnEditDataSeries() 
{

	UnLockTab(DATAFACTORIES_DLG);
	
}

void CJobView::OnEditTemplates() 
{

	UnLockTab(TEMPLATES_EDIT_DLG);


}

void CJobView::OnEditVariableData() 
{

	UnLockTab(TEMPLATEVARS_DLG);
	


}

void CJobView::UnLockTab(int nID)
{
	TC_ITEM tci;
	tci.mask	= TCIF_IMAGE|TCIF_TEXT;
	char str[50];

	m_DlgArray[nID]->GetWindowText(str, sizeof(str));
	tci.pszText	= str;
	tci.iImage = 5;
	m_tabMain->SetItem(nID, &tci);
	

	int sel_index = m_tabMain->GetCurSel();
	m_DlgArray[sel_index]->ShowWindow(SW_HIDE);
	m_tabMain->SetCurSel(nID);
	
	OnTabSelChange(NULL,NULL);
	m_DlgArray[nID]->EnableWindow(TRUE);


}


void CJobView::OnSetupSystemconfiguration() 
{
	CConfigDlg *pDlg = new 	CConfigDlg();

	pDlg->DoModal(); 
	delete pDlg;
	
}

void CJobView::OnSetupCustomBasenumber() 
{
CBaseSchemaDlg *pDlg = new CBaseSchemaDlg();

	pDlg = new CBaseSchemaDlg();
	
	pDlg->DoModal();
	
	delete pDlg;
	
}



void CJobView::DeleteTabItems()
{

	m_tabMain->DeleteAllItems(); 

	int num = m_DlgArray.GetSize();

	for (int i = 0; i < num; i++)
	{
		if (m_DlgArray[i])
			delete m_DlgArray[i];
	}
	m_DlgArray.RemoveAll();
	m_nRunDlgIndex=-1;
}

void CJobView::AddRunTab()
{

	


CDialog*	dlg;

	dlg = new CRunDlg();
	ASSERT(dlg);
	m_DlgArray.Add(dlg);
	VERIFY(dlg->Create(IDD_RUN, m_tabMain));

	m_nRunDlgIndex=m_DlgArray.GetSize();// since it was added to the end


	// Determine the tab text.  The tab text can be found from the 
	// dialog template.

//	m_imageList.Create (IDB_BITMAP2, 19, 1, RGB(255,255,255));
//	m_tabMain->SetImageList(&m_imageList); 
	char str[50];
	TC_ITEM tci;

//	tci.mask	= TCIF_IMAGE|TCIF_TEXT;
	tci.mask = TCIF_TEXT;
	tci.iImage	= -1;
	// Get the caption from dialog template and insert this caption
	// to the tab control.

	
	dlg = m_DlgArray[m_nRunDlgIndex-1];
	dlg->GetWindowText(str, sizeof(str));
	tci.pszText	= str;
//		tci.iImage = i;
	m_tabMain->InsertItem(m_nRunDlgIndex-1, &tci);



	// Remove caption from the dialog box because no caption is allowed
	// for pages in the tab control.
	dlg->ModifyStyle(WS_CAPTION, 0);
	dlg->SendMessage(WM_NCACTIVATE, TRUE);
	OnTabSelChange(NULL,NULL);
	m_DlgArray[m_nRunDlgIndex-1]->EnableWindow(TRUE);
	  

}



void CJobView::RestoreJobView() // remove Run screen and return to Job View
{
	DeleteTabItems();
	m_nRunDlgIndex=-1;
	if (m_Tip)
	{
		m_Tip.RemoveAllTools();
		m_Tip.DestroyWindow(); 
	}
	if (m_imageList)
	{
		m_imageList.DeleteImageList(); 
	
	}
	CreatePages();
	UpDateJobView();
	OnTabSelChange(NULL,NULL);
	m_DlgArray[0]->SetFocus(); 

}
void CJobView::DisplayRunJobView()
{
	DeleteTabItems();
	AddRunTab();


}




BOOL CJobView::PreTranslateMessage(MSG* pMsg) 
{

	m_Tip.RelayEvent(pMsg); // Let the ToolTip process this message.

	return CFormView::PreTranslateMessage(pMsg);
}





void CJobView::OnFileNew() 
{
	
	
}

STDMETHODIMP CJobView::Run(BSTR JobName)
{

	METHOD_PROLOGUE_ATL

CString csJobName;
	csJobName=JobName;
	


	if (!csJobName.IsEmpty()) 
	{
		if(OnFileJobsOpen(csJobName))
		{
			AutoStart();	
			AutoRun();	
		}
	}

	return S_OK;
}

STDMETHODIMP CJobView::Start()
{
	METHOD_PROLOGUE_ATL
	
	if (GetServerState()!=0) 
	{
		SetRunStatus(JOBERROR);
		m_pProcessJob->m_csErrorMessage="JoTS Not ShutDown Properly Last Time";		
		return S_FALSE;
	}
	SetServerState(1);

	m_blnRunOleMode=TRUE;
	AutoStart();
	SetRunStatus(JOBSTARTEDOK); 
	return S_OK;
}

STDMETHODIMP CJobView::Stop()
{
	AutoStop();
	return S_OK;
}



STDMETHODIMP CJobView::get_Status(long *pVal)
{

	METHOD_PROLOGUE_ATL
	
	m_lngRunStatus=m_pProcessJob->GetState();
	*pVal= m_lngRunStatus;

	return S_OK;
}


void CJobView::SetRunStatus(long lngStatus)
{
	m_pProcessJob->SetState(lngStatus);

}

long CJobView::GetRunStatus()
{
	return m_lngRunStatus;

}





BOOL CJobView::AutoStart() 
{


CString csTCPAddress;
CString csTCPPort;
CString csTemp;
CJoTSDoc* pDoc;
	CUtilities *pUtil = new CUtilities();



	pDoc = m_pDoc;

	if(!pUtil->IsJobRecordOK(pDoc->GetJobInfo())) 
	{
		delete pUtil;
		return FALSE;
	}
	


	if (pDoc)
	{
		pDoc->PreProcessInfo();
		m_pMorphor= new CLMorphor3();
//		pMorphor->SetConnectionType(TCPCONNECTION);

		m_pMorphor->SetConnectionType(SERIALCONNECTION);
		m_pMorphor->SetModeType(CMDLANGINTERPRET);

		m_pMorphor->SetQuietMode(TRUE);
		m_pProcessJob = new CProcessJob(pDoc,m_pMorphor);

		m_pProcessJob->SetMaxItems(-1);



		if (!m_pMorphor->OpenChannel())
		{
			if (m_pProcessJob)
				delete m_pProcessJob;

			
			delete pUtil;
			SetRunStatus(ERRORCONNECTINGTOM3);
			return FALSE;
		}
		else
		{


		}


		if(!m_pMorphor->IsMorphorReady())
		{
			m_pMorphor->CloseChannel();

			delete pUtil;
			SetRunStatus(ERRORCONNECTINGTOM3);
			return FALSE;
	
		}

	}

	if (pUtil)
		delete pUtil;
	m_pProcessJob->AutoInit(); 
	SetRunStatus(JOBSTARTEDOK);
	return TRUE;
}


BOOL CJobView::AutoStop() 
{
//	CreateThread
int nReturnState;
	if (m_dwThread!=0)
	{
		// Wait until the watcher thread has stopped

		nReturnState=::WaitForSingleObject(m_dwThread,2000);
		if (nReturnState==WAIT_OBJECT_0)
			::CloseHandle(m_dwThread);

		m_dwThread = 0;



		// Close handle to the thread

	}
	if(m_pMorphor->IsMorphorReady())
	{
		m_pMorphor->ResetApplicator(); 
		m_pMorphor->CloseChannel();
	}
//	m_pMorphor->StopApplicator(TRUE); 

	SetRunStatus(JOBSTOPPED);
	SetServerState(0);
	return TRUE;
}

BOOL CJobView::AutoRun() 
{

    Sleep(1000);
	m_dwThread=MSVC::runInThread(*m_pProcessJob,&CProcessJob::AutoPrint);
	
	return TRUE;
}

STDMETHODIMP CJobView::PrintOne()
{



	if (AutoRun()) 
		return S_OK;

	return S_FALSE;
}

STDMETHODIMP CJobView::get_ErrorMessage(BSTR *pVal)
{

	METHOD_PROLOGUE_ATL

	if(!m_pProcessJob)
		*pVal = m_pProcessJob->GetErrorMessage().AllocSysString();
	return S_OK;
}

STDMETHODIMP CJobView::PrintJob(BSTR JobName, BOOL *blnCompleted)
{
	METHOD_PROLOGUE_ATL
CString csJobName;

	csJobName=JobName;
	
//	OnFileJobsOpen(csJobName);


	if (!csJobName.IsEmpty()) 
	{
		if(!AutoRun())
			*blnCompleted=FALSE;
		else
			*blnCompleted=TRUE;
	}
	else
		m_pProcessJob->SetState(JOBERROR); 

	return S_OK;
}

STDMETHODIMP CJobView::ScanLabel(BOOL *blnCompleted)
{

	METHOD_PROLOGUE_ATL
	
	
	*blnCompleted=m_pProcessJob->ScanLabel();

	return S_OK;
}

STDMETHODIMP CJobView::get_GetBarCode(BSTR *pVal)
{
	METHOD_PROLOGUE_ATL
CString csBarCode;

	csBarCode = m_pProcessJob->GetCurrentSerialNumber(); 
	*pVal = csBarCode.AllocSysString();

	return S_OK;
}

STDMETHODIMP CJobView::get_LabelsPerUnit(short *pVal)
{
	METHOD_PROLOGUE_ATL

	*pVal= m_pProcessJob->GetLabelsPerUnit(); 

	return S_OK;
}


void CJobView::SetServerState(int nState)
{
CStdioFile fh;
CString csState;
CFileException e;
CFileFind ff;

	if (nState!=0)
	{
		fh.Open("c:\\JoTS.dat",  CFile::modeCreate | CFile::modeWrite, &e);
		csState.Format("ServerState:=%d",nState);
		fh.WriteString(csState);
		fh.Close();
	}
	else
	{
		if (ff.FindFile("c:\\JJoTS.dat")!=0)
		{
			DeleteFile("c:\\JoTS.dat");

		}

	}

}
int CJobView::GetServerState()
{
CFileFind ff;
int nState;

	nState=ff.FindFile("c:\\JoTS.dat",NULL); 
	if (nState!=0)
	{
		CUtilities oUtil;
		oUtil.ErrorMessage("A Previous Version Of JoTS Crashed. Open The Task Manager And Terminate It Before Beginning");
		return TRUE;
	}
	return FALSE;
}

LRESULT CJobView::OnReset(WPARAM wp, LPARAM lp)
{

	
   m_VariableDataDlg->UpdateGrids();  

 //  CJoTSDoc* pDoc = GetDocument();
//   pDoc->SaveJob(); 
   return 1;

}



LRESULT CJobView::OnUpdateTemplates(WPARAM wp, LPARAM lp)
{
int nCount=0;
int nBCVar=0;
int nHRVar=0;	
   JobInfo *pJobInfo;
int nCount2=0;
BOOL blnDuplicate=FALSE;

   CJoTSDoc* pDoc = GetDocument();
   pJobInfo=pDoc->GetJobInfo(); 


   while (!pJobInfo->Templates[nCount].Name.IsEmpty())
   {
		nBCVar=0;
		while (!pJobInfo->Templates[nCount].BCVars[nBCVar].Name.IsEmpty())
		{
			pJobInfo->Templates[nCount].BCVars[nBCVar].Name.Empty();
			pJobInfo->Templates[nCount].BCVars[nBCVar].Prefix.Empty();
			pJobInfo->Templates[nCount].BCVars[nBCVar].Suffix.Empty();
			pJobInfo->Templates[nCount].BCVars[nBCVar].Data.Empty();  
			nBCVar++;
		}

		nHRVar=0;
		while (!pJobInfo->Templates[nCount].HRVars[nHRVar].Name.IsEmpty())
		{
			pJobInfo->Templates[nCount].HRVars[nHRVar].Name.Empty();
			pJobInfo->Templates[nCount].HRVars[nHRVar].Prefix.Empty();
			pJobInfo->Templates[nCount].HRVars[nHRVar].Suffix.Empty();
			pJobInfo->Templates[nCount].HRVars[nHRVar].Data.Empty();  
			nHRVar++;
		}
		pJobInfo->Templates[nCount].Name.Empty();
		nCount++;

   
   }
   
   nCount=0;

   while(!pJobInfo->LabelInfo[nCount].TemplateName.IsEmpty())   
   {

	   for (nCount2=0;nCount2<nCount;nCount2++)

	   {
		   if (pJobInfo->Templates[nCount2].Name==pJobInfo->LabelInfo[nCount].TemplateName)
		   {
              blnDuplicate=TRUE;
			  break;
		   }
		   
	   }
	   if (!blnDuplicate)
	   {
			pJobInfo->Templates[nCount].Name = pJobInfo->LabelInfo[nCount].TemplateName;
	   }
	   blnDuplicate=FALSE;
	   nCount++; 	

   }
   
   
   
   nCount=0;
   m_TemplatesDlg->UpdateCombo();

   while(!pJobInfo->Templates[nCount].Name.IsEmpty())   
   {
	   m_VariableDataDlg->UpdateTemplateGrid();  

	   m_TemplatesDlg->UpdateDataSeries2(pJobInfo->Templates[nCount].Name);  
	   nCount++;
   }

   
   
    	

//   pDoc->SaveJob(); 
   return 1;

}



void CJobView::OnAppExit() 
{
//	CheckForJobRecordChanges();

//	CJoTSDoc* pDoc = GetDocument();
//	pDoc->OnCloseDocument();

//	if (m_tabMain)
//	delete m_tabMain;
//	int num = m_DlgArray.GetSize();
//
//	for (int i = 0; i < num; i++)
//	{
//		if (m_DlgArray[i])
//			delete m_DlgArray[i];
//	}
//	m_DlgArray.RemoveAll(); 


//	exit(0);


}
