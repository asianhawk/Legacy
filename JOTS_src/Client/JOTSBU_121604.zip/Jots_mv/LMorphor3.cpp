// LMorphor3.cpp : implementation file
//

#include "stdafx.h"

#include "LMorphor3.h"
#include "Utilities.h"
#include "WaitingDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const CString csTRUE="1";
CWaitingDlg *pMsg=NULL;
/////////////////////////////////////////////////////////////////////////////
// CLMorphor3

CLMorphor3::CLMorphor3()
{
	Init();
	m_p=NULL;
}


CLMorphor3::CLMorphor3(CEdit *pCallBack)
{
	m_p=pCallBack;

}

CLMorphor3::CLMorphor3(JobInfo *pJobInfo )
{
	Init();
	m_p=NULL;
	m_pJobInfo=pJobInfo;
}



CLMorphor3::~CLMorphor3()
{
	if (m_pFile)
		delete m_pFile;

	if (m_pArchiveIn)
		delete m_pArchiveIn;

	if (m_pArchiveOut)
		delete m_pArchiveOut;
	

}

void CLMorphor3::Init()
{
	m_nConnectionType=-1;
	m_nModeType=-1;
	m_nConnectionStatus=-1;
	m_csTCPAddress = _T("");
	m_csTCPPort = _T("");

	m_pFile = NULL;
	m_pArchiveIn=NULL;
	m_pArchiveOut=NULL;

	SetSimulatorMode();
	m_blnQuietMode=FALSE;

}
int	CLMorphor3::GetConnectionType()
{
	return m_nConnectionType;
}

void CLMorphor3::SetConnectionType(int nConnectionType)
{


	m_nConnectionType=nConnectionType;
}


/////////////////////////////////////////////////////////////////////////////
// CLMorphor3 message handlers

int CLMorphor3::GetModeType()
{
	return m_nModeType;
}

void CLMorphor3::SetModeType(int nModeType)
{
	m_nModeType = nModeType;
}


BOOL CLMorphor3::OpenChannel()
{
BOOL blnState=TRUE;
CUtilities oUtil;
CString csTCPAddress;
CString csTCPPort,
		csResponse,
		csExpectedResponse;

	if (GetConnectionType()==TCPCONNECTION)
	{


		if (!oUtil.GetTCPAddress(&csTCPAddress))
		{
			oUtil.ErrorMessage("No TCP Address Found For The LM3");
			return FALSE;
		}
		if (!oUtil.GetTCPPort(&csTCPPort))
		{
			oUtil.ErrorMessage("No TCP Port Found For The LM3");
			return FALSE;
		
		}
		SetTCPAddress(csTCPAddress);
		SetTCPPort(csTCPPort);

		if (!ConnectLM3())
		{
			oUtil.ErrorMessage("No TCP Connection Made, Returning To Main Menu");
			return FALSE;

		}
		// Check to see if the Morphor is ready to process commands

		Transmit(HostInquiry(&csExpectedResponse));
		if (!IsValidResponse(csExpectedResponse)) return FALSE;
	
		
	}
	else if (GetConnectionType()==SERIALCONNECTION)
	{

		if (!OpenPort())
		{
			return FALSE;
		}


	
	}
	else
	{
		oUtil.ErrorMessage("Connection Type Not Defined");
		return FALSE;

	}

	SetConnectionStatus(READY);

	return blnState;
}

BOOL CLMorphor3::IsMorphorReady()
{
CString csExpectedResponse;
BOOL blnWaiting=FALSE;
int nTimeOut=0;

	if (GetConnectionType()==SERIALCONNECTION)
	{
	
		if (!blnWaiting)
		{
//			m_pComPort->StartListener();
		
			m_pComPort->Purge(); 
			i_CallbackOutput.SetCallback(this, &CLMorphor3::GetSerialBuffer );
	
			m_pComPort->SetCallBack(&i_CallbackOutput);
			Transmit(HostInquiry(&csExpectedResponse));
			blnWaiting=TRUE;
			m_pComPort->StopListener(INFINITE);
			WaitDlg(TRUE);
			CUtilities *pUtil = new CUtilities();
			nTimeOut = atoi(pUtil->GetConfigValue(MORPHOR_TIMEOUT)); 
			delete pUtil;
			if(ListenWithMaxTimeOut(nTimeOut*1000))
			{
				WaitDlg(FALSE);
				if (GetSimulatorMode()) return TRUE;
				
				if(m_csReceivedMessage.Find(csExpectedResponse)!=-1)
					return TRUE;
			}
			WaitDlg(FALSE);
			return FALSE;
			
		}
	}
	return FALSE;
}


BOOL CLMorphor3::IsValidResponse(CString csExpectedResponse)
{
CString csResponse;
CUtilities *pUtil=NULL;
BOOL blnState=FALSE;
CPerfTimer tmr(TRUE);
CWaitingDlg *pMsg = new CWaitingDlg();
int nTimeOut;

	
	pUtil= new CUtilities();
	nTimeOut = atoi(pUtil->GetConfigValue(MORPHOR_TIMEOUT)); 
	if (abs(nTimeOut)>100)
		nTimeOut=5;
	pMsg->m_csTitle="Connecting To Morphor";
	pMsg->SetRanges(0,nTimeOut); 
	if(pMsg->Create(IDD_WAITING_DLG,NULL)==FALSE)
	{
		delete pMsg;
		delete pUtil;
		return FALSE;
	}
	pMsg->ShowWindow(SW_SHOW);
	Listen(INFINITE/*nTimeOut*/);
	while (!GetReceivedMessage(&csResponse))
	{

		if (GetSimulatorMode())
		{
			if (tmr.Elapsed()> (int)(nTimeOut*.67))
			{
				pMsg->ShowWindow(SW_HIDE);
				if (pMsg)
					delete pMsg;
				delete pUtil;
			}
			return TRUE;
		}

		if (tmr.Elapsed()>nTimeOut)
		{
			
			pMsg->ShowWindow(SW_HIDE);
			if (pMsg)
				delete pMsg;

			if(GetConnectionType()==SERIALCONNECTION) 
				pUtil->ErrorMessage("Serial Port Open But Morphor Not Responding");
			else if (GetConnectionType()==TCPCONNECTION) 
				pUtil->ErrorMessage("TCP Link Open But Morphor Not Responding");

			blnState=FALSE;
			if (pUtil)
				delete pUtil;
			return blnState;
		}
	
	}	
	pMsg->ShowWindow(SW_HIDE);
	delete pMsg;
	if (ChkResponse(csResponse,csExpectedResponse)&&(!csResponse.IsEmpty()) )
	{
		blnState=TRUE;
		
	}
	else 
	{
		m_csReceivedMessage=""; 
		if (IsValidResponse(csExpectedResponse)) blnState=TRUE;
	}

	if (pUtil)
		delete pUtil;
	return blnState;

}


void CLMorphor3::WaitDlg(BOOL blnStart)
{

int nTimeOut;

	
	if (blnStart)
	{
		pMsg = new CWaitingDlg();
		
		CUtilities *pUtil = new CUtilities();
		nTimeOut = atoi(pUtil->GetConfigValue(MORPHOR_TIMEOUT)); 
		if (abs(nTimeOut)>100)
			nTimeOut=5;
		pMsg->m_csTitle="Connecting To Morphor";
		pMsg->SetRanges(0,nTimeOut); 
		if(pMsg->Create(IDD_WAITING_DLG,NULL)==FALSE)
		{
			delete pMsg;
		}
		pMsg->ShowWindow(SW_SHOW);
		pMsg->YieldToWindows(); 
		delete pUtil;

	}
	else
	{
		if (pMsg)
		pMsg->ShowWindow(SW_HIDE);
		delete pMsg;
	}
}




BOOL CLMorphor3::Print(CString csLabelFormat)
{
	if (GetConnectionType()==TCPCONNECTION)
	{

		Transmit(csLabelFormat);

	}
	else if (GetConnectionType()==SERIALCONNECTION)
	{

		if(!SerialTransmit(csLabelFormat))
			return FALSE;

	}
	else
	{
		AfxMessageBox("Connection Type Not Defined");
		return FALSE;

	}

	return TRUE;

}

BOOL CLMorphor3::Scan(CString csOutput)
{
CString csTemp;
	if (GetConnectionType()==TCPCONNECTION)
	{

		Transmit(csOutput);

	}
	else if (GetConnectionType()==SERIALCONNECTION)
	{

		// Flush the buffer
		while(ListenWithMaxTimeOut(100))
		{
			csTemp=GetReceiveBuffer();
		}	
		
		
		SetReceivedBuffer("");

		if(!SerialTransmit(csOutput))
			return FALSE;

	}
	else
	{
		AfxMessageBox("Connection Type Not Defined");
		return FALSE;

	}

	return TRUE;

}



void CLMorphor3::Transmit(CString csMessage)
{
	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(csMessage);
	}
	else 
	{
		SendMsg(csMessage);
	}


	return;
}

//BOOL CLMorphor3::Listen()
//{
//BOOL blnState=TRUE;
//char Buffer[500];
//DWORD dwBytesRead=0;
//CUtilities oUtil;
//BOOL	blnDataReceived=FALSE;
//long	lLastError;
//const CSerial::EEvent eEvent=CSerial::EEventRecv;
//CString csTemp;
//
//	memset(Buffer,'\0',sizeof(Buffer)-1);
//	if (GetConnectionType()==TCPCONNECTION)
//	{
//
//
//
//	}
//	else if (GetConnectionType()==SERIALCONNECTION)
//	{
//
//		if (m_pComPort==NULL)
//		{
//	
//			return oUtil.ErrorMessage("Com Port Not Open");
//
//		}
//
//        lLastError = m_pComPort->SetupReadTimeouts(CSerial::EReadTimeoutNonblocking);
//
//		if (lLastError!=ERROR_SUCCESS)
//			return oUtil.ErrorMessage("Could Not Set Com Port Read Timeouts");
//
//		// Create a handle for the overlapped operations
//		HANDLE hevtOverlapped = ::CreateEvent(0,TRUE,FALSE,0);;
//		if (hevtOverlapped == 0)
//			return oUtil.ErrorMessage(m_pComPort->GetLastError()+ _T(" Unable to create manual-reset event for overlapped I/O."));
//
//
//		// Setup the overlapped structure
//		OVERLAPPED ov = {0};
//		ov.hEvent = hevtOverlapped;
//
//		// Open the "STOP" handle
//		HANDLE hevtStop = ::CreateEvent(0,TRUE,FALSE,_T("Overlapped_Stop_Event"));
//		if (hevtStop == 0)
//			return oUtil.ErrorMessage(m_pComPort->GetLastError()+ _T(" Unable to create manual-reset event for stop event."));
//
//		bool fContinue = true;
//		do
//		{
//
//			lLastError = m_pComPort->WaitEvent(&ov);
//			if (lLastError != ERROR_SUCCESS)
//				return oUtil.ErrorMessage(m_pComPort->GetLastError()+ _T("Unable to wait for a COM-port event."));			
//				
//			// Setup array of handles in which we are interested
//			HANDLE ahWait[2];
//			ahWait[0] = hevtOverlapped;
//			ahWait[1] = hevtStop;			
//				
//
//
//			// Wait until something happens
//			switch (::WaitForMultipleObjects(sizeof(ahWait)/sizeof(*ahWait),ahWait,FALSE,10000))
//			{
//					case WAIT_OBJECT_0:
//					{
//					// Save event
//					const CSerial::EEvent eEvent = m_pComPort->GetEventType();
//
//					// Handle break event
//					if (eEvent & CSerial::EEventBreak)
//					{
//						printf("\n### BREAK received ###\n");
//					}
//
//					// Handle CTS event
//					if (eEvent & CSerial::EEventCTS)
//					{
//						printf("\n### Clear to send %s ###\n", m_pComPort->GetCTS()?"on":"off");
//					}
//
//					// Handle DSR event
//					if (eEvent & CSerial::EEventDSR)
//					{
//						printf("\n### Data set ready %s ###\n", m_pComPort->GetDSR()?"on":"off");
//					}
//
//					// Handle error event
//					if (eEvent & CSerial::EEventError)
//					{
//						printf("\n### ERROR: ");
//						switch (m_pComPort->GetError())
//						{
//						case CSerial::EErrorBreak:		printf("Break condition");			break;
//						case CSerial::EErrorFrame:		printf("Framing error");			break;
//						case CSerial::EErrorIOE:		printf("IO device error");			break;
//						case CSerial::EErrorMode:		printf("Unsupported mode");			break;
//						case CSerial::EErrorOverrun:	printf("Buffer overrun");			break;
//						case CSerial::EErrorRxOver:		printf("Input buffer overflow");	break;
//						case CSerial::EErrorParity:		printf("Input parity error");		break;
//						case CSerial::EErrorTxFull:		printf("Output buffer full");		break;
//						default:						printf("Unknown");					break;
//						}
//						printf(" ###\n");
//					}
//
//					// Handle ring event
//					if (eEvent & CSerial::EEventRing)
//					{
//						printf("\n### RING ###\n");
//					}
//
//					// Handle RLSD/CD event
//					if (eEvent & CSerial::EEventRLSD)
//					{
//						printf("\n### RLSD/CD %s ###\n", m_pComPort->GetRLSD()?"on":"off");
//					}
//
//					// Handle data receive event
//					if (eEvent & CSerial::EEventRecv)
//					{
//						// Read data, until there is nothing left
//						DWORD dwBytesRead = 0;
//						csTemp.Empty(); 
//						do
//						{
//
//							// Read data from the COM-port
//							lLastError =m_pComPort->Read(Buffer,sizeof(Buffer)-1,&dwBytesRead);
//
//							if (lLastError != ERROR_SUCCESS)
//								return oUtil.ErrorMessage(m_pComPort->GetLastError() + _T("Unable to read from COM-port."));
//							
//							if (dwBytesRead > 0)
//								csTemp+=Buffer;
//						
//						}
//						while (dwBytesRead > 0);
//						fContinue = false;
//					}
//				}
//				break;
//
//				case WAIT_OBJECT_0+1:
//				{
//					// Set the continue bit to false, so we'll exit
//					fContinue = false;
//				}
//				break;
//
//				case WAIT_TIMEOUT:
//				{
//					// Set the continue bit to false, so we'll exit
//					fContinue = false;
//					return oUtil.ErrorMessage("Morphor Did Not Respond");
//
//				}
//				break;
//				default:
//				{
//					// Something went wrong
//					return oUtil.ErrorMessage(m_pComPort->GetLastError() + _T("Error while calling WaitForMultipleObjects."));
//				}
//				break;
//			}
//		}
//		while (fContinue);
//
//		
//		SetReceivedBuffer(csTemp);
//
//	}
//	else
//	{
//		return oUtil.ErrorMessage("Connection Type Not Defined");
//
//	}
//
//	return blnState;
//
//
//}


BOOL CLMorphor3::ConnectSocket(LPCTSTR lpszHandle, LPCTSTR lpszAddress, UINT nPort)
{
	m_strHandle = lpszHandle;

	m_pSocket = new CTCPComm(this);

	if (!m_pSocket->Create())
	{
		delete m_pSocket;
		m_pSocket = NULL;
		AfxMessageBox(IDS_CREATEFAILED);
		return FALSE;
	}

	while (!m_pSocket->Connect(lpszAddress, nPort + 700))
	{
		if (AfxMessageBox(IDS_RETRYCONNECT,MB_YESNO) == IDNO)
		{
			delete m_pSocket;
			m_pSocket = NULL;
			return FALSE;
		}
	}

	m_pFile = new CSocketFile(m_pSocket);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);

	CString strTemp;
	if (strTemp.LoadString(IDS_CONNECT))
		SendMsg(strTemp);

	return TRUE;
}

BOOL CLMorphor3::ConnectLM3()
{
	
	if (GetSimulatorMode()) return TRUE;
	m_pSocket = new CTCPComm(this);

	if (!m_pSocket->Create())
	{
		delete m_pSocket;
		m_pSocket = NULL;
		AfxMessageBox(IDS_CREATEFAILED);
		return FALSE;
	}

	while (!m_pSocket->Connect(GetTCPAddress(), atoi(GetTCPPort()) + 700))
	{
		if (AfxMessageBox(IDS_RETRYCONNECT,MB_YESNO) == IDNO)
		{
			delete m_pSocket;
			m_pSocket = NULL;
			return FALSE;
		}
	}

	m_pFile = new CSocketFile(m_pSocket);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);

	CString strTemp;
	if (strTemp.LoadString(IDS_CONNECT))
		SendMsg(strTemp);

	SetConnectionStatus(IDLE);
	return TRUE;
}


BOOL CLMorphor3::ConnectLM3(CString csTCPAddress, CString csTCPPort )
{
	if (GetSimulatorMode()) return TRUE;

	m_pSocket = new CTCPComm(this);

	if (!m_pSocket->Create())
	{
		delete m_pSocket;
		m_pSocket = NULL;
		AfxMessageBox(IDS_CREATEFAILED);
		return FALSE;
	}

	while (!m_pSocket->Connect(csTCPAddress, atoi(csTCPPort) + 700))
	{
		if (AfxMessageBox(IDS_RETRYCONNECT,MB_YESNO) == IDNO)
		{
			delete m_pSocket;
			m_pSocket = NULL;
			return FALSE;
		}
	}

	m_pFile = new CSocketFile(m_pSocket);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);

	CString strTemp;
	if (strTemp.LoadString(IDS_CONNECT))
		SendMsg(strTemp);

	SetConnectionStatus(IDLE);
	return TRUE;
}


void CLMorphor3::ProcessPendingRead()
{
	do
	{
		ReceiveMsg();
		if (m_pSocket == NULL)
			return;
	}
	while(!m_pArchiveIn->IsBufferEmpty());
}

void CLMorphor3::SendMsg(CString& strText)
{
	if (m_pArchiveOut != NULL)
	{
		CMsg msg;

		msg.m_strText = strText; //m_strHandle + _T(": ") + strText;

		TRY
		{
			msg.Serialize(*m_pArchiveOut);
			m_pArchiveOut->Flush();
		}
		CATCH(CFileException, e)
		{
			m_bAutoChat = FALSE;
			m_pArchiveOut->Abort();
			delete m_pArchiveOut;
			m_pArchiveOut = NULL;

			CString strTemp;
			if (strTemp.LoadString(IDS_SERVERRESET))
				DisplayMsg(strTemp);
		}
		END_CATCH
	}
}

void CLMorphor3::ReceiveMsg()
{
	CMsg msg;

	TRY
	{
		msg.Serialize(*m_pArchiveIn);

		while(!msg.m_msgList.IsEmpty())
		{
			CString temp = msg.m_msgList.RemoveHead();
			DisplayMsg(temp);
		}

	}
	CATCH(CFileException, e)
	{
		m_bAutoChat = FALSE;
		msg.m_bClose = TRUE;
		m_pArchiveOut->Abort();

		CString strTemp;
		if (strTemp.LoadString(IDS_SERVERRESET))
			DisplayMsg(strTemp);
		if (strTemp.LoadString(IDS_CONNECTIONCLOSED))
			DisplayMsg(strTemp);
	}
	END_CATCH

	if (msg.m_bClose)
	{
		delete m_pArchiveIn;
		m_pArchiveIn = NULL;
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
		delete m_pFile;
		m_pFile = NULL;
		delete m_pSocket;
		m_pSocket = NULL;
	}
}

void CLMorphor3::DisplayMsg(LPCTSTR lpszText)
{
	m_csReceivedMessage.Empty();
	m_csReceivedMessage=lpszText;

	if(m_p!=NULL)
		m_p->SetWindowText(lpszText);
}

BOOL CLMorphor3::GetReceivedMessage(CString *csMessage)
{
	if (GetSimulatorMode())
	{
		m_csReceiveBuffer="OK";
		*csMessage = m_csReceiveBuffer;
		Sleep(GetSimulatorDelay() );
		return TRUE;
	}

	if(GetConnectionType()==SERIALCONNECTION)
	{
		m_csReceiveBuffer=m_pComPort->m_csReceiveBuffer;
		if (m_csReceiveBuffer.IsEmpty())
			return FALSE;
		*csMessage =       m_csReceiveBuffer;


	}
	else
	{
	
		if (m_csReceivedMessage.IsEmpty())
			return FALSE;
		*csMessage = m_csReceivedMessage;

	}

	return TRUE;
	
}


CString CLMorphor3::GetReceiveBuffer()
{
	
	
	return 	m_csReceivedMessage;
}

bool CLMorphor3::GetSerialBuffer(void *Param)
{
	m_csReceiveBuffer=m_pComPort->m_csReceiveBuffer;

	if (m_csReceiveBuffer.Find("OK")!=-1)
	{
		AfxMessageBox("Step Complete");
//		m_pComPort->StopListener(INFINITE); 
	}

	
	
	return true;
}

void CLMorphor3::SetReceivedBuffer(CString csBuffer)
{
	m_csReceiveBuffer =	csBuffer;

}

BOOL CLMorphor3::CloseChannel()
{
BOOL blnState=TRUE;



	if (GetConnectionType()==TCPCONNECTION)
	{	
		if (GetSimulatorMode()) return TRUE;
		m_pSocket->ShutDown(2) ;
		m_pSocket->Close(); 
		delete m_pSocket;
		m_pSocket = NULL;
	}
	else
	{
		ClosePort(); 
		delete m_pComPort;
		m_pComPort=NULL;

	}
	SetConnectionStatus(NOTREADY);
	
	return blnState;
}

int CLMorphor3::GetConnectionStatus()
{
	return m_nConnectionStatus;
}

void CLMorphor3::SetConnectionStatus(int nConnectionStatus)
{
	m_nConnectionStatus=nConnectionStatus;
}



CString CLMorphor3::GetTCPAddress()
{
	return m_csTCPAddress;
}
CString CLMorphor3::GetTCPPort()
{

	return m_csTCPPort;
}


void CLMorphor3::SetTCPAddress(CString csTCPAddress)
{

	m_csTCPAddress=csTCPAddress;
}

void CLMorphor3::SetTCPPort(CString csTCPPort)
{
	m_csTCPPort=csTCPPort;
	
}
BOOL CLMorphor3::YieldToWindows()
{
	MSG msg;

	while (::PeekMessage(&msg,NULL,0,0,PM_NOREMOVE))
	{
		if (!AfxGetThread()->PumpMessage())
			return (TRUE);
	}

	return (TRUE);
}


BOOL CLMorphor3::ChkResponse(CString csResponse,CString csExpectedResponse)
{

	if (csResponse.IsEmpty()||csExpectedResponse.IsEmpty())
		return FALSE;

	if (csResponse.Find(csExpectedResponse)!=-1)
	{
		return TRUE;

	}
	return FALSE;
}



BOOL CLMorphor3::OpenPort()
{
CUtilities *pUtil;
CString csTemp;
SerialPortData PortInfo;
int nParity=0,
	nStopBits;

//	AfxGetApp(); 
//	m_pComPort = new CSerial();
	m_pComPort = new CSerialEx();
	pUtil = new CUtilities();

	pUtil->GetComPortInfo(&PortInfo);
	
	if(m_pComPort->Open(_T(PortInfo.Name),0,0,FALSE))
	{
		if (!m_blnQuietMode)
		{
			pUtil->ErrorMessage(" Error Opening Com Port");
		}
		return FALSE;

	}
	csTemp = PortInfo.Parity;
	csTemp.MakeUpper(); 
	if (PortInfo.Parity.Find("EVEN")!=-1)
	{
		nParity=EVENPARITY;
	}
	else if (PortInfo.Parity.Find("ODD")!=-1)
	{
		nParity=ODDPARITY;
	}
	else if (PortInfo.Parity.Find("MARK")!=-1)
	{
		nParity=MARKPARITY;
	}
	else if (PortInfo.Parity.Find("SPACE")!=-1)
	{
		nParity=SPACEPARITY;
	}
	else
	{
		// default
		nParity=NOPARITY;
	}
	if (PortInfo.StopBits==1)
		nStopBits = ONESTOPBIT;
	else if (PortInfo.StopBits==2)
		nStopBits = TWOSTOPBITS;
	else
	{
		if(!m_blnQuietMode)
			pUtil->ErrorMessage("Unsupported Stop Bit Configuration");
		return FALSE;

	}

	if (GetSimulatorMode()) return TRUE;
	if(m_pComPort->Setup(atoi(PortInfo.BaudRate),
					  PortInfo.Wordlength,
					  nParity,
					  nStopBits))

	{
		pUtil->ErrorMessage(" Error Configuring Com Port");
		m_pComPort->Close(); 
		return FALSE;


	}
					  
	
				  
	
	return TRUE;
}



void CLMorphor3::ClosePort()
{
	if (GetSimulatorMode()) return;

	if (m_pComPort)
	{
//		m_pComPort->StopListener(0); 
		m_pComPort->Close(); 	

	}
}


BOOL CLMorphor3::SerialTransmit(CString csMessage)
{
int nLength = csMessage.GetLength();
	OutputDebugString(csMessage);

	if (GetSimulatorMode()) return TRUE;

	m_pComPort->Purge();
	m_csReceivedMessage.Empty();
	m_csReceiveBuffer.Empty();  

	if(m_pComPort->Write(csMessage.GetBuffer(nLength),nLength,0,0))
		return FALSE;
	return TRUE;
}


BOOL CLMorphor3::Listen()
{
BOOL blnState=TRUE;
char Buffer[500];
DWORD dwBytesRead=0;
CUtilities oUtil;
BOOL	blnDataReceived=FALSE;
long	lLastError;
const CSerial::EEvent eEvent=CSerial::EEventRecv;
CString csTemp;
CPerfTimer oTimer;

	memset(Buffer,'\0',sizeof(Buffer)-1);
	if (GetConnectionType()==TCPCONNECTION)
	{



	}
	else if (GetConnectionType()==SERIALCONNECTION)
	{

		if (GetSimulatorMode()) return TRUE;

		if (m_pComPort==NULL)
		{
	
			return oUtil.ErrorMessage("Com Port Not Open");

		}

        lLastError = m_pComPort->SetupReadTimeouts(CSerial::EReadTimeoutNonblocking);

		m_pComPort->m_csReceiveBuffer.Empty();  		
//		m_pComPort->StartListener(); 

		oTimer.Start(); 
		while (m_pComPort->m_csReceiveBuffer.IsEmpty()) 
		{
			oUtil.YieldToWindows();
			if (oTimer.Elapsed()>15) 
			{
//				m_pComPort->StopListener(0);
				return oUtil.ErrorMessage("Morphor3 Not Responding"); 
			}
		
		};
		SetReceivedBuffer(m_pComPort->m_csReceiveBuffer);
//		m_pComPort->StopListener(0);

	}
	else
	{
		return oUtil.ErrorMessage("Connection Type Not Defined");

	}

	return blnState;


}



BOOL CLMorphor3::Listen(__int64 nTimeOut)
{
BOOL blnState=TRUE;
char Buffer[500];
DWORD dwBytesRead=0;
CUtilities oUtil;
BOOL	blnDataReceived=FALSE;
long	lLastError;
const CSerial::EEvent eEvent=CSerial::EEventRecv;
CString csTemp;
CPerfTimer oTimer;

	memset(Buffer,'\0',sizeof(Buffer)-1);
	if (GetConnectionType()==TCPCONNECTION)
	{



	}
	else if (GetConnectionType()==SERIALCONNECTION)
	{

		if (GetSimulatorMode()) return TRUE;

		if (m_pComPort==NULL)
		{
	
			return oUtil.ErrorMessage("Com Port Not Open");

		}

        lLastError = m_pComPort->SetupReadTimeouts(CSerial::EReadTimeoutNonblocking);

		m_pComPort->m_csReceiveBuffer.Empty();  		
//		m_pComPort->StartListener(); 

		if (nTimeOut!=INFINITE)
		{
			oTimer.Start(); 
			while (m_pComPort->m_csReceiveBuffer.IsEmpty()) 
			{
				oUtil.YieldToWindows();
				if (oTimer.Elapsed()>nTimeOut)
				{
//					m_pComPort->StopListener(0);
					return FALSE ;
				}
			}
			SetReceivedBuffer(m_pComPort->m_csReceiveBuffer);
//			m_pComPort->StopListener(0);

		
		}
	}
	else
	{
		return oUtil.ErrorMessage("Connection Type Not Defined");

	}

	return blnState;


}


BOOL CLMorphor3::ListenWithMaxTimeOut(long lngMaxTimeOut)
{
char strBuffer[1500];
	m_csReceiveBuffer.Empty(); 
	m_csReceivedMessage.Empty();
	DWORD lngBytesRead;
	if (GetSimulatorMode()) return TRUE;

	if (m_pComPort->WaitEvent(NULL,lngMaxTimeOut)==ERROR_SUCCESS)
	{
		do
		{
			
			m_pComPort->Read (strBuffer, 1500, &lngBytesRead, NULL, 5000);
			if (strlen(strBuffer)>0)
				m_csReceivedMessage=m_csReceivedMessage+strBuffer;
			else
			{
				Sleep(200);
				if ((m_pComPort->WaitEvent(NULL,500)==ERROR_SUCCESS))
				{
					m_pComPort->Read (strBuffer, 1500, 0, NULL, 500);
					if (strlen(strBuffer)>0)
						m_csReceivedMessage=m_csReceivedMessage+strBuffer;

				}
			}
		
		} while (strlen(strBuffer)>0);
	}
	m_pComPort->Purge();

	if (m_csReceivedMessage.IsEmpty())
		return FALSE;

	return TRUE;
}


BOOL CLMorphor3::ListenInfinite()
{
char strBuffer[30];
BOOL blnCont=TRUE;

	if (GetSimulatorMode()) return TRUE;
	while (blnCont)
	{
		if (m_pComPort->WaitEvent(NULL,15000)==ERROR_SUCCESS)
		{
			do
			{
				m_pComPort->Read (strBuffer, 30, 0, NULL, 5000);
				if (strlen(strBuffer)>0)
					m_csReceivedMessage=m_csReceivedMessage+strBuffer;
				else
				{
					if ((m_pComPort->WaitEvent(NULL,500)==ERROR_SUCCESS))
					{
						m_pComPort->Read (strBuffer, 30, 0, NULL, 500);
						if (strlen(strBuffer)>0)
							m_csReceivedMessage=m_csReceivedMessage+strBuffer;

					}
				}
			
			} while (strlen(strBuffer)>0);
			blnCont=FALSE;
		}
		YieldToWindows(); 
	}
	m_pComPort->Purge();

	if (m_csReceivedMessage.IsEmpty())
		return FALSE;

	return TRUE;
}


BOOL CLMorphor3::GetSimulatorMode()
{
	return m_blnSimulatorMode;
}

int  CLMorphor3::GetSimulatorDelay()
{
	return m_nSimResponseDelay;
}


void CLMorphor3::SetSimulatorMode()
{
CUtilities *pUtil = new CUtilities();
CString csTemp;

	m_blnSimulatorMode=FALSE;
	m_nSimResponseDelay=2000;
	csTemp=pUtil->GetConfigValue("//Config/SimulatorMode/Activate",FALSE);
	if (!csTemp.IsEmpty())
	{
		csTemp.MakeUpper();
		if ((csTemp.Find("Y")!=-1)||(csTemp.Find("T")!=-1))
			m_blnSimulatorMode=TRUE;

		csTemp.Empty(); 
		csTemp=pUtil->GetConfigValue("//Config/SimulatorMode/ResponseDelay",FALSE);
		if (!csTemp.IsEmpty())
		{
			if(pUtil->IsNumeric(csTemp))
			{
				m_nSimResponseDelay=atoi(csTemp);
				if(m_nSimResponseDelay>30000)
					m_nSimResponseDelay=5000;
				else if (m_nSimResponseDelay<0)
					m_nSimResponseDelay=5000;
			}
		}
	}

	delete pUtil;
}


void CLMorphor3::SetEStop(BOOL blnState)
{
CString csMessage;
	
	if (blnState)
	{
		csMessage=ESTOP_ON;
	}
	else
	{
		csMessage=ESTOP_OFF;
	}

	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(csMessage);
	}
	else 
	{
		SendMsg(csMessage);
	}

	return;
}




void CLMorphor3::StartApplicator(BOOL blnState)
{
CString csMessage;
	
	if (blnState)
	{
		csMessage=STARTAPPLICATORBIT_ON;
	}
	else
	{
		csMessage=STARTAPPLICATORBIT_OFF;
	}

	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(csMessage);
	}
	else 
	{
		SendMsg(csMessage);
	}

	return;
}


void CLMorphor3::StopApplicator(BOOL blnState)
{
CString csMessage;
	
	if (blnState)
	{
		csMessage=STOPAPPLICATORBIT_ON;
	}
	else
	{
		csMessage=STOPAPPLICATORBIT_OFF;

	}

	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(csMessage);
	}
	else 
	{
		SendMsg(csMessage);
	}


	return;
}

void CLMorphor3::ResetApplicator()
{
	StartApplicator(FALSE);
	StopApplicator(TRUE);
	ApplyLabel(FALSE);
	SetEStop(FALSE);
	StopApplicator(FALSE);


	Sleep(500);


}


void CLMorphor3::ApplyLabel(BOOL blnState)
{
CString csMessage;
	
	if (blnState)
	{
		csMessage=APPLYLABELBIT_ON;
	}
	else
	{
		csMessage=APPLYLABELBIT_OFF;

	}
	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(csMessage);
	}
	else 
	{
		SendMsg(csMessage);
	}


	return;
}


BOOL CLMorphor3::IsPartPresent()
{
CString 	csTemp;
BOOL blnCont=TRUE;
	
	if (GetSimulatorMode())
	{
		Sleep(GetSimulatorDelay()); 
		return TRUE;

	}


	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(ISPARTPRESENT);
	}
	else 
	{
		csTemp=ISPARTPRESENT;
		SendMsg(csTemp);
	}

	if(ListenWithMaxTimeOut(15000))
	{
		
		csTemp=GetReceiveBuffer();
		csTemp.MakeUpper(); 
		if (csTemp.Find(csTRUE)!=-1)
		{
			return TRUE;
		}

	}
	return FALSE;


}


BOOL CLMorphor3::IsPartRemoved()
{
CString 	csTemp;
BOOL blnCont=TRUE;
	
	if (GetSimulatorMode())
	{
		Sleep(GetSimulatorDelay()); 
		return TRUE;

	}


	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(ISPARTPRESENT);
	}
	else 
	{
		csTemp=ISPARTPRESENT;
		SendMsg(csTemp);
	}

	if(ListenWithMaxTimeOut(15000))
	{
		
		csTemp=GetReceiveBuffer();
		csTemp.MakeUpper(); 
		if (csTemp.Find("0")!=-1)
		{
			return TRUE;
		}

	}
	return FALSE;


}



BOOL CLMorphor3::IsApplicatorReady()
{
CString 	csTemp;
	
	if (GetSimulatorMode())
	{
		Sleep(GetSimulatorDelay()); 
		return TRUE;

	}
	// Flush the buffer
	while(ListenWithMaxTimeOut(100))
	{
		csTemp=GetReceiveBuffer();
	}
   
	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(ISMORPHORRDY);
	}
	else 
	{
		csTemp=ISMORPHORRDY;
		SendMsg(csTemp);
	}
	if(ListenWithMaxTimeOut(5000))
	{
		
		csTemp=GetReceiveBuffer();
		csTemp.MakeUpper(); 
		if (csTemp.Find(csTRUE)!=-1)
		{
			return TRUE;
		}
		else 
			return FALSE;

	}
		
	return FALSE;



}

BOOL CLMorphor3::IsCycleComplete()
{
CString 	csTemp;
	
	if (GetSimulatorMode())
	{
		Sleep(GetSimulatorDelay()); 
		return TRUE;

	}


	if (GetConnectionType()==SERIALCONNECTION)
	{
		SerialTransmit(CYCLECOMPLETE);
	}
	else 
	{
		csTemp=CYCLECOMPLETE;
		SendMsg(csTemp);
	}

	


	if(ListenWithMaxTimeOut(5000))
	{
		
		csTemp=GetReceiveBuffer();
		csTemp.MakeUpper(); 
		if (csTemp.Find(csTRUE)!=-1)
		{
			return TRUE;
		}
		else
		{
			if (csTemp.Find("A")!=-1)
			{
				SetErrorMessage("Applicator Error");
			}
			return FALSE;
		}

	}
		
	return FALSE;

}

// Automation Rounties

BOOL CLMorphor3::GetQuietMode()
{
	return m_blnQuietMode;

}
void CLMorphor3::SetQuietMode(BOOL blnMode)
{
   m_blnQuietMode=blnMode;

}


CString CLMorphor3::GetErrorMessage()
{

	return m_csErrorMessage;
}
void CLMorphor3::SetErrorMessage(CString csErrorMessage)
{
	m_csErrorMessage=csErrorMessage; 

}



/////////////////////////////////////////////////////////////////////////////
// CMsg construction/destruction


IMPLEMENT_DYNCREATE(CMsg, CObject)


CMsg::CMsg()
{
	Init();
}

CMsg::~CMsg()
{
}

/////////////////////////////////////////////////////////////////////////////
// CMsg Operations

void CMsg::Init()
{
	m_bClose = FALSE;
	m_strText = _T("");
	m_msgList.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////
// CMsg serialization

void CMsg::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << (WORD)m_bClose;
		ar << m_strText;
	}
	else
	{
		WORD wd;
		ar >> wd;
		m_bClose = (BOOL)wd;
		ar >> m_strText;
	}
	m_msgList.Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CMsg diagnostics


//void CMsg::AssertValid() 
//{
//	CObject::AssertValid();
//}
//
//void CMsg::Dump(CDumpContext& dc) const
//{
//	CObject::Dump(dc);
//}



