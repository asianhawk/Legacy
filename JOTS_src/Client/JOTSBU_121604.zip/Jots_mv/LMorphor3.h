#if !defined(AFX_LMORPHOR3_H__5ED02DA0_D49D_42CC_B392_29C8EB705998__INCLUDED_)
#define AFX_LMORPHOR3_H__5ED02DA0_D49D_42CC_B392_29C8EB705998__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LMorphor3.h : header file
//

#include "MorphorProtocol.h"


#include "TCPComm.h"
#include "CommClasses/SerialEx.h"
#include "CommClasses/callback.h"
#include "JoTS.h"


/////////////////////////////////////////////////////////////////////////////
// CLMorphor3 window


class CLMorphor3:public CMorphorProtocol  
{
// Construction
public:

	CLMorphor3();

	CLMorphor3(CEdit *pCallBack);
	
	CEdit *m_p;

	CLMorphor3(JobInfo *pJobInfo);
	 ~CLMorphor3();

	void Init();

	JobInfo	*m_pJobInfo;
	CDialog *m_pDia;

// Attributes
public:

// Operations
public:


// Implementation
public:
	
	BOOL Print(CString csLabelFormat);
	BOOL Scan(CString csOutput);
	void SetModeType(int nModeType);
	int GetModeType();
	int		GetConnectionType();
	void	SetConnectionType(int nConnectionType);
	void SetConnectionStatus(int nConnectionStatus);
	int GetConnectionStatus();

	// Call back

	TCallback<CLMorphor3> i_CallbackOutput;
	bool GetSerialBuffer(void *Param);	
	
	// TCP Code
	
	

	BOOL OpenChannel();
	BOOL CloseChannel();
	CString GetReceiveBuffer();

	BOOL Listen();
	BOOL Listen(__int64 nTimeOut);
	BOOL ListenWithMaxTimeOut(long lngMaxTimeOut);
	BOOL CLMorphor3::ListenInfinite();
	void Transmit(CString csMessage);


	// Serial Methods

	BOOL	OpenPort();
	void	ClosePort();
	BOOL	SerialTransmit(CString csMessage);


private:
	int m_nConnectionStatus;

	CString m_csTransmitMessage;
	int			m_nModeType;
	int			m_nConnectionType;		// how to communicate to the
										// the LM3 i.e. serially or via TCP
	CString m_csReceiveBuffer;
	CString m_csErrorMessage;
	BOOL	m_blnSimulatorMode;
	int		m_nSimResponseDelay;
	
	// TCP Handling 

		//  attributes

	BOOL m_bAutoChat;
	CString m_strHandle;
	CTCPComm* m_pSocket;
	CSocketFile* m_pFile;
	CArchive* m_pArchiveIn;
	CArchive* m_pArchiveOut;
	CString	  m_csTCPAddress;
	CString	  m_csTCPPort;
	CString	  m_csReceivedMessage;

		// Serial Communication members

	CSerialEx		*m_pComPort;
//	CSerial		*m_pComPort;


public:

	BOOL ConnectSocket(LPCTSTR lpszHandle, LPCTSTR lpszAddress, UINT nPort);
	BOOL ConnectLM3();
	BOOL ConnectLM3(CString csTCPAddress, CString csTCPPort );
	void ProcessPendingRead();
	void SendMsg(CString& strText);
	void ReceiveMsg();
	void DisplayMsg(LPCTSTR lpszText);


	CString GetTCPAddress();
	CString GetTCPPort();
	
	
	void SetTCPAddress(CString csTCPAddress);
	void SetTCPPort(CString csTCPPort);

	BOOL GetReceivedMessage(CString *csMessage);
	void SetReceivedBuffer(CString csBuffer);		
	BOOL YieldToWindows();
	BOOL ChkResponse(CString csResponse,CString csExpectedResponse);
	BOOL IsValidResponse(CString csExpectedResponse);
	BOOL IsMorphorReady();
	// simulator member functions

	BOOL GetSimulatorMode();
	int	 GetSimulatorDelay();
	void SetSimulatorMode();

	// End of TCP Code

	// DIO Outputs
	void StartApplicator(BOOL blnState);
	void StopApplicator(BOOL blnState);
	void ApplyLabel(BOOL blnState);
	void SetEStop(BOOL blnState);

	void ResetApplicator();



	//.DIO Inputs
	BOOL IsPartPresent();
	BOOL IsPartRemoved();

	BOOL IsApplicatorReady();
	BOOL IsCycleComplete();

	//Automation Engine
	BOOL m_blnQuietMode;
	BOOL GetQuietMode();
	void SetQuietMode(BOOL blnMode);

	CString GetErrorMessage();
	void	SetErrorMessage(CString csErrorMessage);
	void WaitDlg(BOOL blnStart);


};


class CMsg : public CObject
{
protected:
	DECLARE_DYNCREATE(CMsg)
public:
	CMsg();

// Attributes
public:
	CString m_strText;
	BOOL m_bClose;
	CStringList m_msgList;

// Operations
public:
	void Init();

// Implementation
public:
	virtual ~CMsg();
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#ifdef _DEBUG
	void AssertValid();
	void Dump(CDumpContext& dc);
#endif
};



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LMORPHOR3_H__5ED02DA0_D49D_42CC_B392_29C8EB705998__INCLUDED_)
