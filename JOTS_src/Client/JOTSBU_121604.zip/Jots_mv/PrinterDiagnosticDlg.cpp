// PrinterDiagnosticDlg.cpp : implementation file
//

#include "stdafx.h"

#include "PrinterDiagnosticDlg.h"
#include "Utilities.h"
#include "WaitingDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	  PARAMETERNAME			0
#define	  BASELINEVALUE			1	
#define   CURRENTVALUE			2

/////////////////////////////////////////////////////////////////////////////
// CPrinterDiagnosticDlg dialog


CPrinterDiagnosticDlg::CPrinterDiagnosticDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPrinterDiagnosticDlg::IDD, pParent)
{
	EnableAutomation();
	m_blnMorphorReady=FALSE;

	//{{AFX_DATA_INIT(CPrinterDiagnosticDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPrinterDiagnosticDlg::~CPrinterDiagnosticDlg()
{
	delete m_pMorphor;

}

void CPrinterDiagnosticDlg::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CPrinterDiagnosticDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrinterDiagnosticDlg)
	DDX_Control(pDX, IDC_BTN_SAVE_FPS, m_btnSave);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDC_BTN_GETCURRENT_FPS, m_btnDisplayCurrent);
	DDX_Control(pDX, IDC_LBL_TITLE, m_lblTitle);
	DDX_Control(pDX, IDC_GRID, m_Grid);             // associate the grid window with a C++ object
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPrinterDiagnosticDlg, CDialog)
	//{{AFX_MSG_MAP(CPrinterDiagnosticDlg)
		ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
		ON_NOTIFY(NM_RCLICK,IDC_GRID, OnRMClick)
	ON_BN_CLICKED(IDC_BTN_GETCURRENT_FPS, OnBtnGetcurrentFps)
	ON_BN_CLICKED(IDC_BTN_SAVE_FPS, OnBtnSaveFps)
	ON_COMMAND(ID_PRINTERSETTINGS_TRANSMIT, OnPrintersettingsTransmit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CPrinterDiagnosticDlg, CDialog)
	//{{AFX_DISPATCH_MAP(CPrinterDiagnosticDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IPrinterDiagnosticDlg to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {906EBBDB-0A1C-4219-9717-98AA92A220AE}
static const IID IID_IPrinterDiagnosticDlg =
{ 0x906ebbdb, 0xa1c, 0x4219, { 0x97, 0x17, 0x98, 0xaa, 0x92, 0xa2, 0x20, 0xae } };

BEGIN_INTERFACE_MAP(CPrinterDiagnosticDlg, CDialog)
	INTERFACE_PART(CPrinterDiagnosticDlg, IID_IPrinterDiagnosticDlg, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrinterDiagnosticDlg message handlers

BOOL CPrinterDiagnosticDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	InitControls();	
	InitGrid();

	m_pMorphor = new CLMorphor3();
	InitLabelMorphor();




	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPrinterDiagnosticDlg::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
CString csData;
  
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
    

}

void CPrinterDiagnosticDlg::InitControls()
{

short	shBtnColor = 30;	
	CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
		

	// format controls
	GetDlgItem(IDC_LBL_TITLE)->SetFont(&font);

	m_btnSave.EnableWindow(FALSE);

		

	// format btn controls
	
	m_btnDisplayCurrent.SetFont(&font);
	m_btnDisplayCurrent.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnDisplayCurrent.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnDisplayCurrent.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnDisplayCurrent.SetIcon(IDI_OK);
//	m_btnDisplayCurrent.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnSave.SetFont(&font);
	m_btnSave.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnSave.SetIcon(IDI_OK);
//	m_btnSave.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnOK.SetFont(&font);
	m_btnOK.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOK.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnOK.SetIcon(IDI_EXIT, (int)BTNST_AUTO_GRAY);
	m_btnOK.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btnOK.SetAlign(CButtonST::ST_ALIGN_HORIZ);



}

void CPrinterDiagnosticDlg::OnRMClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
 
CRect rect;

	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;


	if (pItem->iRow>m_Grid.GetFixedRowCount()-1)
	{
		m_nCurrentRow=pItem->iRow-m_Grid.GetFixedRowCount();
		m_nCurrentCol=pItem->iColumn;
		
		if (m_oPrinterSettings[m_nCurrentRow].ZPLCmd.Find("^M")!=-1) return;
		
		m_Grid.GetCellRect(pItem->iRow, pItem->iColumn,&rect);
		ClientToScreen(&rect);
      
		CMenu menuTreePopupMaster;
		menuTreePopupMaster.LoadMenu(IDR_POPUP_PRINTER_SETTINGS);

		//pDefCell->GetEditWnd()
		CMenu* pMenuTreePopup = menuTreePopupMaster.GetSubMenu(0);
		pMenuTreePopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_CENTERALIGN, rect.right   ,rect.bottom*1.2  , this , NULL);
	}


}


void CPrinterDiagnosticDlg::InitGrid()
{

CUtilities *pUtil;

	m_Grid.SetFixedRowCount(1);
	m_Grid.SetRowCount(MAXPRINTERPARAMETERS + m_Grid.GetFixedRowCount());		//Data Rows

	m_Grid.SetColumnCount(3);
	m_Grid.SetFixedColumnCount(1);
	m_Grid.SetSingleColSelection(FALSE);
	m_Grid.SetSingleRowSelection(FALSE); 



    m_Grid.SetItemText(0,PARAMETERNAME," Setting ");
    m_Grid.SetItemText(0,BASELINEVALUE,"Baseline");
    m_Grid.SetItemText(0,CURRENTVALUE,"Current");



	
	pUtil = new CUtilities();

	
	
	for (int nCount =1;nCount<m_Grid.GetRowCount() ; nCount++)
	{
		for (int nColumn=1;nColumn<m_Grid.GetColumnCount();nColumn++)
		{
			m_Grid.SetItemFormat(nCount,nColumn,DT_LEFT|DT_VCENTER);
		
		}
	}

	m_csBaselinePrinterSettings=pUtil->GetConfigValue("BaselinePrinterSettingsPath") +
							    pUtil->GetConfigValue("BaselinePrinterSettingsFileName");

	if (m_csBaselinePrinterSettings.IsEmpty())
		m_csBaselinePrinterSettings="C:\\ZebraBselineSettings.dat";


	m_csLastPrinterSettings = pUtil->GetConfigValue("LastPrinterSettingsPath") + 
						  pUtil->GetConfigValue("LastPrinterSettingsFileName");

	if (m_csLastPrinterSettings.IsEmpty())
		m_csLastPrinterSettings="C:\\ZebraSettings.dat";



	m_pPrinterSettings=pUtil->GetZebraSettings();
	for(nCount=0;nCount<MAXPRINTERPARAMETERS;nCount++)
	{
		m_oPrinterSettings[nCount].Name = m_pPrinterSettings[nCount].Name;
		m_oPrinterSettings[nCount].Description  = m_pPrinterSettings[nCount].Description;
		m_oPrinterSettings[nCount].ZPLCmd   = m_pPrinterSettings[nCount].ZPLCmd;
		m_oPrinterSettings[nCount].NumberOfArgs    = m_pPrinterSettings[nCount].NumberOfArgs;
		m_oPrinterSettings[nCount].Value     = m_pPrinterSettings[nCount].Value;
		m_oPrinterSettings[nCount].Value.TrimLeft();
		m_oPrinterSettings[nCount].Value.TrimRight();	


	}

	pUtil->ParseZebraPrinterSettings(m_csBaselinePrinterSettings,m_oPrinterSettings);


	for(int i=0;i<MAXPRINTERPARAMETERS;i++)
	{
		if (m_pPrinterSettings[i].Name.IsEmpty()) break;
		m_Grid.SetItemText(i+ m_Grid.GetFixedRowCount(),PARAMETERNAME,m_oPrinterSettings[i].Name);
		m_Grid.SetItemText(i+ m_Grid.GetFixedRowCount(),BASELINEVALUE,m_oPrinterSettings[i].Value);


	}

	m_Grid.Refresh(); 
	m_Grid.ExpandColumnsToFit(TRUE); 
	
	
	
	delete pUtil;

	

	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	m_Grid.SetFont(&font);
	m_Grid.SetModified(FALSE); 

	
}
void CPrinterDiagnosticDlg::InitLabelMorphor()
{

	m_pMorphor->SetConnectionType(SERIALCONNECTION);
	m_pMorphor->SetModeType(PASSTHRU);



}

BOOL CPrinterDiagnosticDlg::IsLabelMorphorReady()
{
	return m_blnMorphorReady;

}

BOOL CPrinterDiagnosticDlg::OpenLabelMorphor()
{
	if (!m_pMorphor->OpenChannel())
	{
		m_blnMorphorReady=FALSE;

		return FALSE;
	}
	m_pMorphor->Print(LM3PASSTHRU);
	return TRUE;
}
BOOL CPrinterDiagnosticDlg::CloseLabelMorphor()
{
	m_pMorphor->Print(ABORTPASSTHRU);
	if(m_pMorphor->ListenWithMaxTimeOut(1000))
	{
		if (!m_pMorphor->CloseChannel())
		m_blnMorphorReady=TRUE;
		return true;
	}

	m_blnMorphorReady=FALSE;
	return FALSE;

}

CString CPrinterDiagnosticDlg::GetLastErrorMsg()
{
	return m_csLastError;

}

void CPrinterDiagnosticDlg::SetLastErrorMsg(CString csErrorMessage)
{
	m_csLastError=csErrorMessage;

}
	

void CPrinterDiagnosticDlg::OnBtnGetcurrentFps() 
{
CUtilities *pUtil = new CUtilities();

	CWaitingDlg *pDlg = new CWaitingDlg();
	pDlg->SetRanges(0,5);
	pDlg->m_csTitle = "Loading Printer Settings";
	if(pDlg->Create(IDD_WAITING_DLG,NULL)==FALSE)
	{
		delete pDlg;
		delete pUtil;
		return;
	}
	pDlg->ShowWindow(SW_SHOW);
	if (!ReadFps()) 
	{
		delete pDlg;
		delete pUtil;
		
		return;
	}

	pUtil->ParseZebraPrinterSettings(m_csLastPrinterSettings, m_oPrinterSettings);

	for(int i=0;i<MAXPRINTERPARAMETERS;i++)
	{
		if (m_oPrinterSettings[i].Name.IsEmpty()) break;
		m_Grid.SetItemText(i+ m_Grid.GetFixedRowCount(),PARAMETERNAME,m_oPrinterSettings[i].Name);
		m_Grid.SetItemText(i+ m_Grid.GetFixedRowCount(),CURRENTVALUE,m_oPrinterSettings[i].Value);


	}
	m_btnSave.EnableWindow(TRUE);
	m_Grid.Refresh(); 
	pDlg->ShowWindow(SW_HIDE);

	delete pDlg;
	delete pUtil;





}

BOOL CPrinterDiagnosticDlg::ReadFps() 
{


	if (!IsLabelMorphorReady()) // is it still open
	{
		if(!OpenLabelMorphor()) return FALSE;
	}
	

	m_pMorphor->Print("^XA^HH^XZ\n"); 
	Sleep(2000);
	if(!WaitForResponse(15)) 
	{
		CloseLabelMorphor();
		return FALSE;
	}

	CloseLabelMorphor();
	return TRUE;


}
BOOL CPrinterDiagnosticDlg::WaitForResponse(int nTimeOut)
{
BOOL blnState=FALSE;
CString csTemp,
		csReceivedData;
CStdioFile ff;

	if(m_pMorphor->ListenWithMaxTimeOut(nTimeOut*1000))
	{
		csTemp=m_pMorphor->GetReceiveBuffer();
		csReceivedData+=csTemp;


		if( !ff.Open( m_csLastPrinterSettings, CFile::modeCreate|CFile::modeWrite | CFile::typeText ) )
		{
			   #ifdef _DEBUG
				  afxDump << "Unable to open file" << "\n";
			   #endif
			return FALSE;
		}
		ff.Write(csReceivedData,csReceivedData.GetLength()); 
		ff.Close(); 
		return TRUE;
	}
	return blnState;
}


void CPrinterDiagnosticDlg::OnBtnSaveFps() 
{

	DeleteFile(m_csBaselinePrinterSettings);
	CFile::Rename(m_csLastPrinterSettings,m_csBaselinePrinterSettings); 
	
}

void CPrinterDiagnosticDlg::OnPrintersettingsTransmit() 
{
CString csZPLCmd,
		csZPLArg,
		csTransMit;


	csZPLCmd=m_oPrinterSettings[m_nCurrentRow].ZPLCmd;
	
	csZPLArg = m_Grid.GetItemText(m_nCurrentRow+m_Grid.GetFixedRowCount(),m_nCurrentCol);
	
	csZPLArg.TrimLeft();
	csZPLArg.TrimRight();
	csTransMit=csZPLCmd+csZPLArg+"\n";

	CWaitingDlg *pDlg = new CWaitingDlg();
	pDlg->SetRanges(0,3);
	pDlg->m_csTitle = CString("Transmitting")+csTransMit ;
	if(pDlg->Create(IDD_WAITING_DLG,NULL)==FALSE)
	{
		delete pDlg;
		return;
	}
	pDlg->ShowWindow(SW_SHOW);
	if (!IsLabelMorphorReady()) // is it still open
	{
		if(!OpenLabelMorphor()) return;
	}

	m_pMorphor->Print(csTransMit+"\n"); 
	if(!WaitForResponse(3)) 
	{
		CloseLabelMorphor();
		pDlg->ShowWindow(SW_HIDE);

		delete pDlg;
		return ;
	}

	CloseLabelMorphor();
	pDlg->ShowWindow(SW_HIDE);
	delete pDlg;
}
