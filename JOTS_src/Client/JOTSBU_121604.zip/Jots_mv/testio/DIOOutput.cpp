#include "stdafx.h"
static int nOutput;

void SetOutputOn(unsigned int nValue)
{
	nOutput=nOutput+(1<<nValue);

}

void SetOutputOff(unsigned int nValue)
{
unsigned int nMask=0;
int nCount;

	for (nCount=0;nCount<8;nCount++)
	{
		if (nCount!=(int)nValue)
			nMask=nMask+(1<<nCount);
	}
	nOutput=nOutput&nMask;

}

unsigned int GetOutputValue()
{

	return nOutput;

}

