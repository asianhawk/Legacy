// TemplateEditorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
// TemplateEditorDlg.h is in jots.h

#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTemplateEditorDlg dialog


CTemplateEditorDlg::CTemplateEditorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTemplateEditorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTemplateEditorDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_csTemplatePath=_T("");
	m_csCurrentTemplateFullPath=_T("");
	m_blnFileIsOpen=FALSE;
}


void CTemplateEditorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTemplateEditorDlg)
	DDX_Control(pDX, IDOK, m_btnExit);
	DDX_Control(pDX, IDB_BTN_DELETE, m_btnDelete);
	DDX_Control(pDX, IDB_BTN_SAVE_AS, m_btnSaveAs);
	DDX_Control(pDX, IDB_BTN_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_CMB_TEMPLATES, m_cmbTemplates);
	DDX_Control(pDX, IDB_OPEN_TEMPLATE, m_btnOpenTemplate);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTemplateEditorDlg, CDialog)
	//{{AFX_MSG_MAP(CTemplateEditorDlg)
	ON_BN_CLICKED(IDB_OPEN_TEMPLATE, OnOpenTemplate)
	ON_BN_CLICKED(IDB_BTN_SAVE, OnBtnSave)
	ON_BN_CLICKED(IDB_BTN_SAVE_AS, OnBtnSaveAs)
	ON_BN_CLICKED(IDB_BTN_DELETE, OnBtnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTemplateEditorDlg message handlers

BOOL CTemplateEditorDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetTemplates();
	InitControls();

	
	// Create the CrystalEdit control.
	m_ScriptEditor.CreateFromControl( IDC_EDIT_SCRIPT, this );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CTemplateEditorDlg::GetTemplates()
{
CUtilities *pUtil = new CUtilities();
CStringArray csaTemplates;

	pUtil->GetTemplates(&csaTemplates);
	m_csTemplatePath=pUtil->GetConfigValue(ZEBRATEMPLATES);
	
	delete pUtil;
	for (int nTemplate=0;nTemplate<csaTemplates.GetSize();nTemplate++)
	{
		m_cmbTemplates.AddString(csaTemplates.GetAt(nTemplate));   

	}
	m_cmbTemplates.SetCurSel(0); 
}

void CTemplateEditorDlg::OnOK() 
{
	m_ScriptBuffer.FreeAll();   
	CDialog::OnOK();
}

void CTemplateEditorDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	m_ScriptBuffer.FreeAll();   	
	CDialog::OnCancel();
}

void CTemplateEditorDlg::OnOpenTemplate() 
{
CString csTemp,
		csTemplate,
		csErrorMessage;
CFileFind ff;

    m_cmbTemplates.GetLBText(m_cmbTemplates.GetCurSel(),csTemplate);
	
	if (!csTemplate.IsEmpty())
	{
		csTemp=m_csTemplatePath+csTemplate;

		if(!ff.FindFile(csTemp))
		{
			CUtilities *pUtil= new CUtilities();
			csErrorMessage.Format("Template [%s] Not Found At [%s]",csTemplate,m_csTemplatePath); 
			pUtil->ErrorMessage(csErrorMessage); 
			delete pUtil;
			return;

		}

		if (m_blnFileIsOpen) PurgeBuffer();

		m_ScriptBuffer.LoadFromFile(csTemp); 
		m_csCurrentTemplateFullPath=csTemp;
		// Attach it to the edit control.
		m_ScriptEditor.AttachToBuffer( &m_ScriptBuffer );
		m_ScriptEditor.RedrawWindow(); 

		m_btnSave.EnableWindow(TRUE);  
		m_btnSaveAs.EnableWindow(TRUE); 
		m_btnDelete.EnableWindow(TRUE);
		m_btnOpenTemplate.EnableWindow(TRUE);
		m_blnFileIsOpen=TRUE;

	}
	
}
void CTemplateEditorDlg::InitControls()
{
short	shBtnColor = 30;
CAutoFont font;
	font.SetFaceName(_T("Arial"));
	font.SetHeight(14);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_NORMAL); 
	
	GetDlgItem(IDC_LBL_SELECT_TEMPLATES)->SetFont(&font);
	GetDlgItem(IDC_CMB_TEMPLATES)->SetFont(&font);
	GetDlgItem(IDB_OPEN_TEMPLATE)->SetFont(&font);



	GetDlgItem(IDOK)->SetFont(&font);

	m_btnSave.EnableWindow(FALSE);  
	m_btnSaveAs.EnableWindow(FALSE); 
	m_btnDelete.EnableWindow(FALSE);
	


	m_btnSave.SetFont(&font);
	m_btnSave.SetShade(CShadeButtonST::SHS_SOFTBUMP);

	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnSave.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnSave.SetIcon(IDI_OK);
//	m_btnSave.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnSaveAs.SetFont(&font);
	m_btnSaveAs.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnSaveAs.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnSaveAs.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnSaveAs.SetIcon(IDI_CANCEL1);
//	m_btnSaveAs.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnDelete.SetFont(&font);
	m_btnDelete.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnDelete.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnDelete.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnDelete.SetIcon(IDI_CANCEL1);
//	m_btnDelete.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnOpenTemplate.SetFont(&font);
	m_btnOpenTemplate.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnOpenTemplate.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnOpenTemplate.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
//	m_btnOpenTemplate.SetIcon(IDI_CANCEL1);
//	m_btnOpenTemplate.SetAlign(CButtonST::ST_ALIGN_HORIZ);


	m_btnExit.SetFont(&font);
	m_btnExit.SetShade(CShadeButtonST::SHS_SOFTBUMP);
	m_btnExit.SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(0, 0, 255));
	m_btnExit.SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(0, 0, 0));
	m_btnExit.SetIcon(IDI_EXIT, (int)BTNST_AUTO_GRAY);
	m_btnExit.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btnExit.SetAlign(CButtonST::ST_ALIGN_HORIZ);


}

void CTemplateEditorDlg::OnBtnSave() 
{
	m_ScriptBuffer.SaveToFile(m_csCurrentTemplateFullPath); 	
}

void CTemplateEditorDlg::OnBtnSaveAs() 
{
CUtilities *pUtil=new CUtilities();
CString csTemplateDir;

	pUtil->GetZebraPrinterTemplateDirectory(&csTemplateDir);
	delete pUtil;

	CString csOutput;

	CString filt="Printer Template(*.zpl)|*.zpl||";
    
	CFileDialog fileDlg(FALSE,"*.zpl","*.zpl",NULL,filt,this);
	
	fileDlg.m_ofn.lpstrTitle="Save Printer Template";
	fileDlg.m_ofn.lpstrInitialDir =csTemplateDir;
//	fileDlg.m_ofn.Flags = fileDlg.m_ofn.Flags|OFN_NOCHANGEDIR;
	if (fileDlg.DoModal()==IDOK) 
	{
		CWaitCursor bob;
		
		CString fileName=fileDlg.GetPathName();
		
		m_ScriptBuffer.SaveToFile(fileName); 

	}
	
}

void CTemplateEditorDlg::OnBtnDelete() 
{
CString csErrorMessage;
	if (!m_csCurrentTemplateFullPath.IsEmpty())
	{
		if(!DeleteFile(m_csCurrentTemplateFullPath))
		{
			CUtilities *pUtil= new CUtilities();
			csErrorMessage.Format("Error Deleting Template [%s]",m_csTemplatePath); 
			pUtil->ErrorMessage(csErrorMessage); 
			delete pUtil;
			return;
		
		}
		m_cmbTemplates.ResetContent();
		GetTemplates();

int nCharCount=0,
		nLineCount=0;
		nLineCount = m_ScriptBuffer.GetLineCount();
		
		nCharCount=m_ScriptBuffer.GetLineLength(nLineCount-1) ;

		m_ScriptBuffer.DeleteText(&m_ScriptEditor,0,0,nLineCount-1,nCharCount);

		 
		m_ScriptEditor.DetachFromBuffer(); 
		m_ScriptBuffer.FreeAll();

		m_btnSave.EnableWindow(FALSE);  
		m_btnSaveAs.EnableWindow(FALSE); 
		m_btnDelete.EnableWindow(FALSE);
		m_btnOpenTemplate.EnableWindow(TRUE);
		m_blnFileIsOpen=FALSE;

	
	}
	
}
void CTemplateEditorDlg::PurgeBuffer()
{
int nCharCount=0,
		nLineCount=0;
		nLineCount = m_ScriptBuffer.GetLineCount();
		if (nLineCount>0)
		{
			nCharCount=m_ScriptBuffer.GetLineLength(nLineCount-1) ;
   
			if (nCharCount>0)
			{
				m_ScriptBuffer.DeleteText(&m_ScriptEditor,0,0,nLineCount-1,nCharCount);
			}

			 
			m_ScriptEditor.DetachFromBuffer(); 
			m_ScriptBuffer.FreeAll();

		}


}
