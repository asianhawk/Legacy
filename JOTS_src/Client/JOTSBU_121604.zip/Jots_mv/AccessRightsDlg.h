#if !defined(AFX_ACCESSRIGHTSDLG_H__507CF590_249E_45D2_B86D_F8539C2853E6__INCLUDED_)
#define AFX_ACCESSRIGHTSDLG_H__507CF590_249E_45D2_B86D_F8539C2853E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AccessRightsDlg.h : header file
//

#include "GridCtrl_src/GridCtrl.h"
#include "GridCtrl_src/GridCellCheck.h"


/////////////////////////////////////////////////////////////////////////////
// CAccessRightsDlg dialog

class CAccessRightsDlg : public CDialog
{
// Construction
public:
	CAccessRightsDlg(CWnd* pParent = NULL);   // standard constructor
	CGridCtrl m_Grid;
	void InitGrid();
	~CAccessRightsDlg();


// Dialog Data
	//{{AFX_DATA(CAccessRightsDlg)
	enum { IDD = IDD_ACCESS_RIGHTS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAccessRightsDlg)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAccessRightsDlg)
    afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CAccessRightsDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACCESSRIGHTSDLG_H__507CF590_249E_45D2_B86D_F8539C2853E6__INCLUDED_)
