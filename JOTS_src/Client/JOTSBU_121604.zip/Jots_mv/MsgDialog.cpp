// MsgDialog.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "MsgDialog.h"
#include "AutoFont.h"	


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsgDialog dialog


CMsgDialog::CMsgDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMsgDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsgDialog)
	m_csMessage = _T("");
	//}}AFX_DATA_INIT
	m_nMsgType=1;
	m_blnContinue=TRUE;
	m_csTitle.Empty(); 
}


void CMsgDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsgDialog)
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Text(pDX, IDC_LBL_TEXT, m_csMessage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsgDialog, CDialog)
	//{{AFX_MSG_MAP(CMsgDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsgDialog message handlers

BOOL CMsgDialog::OnInitDialog() 
{
CDialog::OnInitDialog();
CAutoFont font;
font.SetFaceName(_T("Arial"));
font.SetHeight(14);
font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
font.SetWeight(FW_NORMAL); 
	
CString csMessage;

	GetDlgItem(IDC_LBL_TEXT)->SetFont(&font);
	GetDlgItem(IDOK)->SetFont(&font);
	GetDlgItem(IDCANCEL)->SetFont(&font);
	if(m_nMsgType ==0)
	{
		if (m_csTitle.IsEmpty()) 
			csMessage = "JoTS: Error[1]";
		else
			csMessage= "JoTS: Error[1]" + m_csTitle;
	}
	else if(m_nMsgType == 1)
	{
		if (m_csTitle.IsEmpty()) 
			csMessage = "JoTS: Error[1]";
		else
			csMessage= "JoTS: Error[1]" + m_csTitle;
	}
	else if(m_nMsgType == 2)
	{
		if (m_csTitle.IsEmpty()) 
			csMessage = "JoTS: Error[2]";
		else
			csMessage= "JoTS: Error[2]" + m_csTitle;
	}
	else if(m_nMsgType == 3)
	{
		if (m_csTitle.IsEmpty()) 
			csMessage = "JoTS: Error[3]";
		else
			csMessage= "JoTS: Error[3]" + m_csTitle;
	}
	else
		csMessage=m_csTitle;

	m_csCaption=csMessage;
	SetWindowText(m_csCaption);
	SetCmdButtons();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMsgDialog::SetCmdButtons()
{
//CRect rect,rect2,rect3;
//int nXPos;

//	GetClientRect(&rect);
//	GetDlgItem(IDC_BMP_LOGO)->GetClientRect(&rect3);
//	nXPos=rect.right - rect3.right;
//   	m_btnOK.GetClientRect(&rect2);
//	nXPos=nXPos/2 - rect.left/2;
	
//	rect2.left = nXPos;
	switch (m_nMsgType)
	{

		case 1:		// Normal
			
			m_btnCancel.ShowWindow(FALSE);
//			m_btnOK.SetWindowPos(this,0,rect.top  ,0 ,rect2.bottom  ,SWP_SHOWWINDOW); 
//			m_btnOK.MoveWindow(&rect2,TRUE); 
		
			break;

		case YES_OR_NO:
			m_btnCancel.ShowWindow(TRUE);
			m_btnOK.SetWindowText("Yes");
			m_btnCancel.SetWindowText("No");
			break;
			
		default:
			m_btnCancel.ShowWindow(FALSE);
			m_btnOK.ShowWindow(TRUE); 
			break;


	}


}

void CMsgDialog::OnOK() 
{
	SetContinue(TRUE);		
	CDialog::OnOK();
}

BOOL CMsgDialog::GetContinue()
{
	return m_blnContinue;

}

void CMsgDialog::SetContinue(BOOL blnContinue)
{
	m_blnContinue=blnContinue; 	

}

void CMsgDialog::OnCancel() 
{
	SetContinue(FALSE);	
	CDialog::OnCancel();
}


