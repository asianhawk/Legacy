// seqadd.h - file to do base addition on user defined number systems
// $History: SeqAdd.h $
//
//*****************  Version 6  *****************
//User: Neil.vaneps  Date: 10/11/01   Time: 12:38p
//Updated in $/C++ Code/Label System/Numgen
//Exposed another function for use by DLL clients.
//
//*****************  Version 5  *****************
//User: Neil.vaneps  Date: 10/11/01   Time: 12:29p
//Updated in $/C++ Code/Label System/Numgen
//Added missing function from order's copy of seqmath.
//
//*****************  Version 4  *****************
//User: Neil.vaneps  Date: 10/11/01   Time: 12:19p
//Updated in $/C++ Code/Label System/Numgen
//Moved fstream.h include to header file.
//
//*****************  Version 3  *****************
//User: Neil.vaneps  Date: 10/11/01   Time: 11:36a
//Updated in $/C++ Code/Label System/Numgen
//Exported functions in SeqAdd.cpp and SeqMath.cpp to help eliminate
//duplicity.
//
//*****************  Version 2  *****************
//User: Neil.vaneps  Date: 10/09/01   Time: 11:06a
//Updated in $/C++ Code/Label System/Numgen
//Fixed namespace conflict.
//
//*****************  Version 1  *****************
//User: Neil.vaneps  Date: 10/04/01   Time: 6:34p
//Created in $/C++ Code/Label System/Numgen
//

#include <fstream.h>
#include "resource.h"

#define AFX_MFC_EXT_TYPE __declspec( dllimport )

// array of structures defining each position in a number string                    
struct Numbers                                     
{   long int position;   // position of the digit from left to right in the number string starting at 1  
    long int count;      // number of positions in subset       
    CString min;         // minimum value of subset             
    CString max;         // maximum value of subset             
    CString base;        // a string that defines the base  
    long int order;      // order to increment this number from right to left starting at 1
};

CString AFX_MFC_EXT_TYPE LongToCString(long number,int stringlen);

// Function to get the special numbering type information from BaseTypes
int AFX_MFC_EXT_TYPE GetTypeInfoOrder(long Type, Numbers digits[],int & NumDigits, CString & MinMsg, CString & MaxMsg);

//  Function to convert a base 10 integer to a CString.            
CString AFX_MFC_EXT_TYPE IntToCString(int number);

// Function to convert a CString to a base 10 integer
int AFX_MFC_EXT_TYPE CStringToInt(CString charstr);

// Function to convert a CString to a base 10 long integer
long AFX_MFC_EXT_TYPE CStringToLong(CString charstr);

// Function to convert a CString to a character string
void AFX_MFC_EXT_TYPE CStringToChar(CString & s, char ch[]);

// Function to convert a base 10 unsigned long to a CString
CString AFX_MFC_EXT_TYPE UnsignLongToCString(unsigned long number,int stringlen);

// Function to get the special numbering type information from BaseTypes
int AFX_MFC_EXT_TYPE GetTypeInfoDLL(long Type, Numbers digits[],int & NumDigits, CString & MinMsg, CString & MaxMsg,
				CString & BaseTypePath);

// Function to get the table information and the minimum and maximum message for a standard base
CString AFX_MFC_EXT_TYPE GetBaseInfo(long base, CString & table, int MsgLen, CString & Min, CString & Max,
					CString & Drop);

// Function to convert a user defined standard base number to base 10 
CString AFX_MFC_EXT_TYPE B10ToBx(long bbase,CString & Number, CString & ttable, int MsgLen);

// Function to convert a base 10 number to a multi base numtype
CString AFX_MFC_EXT_TYPE B10ToMulti(CString & number,long Type,Numbers digits[],int NumDigits);

// Function to build the base string for this number base
CString AFX_MFC_EXT_TYPE GetBaseStr(int Base, CString & Drop, CString & Table);

// Function to convert a user defined CString base number  to a CString base 10 number
CString AFX_MFC_EXT_TYPE BxToB10(CString & charstr, int length, CString base);

// Function to convert a user defined multiple base number to a CString base 10
CString AFX_MFC_EXT_TYPE MultiToB10(CString & charstr, int length, Numbers digits[]);

// Calculate the maximum base 10 value for this subset if it isn't already specified.
int AFX_MFC_EXT_TYPE SetMaxValues(Numbers digits[], int & NumDigits);

// Calculate the minimum and maximum label messages
int AFX_MFC_EXT_TYPE GetMinMaxMsg(Numbers digits[], int NumDigits, CString & MinMsg, CString & MaxMsg);

// Change the number around so that the characters are in the correct positions for incrementing
// from right to left
CString AFX_MFC_EXT_TYPE GetInternalMsg(CString & Num, Numbers digits[], int NumDigits);

// Change the internal message back to the format of the input message 
CString AFX_MFC_EXT_TYPE etOutMsg(CString & IMsg, Numbers digits[], int NumDigits); 

// Validate the user input for the start label message for a special type              
CString AFX_MFC_EXT_TYPE ValidateInput(CString & Num, Numbers digits[], int & NumDigits);

// Validate the user input for the start label message for a standard base
CString AFX_MFC_EXT_TYPE ValidateStand(CString & Num, CString & Base, int & MsgLen);

// Validate the user input for the start label message for a standard base
CString AFX_MFC_EXT_TYPE ValidateType1(CString & Num, CString & Base, int & MsgLen);

// Generate a file with sequence numbers in it from a standard base string
int AFX_MFC_EXT_TYPE SeqBaseAdd(CString & Num,CString BaseStr,int Increment,unsigned long Quantity,
			   ofstream & out, ofstream & log, CString & Call);

// Adds a base 10 CString to another standard base CString number 
int AFX_MFC_EXT_TYPE CSBaseAdd(CString & Num, CString BaseStr, CString Increment);

// Subtract two CString numbers in a user defined base
CString AFX_MFC_EXT_TYPE CSBaseSub(CString & N1, CString & N2, CString & BaseStr);
                                                                             
// Adds a long integer to a number string using a structure defining each number                                                                              
int AFX_MFC_EXT_TYPE CSMultiBaseAdd(CString & Num,Numbers Digits[],CString & Increment);

// Generate a file with sequence numbers in it from a multi base numbering type
int AFX_MFC_EXT_TYPE SeqMultiBase(CString & Num, Numbers digits[], CString & Increment,
				 unsigned long Quantity, ofstream & out, ofstream & log);
                                                                                 
// Adjusts the number string if the maximum value has been exceeded for one of its subsets
// Return the current carry value                                                           
CString AFX_MFC_EXT_TYPE CSProcessMinMax(CString & Num,int CurIndx,Numbers Digits[],CString & AddIn);

// Add a type 1 number with a quantity and return the answer in a type 1 number
CString AFX_MFC_EXT_TYPE CSType1Add(CString & BaseStr, CString & Num, CString & Quantity);

// Convert a type 1 number to a base 10 number
CString AFX_MFC_EXT_TYPE Type1ToB10(CString & Num, CString & BaseStr);

// Convert a base 10 number to a type 1 number
CString AFX_MFC_EXT_TYPE B10ToType1(CString & Num, CString & BaseStr, int EndMsgLen);

CString AFX_MFC_EXT_TYPE GetOutMsg(CString & IMsg, Numbers digits[], int NumDigits);


