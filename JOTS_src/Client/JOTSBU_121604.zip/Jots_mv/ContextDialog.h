#if !defined(AFX_CONTEXTDIALOG_H__741E556A_A47C_11D1_B155_444553540000__INCLUDED_)
#define AFX_CONTEXTDIALOG_H__741E556A_A47C_11D1_B155_444553540000__INCLUDED_


//////////////////////////////////////////////////////////////////////
// CContextDialogClass : Dialog with contextual help (using HtmlHelp activeX)
class CContextDialog : public CDialog
{
// Construction
public:
	CContextDialog(UINT idd, CWnd* pParent = NULL);   // standard constructor

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContextDialog)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


// Implementation
protected:
	CString m_strChmName;

protected:
	CWnd *m_pContextParent;
	UINT m_iContextID;

// Methods
public:
	inline void SetChmName(CString &strChmName){
		m_strChmName = strChmName;
	}
	inline void SetChmName(LPCTSTR lpszChmName){
		m_strChmName = lpszChmName;
	}
	// Generated message map functions
	//{{AFX_MSG(CContextDialog)
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //AFX_CONTEXTDIALOG_H__741E556A_A47C_11D1_B155_444553540000__INCLUDED_
