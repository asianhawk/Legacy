// GetDirectoryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "jots.h"
#include "GetDirectoryDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define WM_BROWSECTRL_NOTIFY	WM_APP + 100
BYTE of[88];
/////////////////////////////////////////////////////////////////////////////
// CGetDirectoryDlg dialog


CGetDirectoryDlg::CGetDirectoryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetDirectoryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetDirectoryDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_csDirectory.Empty();
}


void CGetDirectoryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetDirectoryDlg)
	DDX_Control(pDX, IDC_BTN_DIR, m_btnGetDirectory);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetDirectoryDlg, CDialog)
	//{{AFX_MSG_MAP(CGetDirectoryDlg)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_BROWSECTRL_NOTIFY, OnFileCtrlNotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetDirectoryDlg message handlers

void CGetDirectoryDlg::SetDirectory(CString csDirectory)
{
	csDirectory.TrimLeft();
	csDirectory.TrimRight();
	m_csDirectory=csDirectory;

}

CString	CGetDirectoryDlg::GetDirectory()
{

	return m_csDirectory;
}
LRESULT CGetDirectoryDlg::OnFileCtrlNotify(WPARAM wParam, LPARAM lParam)
{
CString str;
	// The user just activated and closed the file dialog.
	CBrowseCtrl* pCtrl = (CBrowseCtrl*)lParam; // pointer to the CBrowseCtrl object.
	ASSERT(pCtrl == &m_btnGetDirectory);

	if ((int)wParam == IDOK)
	{

		POSITION pos = m_btnGetDirectory.GetStartPosition();
		while (pos != NULL)
			str += m_btnGetDirectory.GetNextPathName(pos) + _T("\n");
			SetDirectory(str);
	}
	else
	{
		// ***** The file dialog was closed by the "Cancel" button *****		
		// TODO: Add your control notification handler code here

	}

	pCtrl = NULL; // Appeases VC6 warning level 4.
	return (LRESULT)0;
}



BOOL CGetDirectoryDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_btnGetDirectory.SetButtonStyle(BC_CTL_FOLDERSONLY|BC_ICO_EXPLORER|BC_BTN_ICON);
	m_btnGetDirectory.SetNotifyMessageID(WM_BROWSECTRL_NOTIFY);	
	m_btnGetDirectory.SetTooltipText(_T("Click Here to Browse!"));


	CAutoFont font;
	font.SetFaceName(_T("Times New Roman"));
	font.SetHeight(15);
	font.SetPitchAndFamily(FIXED_PITCH | FF_ROMAN);
	font.SetWeight(FW_BOLD); 
	
	GetDlgItem(IDC_LBL_TITLE)->SetFont(&font);
	GetDlgItem(IDC_BTN_DIR)->SetFont(&font);
	GetDlgItem(IDOK)->SetFont(&font);
	GetDlgItem(IDCANCEL)->SetFont(&font);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
