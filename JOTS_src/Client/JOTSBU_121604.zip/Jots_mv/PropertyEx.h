#if !defined(AFX_PROPERTYEX_H__AB423ACC_C0D3_4327_BB89_20AF3E3B58BE__INCLUDED_)
#define AFX_PROPERTYEX_H__AB423ACC_C0D3_4327_BB89_20AF3E3B58BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertyEx.h : header file
//
#include "AutoFont.h"

#include "XML\XMLFile.h"

/////////////////////////////////////////////////////////////////////////////
// CPropertyEx

class CPropertyEx : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropertyEx)

// Construction
public:
	CPropertyEx(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CPropertyEx(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	long m_lastPageID;
	long m_lngNumberOfSerializedIndexes;
	long m_lngCurrentCountOfSerializedIndexes;
	int	 m_nMaxNumberOfTemplates;
	int	 m_nCurrentTemplateIndex;
	int  m_nBarCodePageID;
	int  m_nNumberOfLabels;
	BOOL m_blnUniqueTemplates;
	CStringArray m_csaDataDefinition;
	CStringArray m_csaTemplates;
	DataSeries SerialData[MAXDATASERIES];
	LabelInfo  LabelData[MAXLABELS];
	TemplateVariables Templates[MAXTEMPLATES];	
	CXMLFile	m_oXML;
	void GetTemplateNames();
	CString GetTemplatePath();
	CString GetJobName();
	void	SetJobName(CString csJobName);

// Operations
public:
	void Init();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropertyEx();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertyEx)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_strTemplatePath;
	CString m_strTemplateFileExtension;
	CString m_csJobName;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYEX_H__AB423ACC_C0D3_4327_BB89_20AF3E3B58BE__INCLUDED_)
