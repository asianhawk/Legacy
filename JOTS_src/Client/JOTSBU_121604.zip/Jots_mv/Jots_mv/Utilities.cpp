

#include "stdafx.h"
#include "MsgDialog.h"
#include "Utilities.h"
#include "XML\XMLFile.h"
#include <direct.h>
#include "security/blowfish.h"
#include "ZebraZPL.h"


CUtilities::CUtilities()
{


}

BOOL CUtilities::IsNumeric ( CString csNumber )
{

	int int_len = csNumber.GetLength();
	int i;
	char chr_temp;


	if (int_len < 1 )
		return FALSE;

	for (i = 0; i < int_len; i++)
	{
			chr_temp = csNumber[i];
			
			if (((int(chr_temp) < 48) || (int(chr_temp) > 57 )))
			{
				if(!((int(chr_temp) == 43)|| (int(chr_temp) == 45)))
						return FALSE;
			}
	}

	return TRUE;

}

BOOL CUtilities::IsValidInteger(int nValue, int nMin, int nMax, CString csVarName)
{
CString csTemp;
CString csValue,
		csErrorMessage;



	csValue.Format("%d",nValue);
	if (!IsNumeric(csValue))
	{
		
		csErrorMessage.Format("Value For [%s] Not An Valid Integer",csVarName);
		return ErrorMessage(csErrorMessage);

	}

	if (nValue>nMax)
	{
		csTemp="Integer Value Too Large ";
		ErrorMessage(csVarName + 
					  csValue +
					  csTemp);
		return FALSE;
	}

	if (nValue<nMin)
	{
		csTemp="Integer Value Too Small ";
		return ErrorMessage(csVarName + 
					  csValue +
					  csTemp);
	}
	return TRUE;
	
}

BOOL CUtilities::IsStringEmpty(CString csBuffer,CString csErrorMessage)
{
	if (csBuffer.IsEmpty())
	{
		ErrorMessage(csErrorMessage,ERRORLEVEL_1);
		return TRUE;

	}
	return FALSE;
}

BOOL CUtilities::IsStringEmpty(CString csFunctionName, CString csVarName,CString csValue)
{
CString csErrorFName,
		csFormat;

	csFormat.Format("Error in [%s]:\n\r______________________\n\n\n\r",csFunctionName);
	csFormat = csFormat + "Input Variable [%s]\n\n\r";
	
	
	if (csValue.IsEmpty())
	{

		csErrorFName.Format(csFormat+"Can Not Be Blank",csVarName);
		
		ErrorMessage(csErrorFName);
		return TRUE;

	}
	return FALSE;
}



BOOL CUtilities::IsValueAllowed(CString csFunctionName, CString csVarName, CString csInputValue, int nMin, int nMax)
{
CString csErrorFName;
CString csFormat;
int nInputValue;

	csFormat.Format("Error in [%s]:\n\r______________________\n\n\n\r",csFunctionName);
	csFormat = csFormat + "Input Variable [%s]\n\n\r";
	if (csInputValue.IsEmpty())
	{

		
		
		csErrorFName.Format(csFormat+"Can Not Be Blank",csVarName);

		if (csInputValue.IsEmpty())
		{
			ErrorMessage(csErrorFName);
			return FALSE;

		}


	}
		
	nInputValue=atoi(csInputValue);

	if (nInputValue<nMin)
	{

		csFormat.Format("Error in [%s]:\n\r______________________\n\n\n\r",csFunctionName);
		csFormat = csFormat + "Input Variable [%s]\n\n\r";		
	
		csErrorFName.Format(csFormat + "Value Entered [%d]\n\n\rIs Less Than Minimum Allowed [%d]",csVarName,nInputValue,nMin);

		
		
		ErrorMessage(csErrorFName);
		return FALSE;

	}
	if (nInputValue>nMax)
	{


		csFormat.Format("Error in [%s]:\n\r______________________\n\n\n\r",csFunctionName);
		csFormat = csFormat + "Input Variable [%s]\n\n\r";		
	
		csErrorFName.Format(csFormat + "Value Entered [%d]\n\n\rIs Greater Than Maxiimum Allowed [%d]",csVarName,nInputValue,nMax);
		
		
		ErrorMessage(csErrorFName);
		return FALSE;

	}

	return TRUE;
}




BOOL CUtilities::ErrorMessage(CString csErrorMessage)
{
	CMsgDialog *pDlg = new CMsgDialog();
	pDlg->m_csMessage= csErrorMessage;
	pDlg->m_nMsgType=0; 
	pDlg->DoModal();
	return FALSE;

}


BOOL CUtilities::ErrorMessage(UINT nResourceID)
{
CString csErrorMessage;

	csErrorMessage.LoadString(nResourceID); 
	CMsgDialog *pDlg = new CMsgDialog();
	pDlg->m_csMessage= csErrorMessage;
	pDlg->DoModal();
	return FALSE;

}

void CUtilities::ErrorMessage(CString csErrorMessage, int nMsgType)
{
	CMsgDialog *pDlg = new CMsgDialog();
	pDlg->m_csMessage= csErrorMessage;
	pDlg->m_nMsgType=nMsgType; 
	pDlg->DoModal();


}

void CUtilities::ErrorMessage(CString csErrorMessage, CString csTitle)
{
	CMsgDialog *pDlg = new CMsgDialog();
	pDlg->m_csMessage= csErrorMessage;
	pDlg->m_nMsgType=-1; 
	if (!csTitle.IsEmpty()) 
		pDlg->m_csTitle=csTitle; 

	pDlg->DoModal();


}


BOOL CUtilities::UserResponse(CString csMessage)
{
BOOL blnResponse;
	
	CMsgDialog *pDlg = new CMsgDialog();
	pDlg->m_csMessage= csMessage;
	pDlg->m_nMsgType=YES_OR_NO; 
	pDlg->DoModal();
	blnResponse=pDlg->GetContinue();

	delete pDlg;
	return blnResponse;


}



BOOL CUtilities::FindAFile(CString csStartLocation )
{

CFileFind ff;
CString csFileFound,
		csTemp;
BOOL bFound = FALSE;

    		
   bFound = ff.FindFile(csStartLocation);
   while (bFound)
   {
      bFound = ff.FindNextFile();

	  if (ff.IsDirectory())
	  {
		if (ff.IsDots())
                continue;
		csTemp=ff.GetFilePath()+"\\*.*";
		if (FindAFile(csTemp)) return TRUE;

	  }
	  else
	  {
	      csFileFound=ff.GetFileName();

		  csTemp=csFileFound;
		  csTemp.MakeUpper(); 	
		  if (csTemp == "JOTSCONFIG.XML")
		  {
			  m_strFileFound=ff.GetFilePath(); 	
			  return TRUE;
		  }
	  }
   }

   return FALSE;


}




BOOL CUtilities::FindJoTsConfigFile(CString csStartLocation)
{

CFileFind ff;
CString csFileFound,
		csTemp;
BOOL bFound = FALSE;

   if (IsFileValid(csStartLocation))
   {
		csTemp=csStartLocation;
		csTemp.MakeUpper(); 
		if (csTemp.Find("JOTSCONFIG.XML")!=-1)
		{
			m_strFileFound=csStartLocation;
			
			return TRUE;
		}
		
		
   }
    		
   bFound = ff.FindFile("C:\\*.*");
   while (bFound)
   {
      bFound = ff.FindNextFile();
	  if (ff.IsDirectory())
	  {
		if (ff.IsDots())
                continue;
		
		if(FindAFile(ff.GetFilePath()))
		{
			return TRUE;
		}
	  }
	  else
	  {
	      csFileFound=ff.GetFileName();

		  csTemp=csFileFound;
		  csTemp.MakeUpper(); 	
		  if (csFileFound=="JOTSCONFIG.XML")
		  {

			  return TRUE;
		  }
	  }
   }

   return FALSE;


}



BOOL CUtilities::FindJoTsConfigFile(CString csStartLocation, CString *csActualLocation)
{

CFileFind ff;
CString csFileFound,
		csTemp;
BOOL bFound = FALSE;

   if (IsFileValid(csStartLocation))
   {
		csTemp=csStartLocation;
		csTemp.MakeUpper(); 
		if (csTemp.Find("JOTSCONFIG.XML")!=-1)
		{
			m_strFileFound=csStartLocation;
			*csActualLocation=csStartLocation;	
			return TRUE;
		}
		
		
   }
    		
   bFound = ff.FindFile("C:\\*.*");
   while (bFound)
   {
      bFound = ff.FindNextFile();
	  if (ff.IsDirectory())
	  {
		if (ff.IsDots())
                continue;
		
		if(FindAFile(ff.GetFilePath()))
		{
			return TRUE;
		}
	  }
	  else
	  {
	      csFileFound=ff.GetFileName();

		  csTemp=csFileFound;
		  csTemp.MakeUpper(); 	
		  if (csFileFound=="JOTSCONFIG.XML")
		  {

			  m_strFileFound=ff.GetFilePath();
			  *csActualLocation=ff.GetFilePath();
			  
			  return TRUE;
		  }
	  }
   }

   return FALSE;


}


BOOL CUtilities::IsFileValid(CString csFileName)
{
 CFileFind ff;

	return ff.FindFile(csFileName);

}

BOOL CUtilities::GetJobsDirectory(CString *csJobsDirectory)
{
CString csConfigFile;
CXMLFile *pXML;
CFileFind ff;	

	pXML = new CXMLFile();	
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
	   delete pXML;		
	   return FALSE;

	}
	pXML->LoadFile(csConfigFile); 
	pXML->GetSingleNodeValue("//Config/Jobs/Path",*csJobsDirectory); 



	delete pXML;

	// Now test that the direcory exists

	if(!ff.FindFile(*csJobsDirectory+"*.*",0)) 
		return ErrorMessage(IDS_ERR_MESSAGE_MISSING_JOBDIR);


	return TRUE;
}

CString CUtilities::GetTCPAddress()
{
CString csTCPAddress;
CString csConfigFile;
CXMLFile *pXML;

	pXML = new 	CXMLFile ();	
	
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return "";

   }
   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue("//Config/TCPAddress",csTCPAddress); 

  

	delete pXML;
	return csTCPAddress;


}

CString CUtilities::GetTCPPort()
{
CString csTCPPort;
CString csConfigFile;
CXMLFile *pXML;

	pXML = new 	CXMLFile ();	
	
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return "";

   }
   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue("//Config/TCPPort",csTCPPort); 

  

	delete pXML;
	return csTCPPort;



}


BOOL CUtilities::GetTCPAddress(CString *csTCPAddress)
{
CXMLFile *pXML;
CString csConfigFile;

	pXML = new 	CXMLFile ();	
	
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return FALSE;

   }
   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue("//Config/TCPAddress",*csTCPAddress); 

  

	delete pXML;
	return TRUE;


}


BOOL CUtilities::GetTCPPort(CString *csTCPPort)
{
CXMLFile *pXML;
CString csConfigFile;
	pXML = new 	CXMLFile ();	
	
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return FALSE;

   }
   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue("//Config/TCPPort",*csTCPPort); 

  

	delete pXML;
	return TRUE;


}


void CUtilities::SetTCPAddress(CString csTCPAddress)
{
CXMLFile *pXML;
CString csConfigFile;
	pXML = new 	CXMLFile ();	
	
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return;

   }
   pXML->LoadFile(csConfigFile); 
   pXML->UpdateNode("//Config/TCPAddress",csTCPAddress); 

  

   delete pXML;
   return;


}


void CUtilities::SetTCPPort(CString csTCPPort)
{
CXMLFile *pXML;
CString csConfigFile;
	pXML = new 	CXMLFile ();	
	
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		return;

	}
	pXML->LoadFile(csConfigFile); 
	pXML->UpdateNode("//Config/TCPPort",csTCPPort);
	
  

	delete pXML;
	return;


}




BOOL CUtilities::GetZebraPrinterTemplateDirectory(CString *csPrinterTemplateDirectory)
{
CString csConfigFile;
CXMLFile *pXML;
	
   pXML	= new CXMLFile();
   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
	   delete pXML;		
	   return FALSE;

   }
   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue(ZEBRATEMPLATES,*csPrinterTemplateDirectory); 


   
   if (csPrinterTemplateDirectory->IsEmpty())
   {
		delete pXML;
		return FALSE;
   }
  
	delete pXML;
	return TRUE;
}


BOOL CUtilities::GetTemplates(CStringArray *csaTemplates)
{
CFileFind ff;

CString csConfigFile,
		csTemplatesLocation,
		csZebraFileExtension;

CXMLFile *pXML;


   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return FALSE;

   }
   if (csConfigFile.IsEmpty())
   {
		AfxMessageBox("Config File Not Found");
		return FALSE;

   }
   pXML	= new CXMLFile();

   if(!pXML->LoadFile(csConfigFile))
   {
	   ErrorMessage(pXML->GetLastError());
	   delete pXML;
       return FALSE;

   }
   pXML->GetSingleNodeValue(ZEBRATEMPLATES,csTemplatesLocation); 
   pXML->GetSingleNodeValue(ZEBRFILEEXTENSION,csZebraFileExtension); 

   delete pXML;
		
   BOOL bWorking = ff.FindFile(csTemplatesLocation+"*."+csZebraFileExtension);
   while (bWorking)
   {
      bWorking = ff.FindNextFile();
      csaTemplates->Add(ff.GetFileName());
   }

   return TRUE;

}



BOOL CUtilities::ReadPrinterTemplate(CString csFileSource, CString *csReadFile)
{
CString csErrorMessage,
		csInput;

      CStdioFile f;
      if (!f.Open(csFileSource, CFile::modeRead | CFile::typeText))
      {
         csErrorMessage.Format("Error Opening [%s]",csFileSource);
		 ErrorMessage(csErrorMessage);
         return FALSE;
      }

      CString t;
      while (f.ReadString(t))
      {
         csInput+=t;
      }

      f.Close();
	
	  if (csInput.IsEmpty()) return FALSE;
	  *csReadFile=csInput;

	  return TRUE;

}

NumberBases *CUtilities::GetNumberBases()
{
CString csConfigFile,
		csValue;
CXMLFile *pXML;
long length;	
	
	pXML = new CXMLFile();

	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		return FALSE;

	}
	pXML->LoadFile(csConfigFile); 
	IXMLDOMNodeList *pnl; 

//       Number Base Information
	pXML->GetDocument()->selectNodes(_bstr_t("//Config/NumberBases/Base"),&pnl);

	IXMLDOMNode *pNode; 

	pnl->get_length(&length);	
	for (int i=0; i<length; i++)
	{
	  pnl->get_item(i,&pNode);

	  pXML->GetSingleNodeValue(pNode,"Name",csValue);
	  if (!csValue.IsEmpty())
		  m_oNumberBases[i].BaseName  = csValue;

	  pXML->GetSingleNodeValue(pNode,"Table",csValue);
	  if (!csValue.IsEmpty())
		  m_oNumberBases[i].Table  = csValue;

	}
	pNode->Release(); 
    pnl->Release();
	delete pXML;

	return m_oNumberBases;
}

CString CUtilities::GetBaseNumberTable(NumberBases *BaseNumbers, CString csName)
{
int nBaseIndex=0;

	while (!BaseNumbers[nBaseIndex].BaseName.IsEmpty())
	{
		if (BaseNumbers[nBaseIndex].BaseName==csName)
			return BaseNumbers[nBaseIndex].Table; 
		
			nBaseIndex++;

		if (nBaseIndex==MAXNUMBERBASES)
		{
			ErrorMessage("Base Number Name Not Found");
			break;
		}
	}
	return "";
}


CString CUtilities::GetBaseNumberTable(CString csName)
{

int nBaseIndex=0;
	GetNumberBases();

	

	while (!m_oNumberBases[nBaseIndex].BaseName.IsEmpty())
	{
		if (m_oNumberBases[nBaseIndex].BaseName==csName)
			return m_oNumberBases[nBaseIndex].Table; 
		
			nBaseIndex++;

		if (nBaseIndex==MAXNUMBERBASES)
		{
			ErrorMessage("Base Number Name Not Found");
			break;
		}
	}
	return "";
}



BOOL CUtilities::UpdateSerialNumber(CString csJobName, CString csName, CString csNewSerialNumber)
{
CString csCurrentDSName,
		csJobsDirectory,
		csConfigFile;

long length;

CXMLFile *pXML;
IXMLDOMNode *pNode=NULL;
IXMLDOMNodeList *pnl=NULL; 
	
	
	pXML = new CXMLFile();

	if (!GetJobsDirectory(&csJobsDirectory))
	{
		ErrorMessage("Jobs Directory Not Found");
		delete pXML;
		return FALSE;

	}

	csConfigFile = csJobsDirectory + CString("\\") + csJobName + CString(".xml");


	pXML->LoadFile(csConfigFile); 

	pXML->GetDocument()->selectNodes(_bstr_t("//Job/Data"),&pnl);



	pnl->get_length(&length);

	for (int i=0; i<length; i++)
	{
  
	  pnl->get_item(i,&pNode);

	  pXML->GetSingleNodeValue(pNode,"Name",csCurrentDSName);
	  if (!csCurrentDSName.IsEmpty())
	  {
		  if (csCurrentDSName.Find(csName)!=-1)
		  {
			  pXML->SetSingleNode_Text(pNode, "StartingSerialNumber" , csNewSerialNumber);	  

		  }
		  

	  }
  
	  pNode->Release();

	}
	pnl->Release();
	pXML->SaveFile(csConfigFile);
	delete pXML;
	return TRUE;
}


CString CUtilities::GetSerialNumber(CString csJobName, CString csName)
{
CString csJobsDirectory,
		csConfigFile,
		csSerialNumber,
		csValue;


long length;

CXMLFile *pXML;
IXMLDOMNode *pNode=NULL;
IXMLDOMNodeList *pnl=NULL; 
	
	
	pXML = new CXMLFile();
	if (!GetJobsDirectory(&csJobsDirectory))
	{
		ErrorMessage("Jobs Directory Not Found");
		delete pXML;
		return "";

	}

	csConfigFile = csJobsDirectory + CString("\\") + csJobName + CString(".xml");


	pXML->LoadFile(csConfigFile); 

	pXML->GetDocument()->selectNodes(_bstr_t("//Job/Data"),&pnl);



	pnl->get_length(&length);

	for (int i=0; i<length; i++)
	{
  
	  pnl->get_item(i,&pNode);

	  pXML->GetSingleNodeValue(pNode,"Name",csValue);

	 
	  if (csValue.Find(csName)!=-1)
	  {

	
		  pXML->GetSingleNodeValue(pNode,"StartingSerialNumber",csValue);
		  if (!csValue.IsEmpty())
		  {
			  csSerialNumber=csValue;  
			  
			  break;
		  }
	  }
	}

	if (pNode) pNode->Release(); 
	pnl->Release();
	delete pXML;  

	return csSerialNumber;
}



BOOL CUtilities::GetComPortInfo(SerialPortData *PortData)
{
CXMLFile *pXML;
CString csConfigFile,
		csTemp;
	pXML = new 	CXMLFile ();	

	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		return FALSE;

	}
	pXML->LoadFile(csConfigFile); 

		// Name
	pXML->GetSingleNodeValue("//Config/MorphorSerialPort/Name",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Com Port Name Undefined");
		delete pXML;
		return FALSE;
	}
	PortData->Name = csTemp;


	// Baud rate
	pXML->GetSingleNodeValue("//Config/MorphorSerialPort/BaudRate",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Baud Rate Undefined");
		delete pXML;
		return FALSE;
	}
	PortData->BaudRate = csTemp;

	
	// Parity
	pXML->GetSingleNodeValue("//Config/MorphorSerialPort/Parity",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Parity Undefined");
		delete pXML;
		return FALSE;
	}
	PortData->Parity = csTemp;

	// Word Length
	pXML->GetSingleNodeValue("//Config/MorphorSerialPort/WordLength",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Word Length Not Defined");
		delete pXML;
		return FALSE;
	}
	PortData->Wordlength  = atoi(csTemp);
	

	
	// Stop Bits
	pXML->GetSingleNodeValue("//Config/MorphorSerialPort/Stopbits",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Stop Bits Not Defined");
		delete pXML;
		return FALSE;
	}
	PortData->StopBits  = atoi(csTemp);
	
	delete pXML;
	return TRUE;


}



BOOL CUtilities::SetComPortInfo(SerialPortData PortData)
{
CXMLFile *pXML;
CString csConfigFile,
		csTemp;

	pXML = new 	CXMLFile ();	
	
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		return FALSE;

	}
	pXML->LoadFile(csConfigFile); 

	// Com Port Number
	csTemp=PortData.Name;
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Com Port Number Not Defined");
		return FALSE;
	}
	if (!pXML->UpdateNode("//Config/MorphorSerialPort/Name",csTemp))
		return FALSE;
	

	// Baud Rate
	csTemp=PortData.BaudRate;
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Baud Rate Not Defined");
		return FALSE;
	}
	if (!pXML->UpdateNode("//Config/MorphorSerialPort/BaudRate",csTemp))
		return FALSE;
	
	// Parity
	csTemp=PortData.Parity ;
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Parity Not Defined");
		return FALSE;
	}
	if (!pXML->UpdateNode("//Config/MorphorSerialPort/Parity",csTemp))
		return FALSE;


	// Word Length
	csTemp.Format("%d",PortData.Wordlength);
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Word Length Not Defined");
		return FALSE;
	}
	if (!pXML->UpdateNode("//Config/MorphorSerialPort/WordLength",csTemp))
		return FALSE;


	// Stop Bits
	csTemp.Format("%d",PortData.StopBits);
	if (csTemp.IsEmpty())
	{
		ErrorMessage("Stop Bit Not Defined");
		return FALSE;
	}
	if (!pXML->UpdateNode("//Config/MorphorSerialPort/Stopbits",csTemp))
		return FALSE;


	delete pXML;
	return TRUE;
}

void CUtilities::YieldToWindows ( void )
{


	// Process existing messages in the application's message queue.
	// When the queue is empty, do clean up and return.
	
	MSG msg;

	while ( ::PeekMessage(&msg,NULL,0,0,PM_NOREMOVE) )
	{
		if (!AfxGetThread()->PumpMessage())
//		if (!CWinThread::PumpMessage())
			return;
	}

}

BOOL CUtilities::IsUniqueJobFile(CString csFileName)
{
CString csConfigFile,
		csJobsDirectory;


CFileFind ff;



	if (!GetJobsDirectory(&csJobsDirectory))
	{
	
		return FALSE;

	}

	csConfigFile = csJobsDirectory + CString("\\") + csFileName + CString(".xml");

	if(!ff.FindFile(csConfigFile))
	{
		return TRUE;
	}
	return FALSE;
}


BOOL CUtilities::GetScannerInfo(int nIndex, Scanner *pSCanner)
{
CString csConfigFile;
CString csPrefix,
		csErrMessagePrefix,
		csTemp;
CXMLFile *pXML;
	
	pXML	= new CXMLFile();
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
	   delete pXML;		
	   return FALSE;

	}
	pXML->LoadFile(csConfigFile); 
   
	switch (nIndex)
	{
		case MORPHOR_BC_SCANNER_ID:
			 csPrefix=MORPHOR_BC_SCANNER;
			 csErrMessagePrefix="Barcode Scanner";

			 break;
		case MORPHOR_AUX_SCANNER_ID:
			 csPrefix=MORPHOR_AUX_SCANNER;
			 csErrMessagePrefix="Aux Scanner";

			 break;
		default:
			 csPrefix=MORPHOR_BC_SCANNER_ID;
			 csErrMessagePrefix="Barcode Scanner";
			 
	}
	//Scanner ID
	pXML->GetSingleNodeValue(csPrefix+"ID",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage(csErrMessagePrefix +"Scanner ID Not Found");
		delete pXML;
		return FALSE;
	}
	pSCanner->ID  = csTemp;

   
	//Pre Trigger Delay
	pXML->GetSingleNodeValue(csPrefix+"PreReadDelay",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage(csErrMessagePrefix+ "Pre Trigger Delay Not Found");
		delete pXML;
		return FALSE;
	}
	pSCanner->PreTriggerDelay = csTemp;
  

	//Post Trigger Max Read TimeOut
	pXML->GetSingleNodeValue(csPrefix+"PostReadTimeOut",csTemp); 
	if (csTemp.IsEmpty())
	{
		ErrorMessage(csErrMessagePrefix+ "Post Trigger Read Time Out Not Found");
		delete pXML;
		return FALSE;
	}
	pSCanner->PostScanMaxTimeout  = csTemp;

	
	delete pXML;
	return TRUE;
}



BOOL CUtilities::IsScannerUsed(int nIndex)
{
CString csConfigFile;
CString csPrefix,
		csErrMessagePrefix,
		csTemp;
CXMLFile *pXML;
BOOL blnUsed=FALSE;
	
	pXML	= new CXMLFile();
	if(!FindJoTsConfigFile(DEFAULTCONFIGFILE,&csConfigFile))
	{
	   delete pXML;		
	   return FALSE;

	}
	pXML->LoadFile(csConfigFile); 
   
	switch (nIndex)
	{
		case MORPHOR_BC_SCANNER_ID:
			 csPrefix=MORPHOR_BC_SCANNER;

			 break;
		case MORPHOR_AUX_SCANNER_ID:
			 csPrefix=MORPHOR_AUX_SCANNER;

			 break;
		default:
			 csPrefix=MORPHOR_BC_SCANNER_ID;
			 
	}
	//Scanner ID
	pXML->GetSingleNodeValue(csPrefix+"Enabled",csTemp); 
	if (csTemp.IsEmpty())
	{
		delete pXML;
		return FALSE;
	}
	csTemp.MakeUpper();
	if(csTemp.Find("Y")!=-1)
	{
		blnUsed = TRUE;
	}
	
	if(csTemp.Find("T")!=-1)
	{
		blnUsed = TRUE;
	}

	
	delete pXML;
	return blnUsed;
}

BOOL CUtilities::IsSupportRotation()
{
CString csConfigFile;
CString csPrefix,
		csErrMessagePrefix,
		csTemp;
CXMLFile *pXML;
BOOL blnUsed=FALSE;
	
	pXML	= new CXMLFile();
	if(!FindJoTsConfigFile(DEFAULTCONFIGFILE,&csConfigFile))
	{
	   delete pXML;		
	   return FALSE;

	}
	pXML->LoadFile(csConfigFile); 
   

	pXML->GetSingleNodeValue(SUPPORTROTATION,csTemp); 
	if (csTemp.IsEmpty())
	{
		delete pXML;
		return FALSE;
	}
	csTemp.MakeUpper();
	if(csTemp.Find("Y")!=-1)
	{
		blnUsed = TRUE;
	}
	
	if(csTemp.Find("T")!=-1)
	{
		blnUsed = TRUE;
	}

	
	delete pXML;
	return blnUsed;
}



CString CUtilities::GetConfigValue(CString csXPath)
{

CXMLFile *pXML;
CString csConfigFile,
		csTemp,
		csErrorMessage;

	pXML = new 	CXMLFile ();	

	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		delete pXML;
		return "";

	}
	if(!pXML->LoadFile(csConfigFile))
	{

		delete pXML;
		return "";

	}

		// Name
	pXML->GetSingleNodeValue(csXPath,csTemp); 
	if (csTemp.IsEmpty())
	{
		csErrorMessage.Format("Config Value [%s] Not Found",csXPath); 
		ErrorMessage(csErrorMessage);
		delete pXML;
		return "";
	}
	
	delete pXML;
	return csTemp;


}

CString CUtilities::GetConfigValue(CString csXPath, BOOL blnWarning)
{

CXMLFile *pXML;
CString csConfigFile,
		csTemp,
		csErrorMessage;

	pXML = new 	CXMLFile ();	

	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		delete pXML;
		return "";

	}
	if(!pXML->LoadFile(csConfigFile))
	{

		delete pXML;
		return "";

	}

		// Name
	pXML->GetSingleNodeValue(csXPath,csTemp); 
	if (csTemp.IsEmpty()&& (blnWarning))
	{
		csErrorMessage.Format("Config Value [%s] Not Found",csXPath); 
		ErrorMessage(csErrorMessage);
		delete pXML;
		return "";
	}
	
	delete pXML;
	return csTemp;


}


void CUtilities::SetConfigValue(CString csXPath, CString csValue)
{

CXMLFile *pXML;
CString csConfigFile,
		csErrorMessage;

	pXML = new 	CXMLFile ();	
	
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		delete pXML;
		return;

	}
	pXML->LoadFile(csConfigFile); 


	if (csXPath.IsEmpty())
	{
		csErrorMessage.Format("Config Value [%s] Not Found",csXPath); 
		ErrorMessage(csErrorMessage);
		delete pXML;
		return;
	}
	if (!pXML->UpdateNode(csXPath,csValue))
	{
		delete pXML;
		return;
	}
	pXML->SaveFile(csConfigFile);
	
	delete pXML;


}


void CUtilities::SetBaseNumber(NumberBases *pBaseSchema)
{

CXMLFile *pXML;
CString csConfigFile,
		csErrorMessage,
		csTemp;

	pXML = new 	CXMLFile ();	
	
	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		delete pXML;
		return;

	}
	pXML->LoadFile(csConfigFile); 
	

    pXML->AddBaseNumbers(pBaseSchema); 

	pXML->SaveFile(csConfigFile);
	
	delete pXML;


}

ZebraSetting *CUtilities::GetZebraSettings()
{

CString csConfigFile,
		csValue;
CXMLFile *pXML;
long length;	

	
	pXML = new CXMLFile();

	if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
	{
		return m_oPrinterSettings;

	}
	if(!pXML->LoadFile(csConfigFile))
	{
		ErrorMessage("Error Loading Config File In ParseZebraSettings()");
		return m_oPrinterSettings;

	}
	IXMLDOMNodeList *pnl; 

//       Number Base Information
	pXML->GetDocument()->selectNodes(_bstr_t("//Config/ZebraFrontPanelSetting"),&pnl);

	IXMLDOMNode *pNode; 

	pnl->get_length(&length);	
	for (int i=0; i<length; i++)
	{
	  pnl->get_item(i,&pNode);

	  pXML->GetSingleNodeValue(pNode,"Name",csValue);
	  if (!csValue.IsEmpty())
		  m_oPrinterSettings[i].Name   = csValue;

	  pXML->GetSingleNodeValue(pNode,"Description",csValue);
	  if (!csValue.IsEmpty())
		  m_oPrinterSettings[i].Description  = csValue;


	  pXML->GetSingleNodeValue(pNode,"ZPLCmd",csValue);
	  if (!csValue.IsEmpty())
		  m_oPrinterSettings[i].ZPLCmd   = csValue;
	

	  pXML->GetSingleNodeValue(pNode,"ZPLArgs",csValue);
	  if (!csValue.IsEmpty())
		  m_oPrinterSettings[i].NumberOfArgs   = csValue;
	  
	
	}
	for (i=length;i<MAXPRINTERPARAMETERS;i++)
	{
		m_oPrinterSettings[i].Name.Empty();  	
		m_oPrinterSettings[i].Description.Empty();  	
		m_oPrinterSettings[i].ZPLCmd.Empty();  	
		m_oPrinterSettings[i].NumberOfArgs.Empty();  	
		m_oPrinterSettings[i].Value.Empty();
	}

	pNode->Release(); 
    pnl->Release();
	delete pXML;

	return m_oPrinterSettings;


}

void CUtilities::ParseZebraPrinterSettings(CString csFullPath, ZebraSetting *Settings)
{
CStdioFile ff;
CString csBuffer,
		csTemp;

int nNumberOfSettings=0,
	nCount;


	while (!Settings[nNumberOfSettings].Name.IsEmpty())
	{
		nNumberOfSettings++;
	}



	if(!IsFileValid(csFullPath))
	{
		CString csErrorMessage;
		csErrorMessage.Format("File [%s] Not Found ",csFullPath);
		ErrorMessage(csErrorMessage);
		return;

	}

	ff.Open(csFullPath,CFile::modeRead);
	while(ff.ReadString(csBuffer))
	{
		csBuffer.MakeUpper(); 
		for(nCount=0;nCount<nNumberOfSettings;nCount++)
		{
			csTemp=Settings[nCount].Name;
			csTemp.MakeUpper();			// just in case Zebra changes the case of the outputs
			if(csBuffer.Find(csTemp)!=-1)
			{
				Settings[nCount].Value =csBuffer.Mid(2,20); 
			
			}

		}

	}

	ff.Close(); 

}

BOOL CUtilities::GetJobFileInfo(CString csJobFile, JobInfo *pJobInfo)
{
CString csCurrentDSName,
		csJobsDirectory,
		csConfigFile,
		csValue;

long length;

CXMLFile *pXML;
	
	

	if (!GetJobsDirectory(&csJobsDirectory))
	{
		ErrorMessage("Jobs Directory Not Found");
		return FALSE;

	}

	csConfigFile = csJobsDirectory + CString("\\") + csJobFile;

	pXML = new CXMLFile();
	pXML->LoadFile(csConfigFile); 



   IXMLDOMNodeList *pnl=NULL; 
   pXML->GetDocument()->selectNodes(_bstr_t("//Job"),&pnl);
   IXMLDOMNode *pNode=NULL; 	
   pnl->get_length(&length);	
   for (int i=0; i<length; i++)
   {
      pnl->get_item(i,&pNode);

	  pXML->GetSingleNodeValue(pNode,"Name",csValue);
	  if (!csValue.IsEmpty())
		  pJobInfo->Name=csValue;

	  pXML->GetSingleNodeValue(pNode,"Company",csValue);
	  if (!csValue.IsEmpty())
		pJobInfo->Customer=csValue;

  	  pXML->GetSingleNodeValue(pNode,"Product",csValue);
	  if (!csValue.IsEmpty())
		pJobInfo->ProductDescription=csValue;


   }
   pNode->Release();
   pnl->Release();
   delete pXML;

   return TRUE;
}


void CUtilities::SetJobFileInfo(CString csJobFile, JobInfo *pJobInfo)
{
CString csTemp,
		csJobsDirectory,
		csConfigFile;

long length;

CXMLFile *pXML;
IXMLDOMNode *pNode=NULL;
IXMLDOMNodeList *pnl=NULL; 
int nOffset=0;	
	
	pXML = new CXMLFile();

	if (!GetJobsDirectory(&csJobsDirectory))
	{
		ErrorMessage("Jobs Directory Not Found");
		delete pXML;

	}

	csConfigFile = csJobsDirectory + CString("\\") +csJobFile;


	if(!IsFileValid(csConfigFile))
	{
		ErrorMessage("Job File Not Found");
		return;
	}

	pXML->LoadFile(csConfigFile); 

	pXML->GetDocument()->selectNodes(_bstr_t("//Job"),&pnl);



	pnl->get_length(&length);

	for (int i=0; i<length; i++)
	{
  
	  pnl->get_item(i,&pNode);
	
	  nOffset = csJobFile.Find(".");
	  if (nOffset!=-1)
		  csTemp=csJobFile.Mid(0,nOffset);
	  pXML->SetSingleNode_Text(pNode, "Name" , csTemp );	  
	  pXML->SetSingleNode_Text(pNode, "Company" , pJobInfo->Customer);	  
	  pXML->SetSingleNode_Text(pNode, "Product" , pJobInfo->ProductDescription);	  

		  

  
	  pNode->Release();

	}
	pnl->Release();
	pXML->SaveFile(csConfigFile);
	delete pXML;
}

BOOL CUtilities::IsValidTemplate(CString csTemplate)
{
CFileFind ff;

CString csConfigFile,
		csTemplatesLocation,
		csZebraFileExtension;

CXMLFile *pXML;


   if(!FindJoTsConfigFile("c:\\JoTS\\Config\\JoTSConfig.xml",&csConfigFile))
   {
		return FALSE;

   }
   if (csConfigFile.IsEmpty())
   {
		AfxMessageBox("Config File Not Found");
		return FALSE;

   }
   pXML	= new CXMLFile();

   pXML->LoadFile(csConfigFile); 
   pXML->GetSingleNodeValue(ZEBRATEMPLATES,csTemplatesLocation); 



   delete pXML;

   return IsFileValid(csTemplatesLocation+csTemplate);


}


CString CUtilities::ReadEncryptedFile(CString csFileName)
{
CString csKeyWord,
		csDeCryptedFile;

auto_ptr<CBlowFish> m_apBlowFish;

BOOL bHex;
int iMode;
int iPadding,
	iLength;
IMethod* poMethod;

	BlowFishParams(csKeyWord,bHex,iMode,iPadding);
	if(NULL == m_apBlowFish.get())
		//Create First Time
		m_apBlowFish = auto_ptr<CBlowFish>(new CBlowFish());
	char acKey[56];
	iLength = csKeyWord.GetLength();
	strncpy(acKey, LPCTSTR(csKeyWord), 56);
	m_apBlowFish->Initialize(acKey, 56, SBlock(0UL,0UL), iMode, iPadding);
	poMethod = m_apBlowFish.get(); 

	csDeCryptedFile=poMethod->DecryptFileToBuffer(LPCTSTR(csFileName));
	delete poMethod;

	if (csDeCryptedFile.IsEmpty())
	{
	
		return "";
	}

	return csDeCryptedFile;

}

BOOL CUtilities::IsJobRecordOK(JobInfo *pJobInfo)
{

	if (!IsPrinterTemplateBCVarsOK(pJobInfo))
	{
		return FALSE;
	}
	if (!IsPrinterTemplateHRVarsOK(pJobInfo))
	{
		return FALSE;
	}

	return TRUE;
}


BOOL CUtilities::IsPrinterTemplateBCVarsOK(JobInfo *pJobInfo)
{

CZebraZPL ZebraPrinter;
int nNumberOfBarCodeVars=0;
int nCount=0,
	nIndex=0,
	nBCVarIndex=0,
	nMaxVarNameFoundIndex=0,
	nBCCount=0;
CStringArray csBCVars;
int nNumberOfBC_vars;
CString csTemp;
CString csFormat,
		csTemplateName;

BOOL blnFound=FALSE;
	
	
	// scroll through the label records
	while(!pJobInfo->LabelInfo[nCount].TemplateName.IsEmpty())
	{
		
		csTemplateName=pJobInfo->LabelInfo[nCount].TemplateName;
		
		csBCVars.RemoveAll(); 
		ZebraPrinter.ReadTemplate(csTemplateName);
		ZebraPrinter.ScanForVars(); 
		nNumberOfBC_vars=ZebraPrinter.GetCountOfBarCodeVars();
 	    nMaxVarNameFoundIndex=0;	// for the future where there may be more than
		
		for (nBCCount=0;nBCCount<nNumberOfBC_vars;nBCCount++)
		{
			csBCVars.Add(ZebraPrinter.GetBCVar(nBCCount)); 

		}
		for (nBCVarIndex=0;nBCVarIndex<MAXVARS;nBCVarIndex++)
		{
		  csTemp = pJobInfo->Templates[nCount].BCVars[nBCVarIndex].Name;
		  if (csTemp.IsEmpty()) break; 	
		  blnFound=FALSE;			// one BC per label
		  for (nIndex=nMaxVarNameFoundIndex;nIndex<nNumberOfBC_vars;nIndex++)
		  {
				if (csBCVars.GetAt(nIndex)==csTemp)
				{
					blnFound=TRUE;
			 	    nMaxVarNameFoundIndex++;	// for the future where there may be more than
					break;
				}

		  }
		  if(!blnFound)break;  // break out of driven loop
		}
        if(!blnFound)break; // break out of driver loop
		nCount++;

	}
	if(!blnFound)
	{
		// Bar Code Variables Always Require  A Data Factory
		// A Bar code variable without a data factory is static and should remove its []
		if (nNumberOfBC_vars==0) return TRUE;

		CUtilities *pUtil = new CUtilities();
		csFormat.LoadString(IDS_ERR_MISSING_DATA_FACTORY);
	
		if (nMaxVarNameFoundIndex==0)
			if (csBCVars.GetAt(nMaxVarNameFoundIndex).IsEmpty())
			{
				csTemp.Format(csFormat,csTemplateName,"No Bar Code Variable Defined");
			}
			else
				csTemp.Format(csFormat,csTemplateName,csBCVars.GetAt(nMaxVarNameFoundIndex));
		else
		{
			csTemp.Format(csFormat,csTemplateName,csBCVars.GetAt(nMaxVarNameFoundIndex-1));
		}
		pUtil->ErrorMessage( csTemp,2); 
		delete pUtil;
		return FALSE;
	}
	return TRUE;
}


BOOL CUtilities::IsPrinterTemplateHRVarsOK(JobInfo *pJobInfo)
{

CZebraZPL ZebraPrinter;
int nNumberOfBarCodeVars=0;
int nCount=0,
	nIndex=0,
	nHRVarIndex=0,
	nMaxVarNameFoundIndex=0,
	nHRCount=0;
CStringArray csHRVars;
int nNumberOfHR_vars;
CString csTemp;
CString csFormat,
		csTemplateName;

BOOL blnFound=FALSE;
	
	
	// scroll through the label records
	while(!pJobInfo->LabelInfo[nCount].TemplateName.IsEmpty())
	{
		
		csTemplateName=pJobInfo->LabelInfo[nCount].TemplateName;
		
		csHRVars.RemoveAll(); 
		ZebraPrinter.ReadTemplate(csTemplateName);
		ZebraPrinter.ScanForVars(); 
		nNumberOfHR_vars=ZebraPrinter.GetCountOfHRVars();
		
		for (nHRCount=0;nHRCount<nNumberOfHR_vars;nHRCount++)
		{
			csHRVars.Add(ZebraPrinter.GetHRVar(nHRCount)); 

		}
		for (nHRVarIndex=0;nHRVarIndex<MAXVARS;nHRVarIndex++)
		{
		  csTemp = pJobInfo->Templates[nCount].HRVars[nHRVarIndex].Name;
		  if (csTemp.IsEmpty()) break; 	
		  blnFound=FALSE;			
		  for (nIndex=nMaxVarNameFoundIndex;nIndex<nNumberOfHR_vars;nIndex++)
		  {
				if (csHRVars.GetAt(nIndex)==csTemp)
				{
					blnFound=TRUE;
					break;
				}

		  }
		  if(!blnFound)break;  // break out of driven loop
		  nMaxVarNameFoundIndex++;	// for the future where there may be more than
		}
        if(!blnFound)break; // break out of driver loop
		nCount++;

	}
	if(!blnFound)
	{
		// Bar Code Variables Always Require  A Data Factory
		// A Bar code variable without a data factory is static and should remove its []
		if (nNumberOfHR_vars==0) return TRUE;
		CUtilities *pUtil = new CUtilities();
		csFormat.LoadString(IDS_ERR_MISSING_DATA_FACTORY_HR);
		csTemp.Format(csFormat,csTemplateName,csHRVars.GetAt(nMaxVarNameFoundIndex));
		pUtil->ErrorMessage( csTemp,2); 
		delete pUtil;
		return FALSE;
	}
	return TRUE;
}




void CUtilities::EncryptFile(CString csSrcFile, CString csOutputFile)
{
CString csKeyWord,
		csDeCryptedFile;

auto_ptr<CBlowFish> m_apBlowFish;

BOOL bHex;
int iMode;
int iPadding,
	iLength;
IMethod* poMethod;

	BlowFishParams(csKeyWord,bHex,iMode,iPadding);
	if(NULL == m_apBlowFish.get())
		//Create First Time
		m_apBlowFish = auto_ptr<CBlowFish>(new CBlowFish());
	char acKey[56];
	iLength = csKeyWord.GetLength();
	strncpy(acKey, LPCTSTR(csKeyWord), 56);
	m_apBlowFish->Initialize(acKey, 56, SBlock(0UL,0UL), iMode, iPadding);
	poMethod = m_apBlowFish.get(); 

	poMethod->EncryptFile(LPCTSTR(csSrcFile), LPCTSTR(csOutputFile));
	delete poMethod;

	if (csDeCryptedFile.IsEmpty())
	{
	
		return ;
	}

}




void CUtilities::BlowFishParams(CString& roStrKeyData, BOOL& rbHex, int& riMode, int& riPadding)
{

	roStrKeyData="secret";
	riMode = IMethod::ECB;
//	riMode = IMethod::CBC;
//	riMode = IMethod::CFB;
	riPadding = IMethod::ZEROES;
//	riPadding = IMethod::BLANKS;
//	riPadding = IMethod::PKCS7;

}



BOOL CUtilities::IsConfigFileValid(CString csFileName)
{
 CFileFind ff;

	return ff.FindFile(csFileName);

}


BOOL CUtilities::IsXMLFile_FormatOK(CString csFileName)
{


CXMLFile *pXML;

   pXML	= new CXMLFile();

   if(!pXML->LoadFile(csFileName))
   {
	   ErrorMessage(pXML->GetLastError());
	   delete pXML;
       return FALSE;

   }
   delete pXML;
   return TRUE;

}


BOOL CUtilities::IsValidTemplateLocation()
{
BOOL blnValidNode;

CString csConfigFile,
		csTemplatesLocation,
		csZebraFileExtension;

CXMLFile *pXML;


   pXML	= new CXMLFile();

   pXML->LoadFile("c:\\JoTS\\Config\\JoTSConfig.xml"); 
   blnValidNode=pXML->GetSingleNodeValue(ZEBRATEMPLATES,csTemplatesLocation); 

   delete pXML;

   if (!blnValidNode)
   {
		ErrorMessage("Invalid Printer Template Node In Configuration File");
		return FALSE;
   }
   blnValidNode =IsFileValid(csTemplatesLocation+"*.*");

   if (!blnValidNode)
   {
		ErrorMessage("Template Directory Not Found");
		return FALSE;
   }
	
   return  TRUE;


}

BOOL CUtilities::IsValidJobsLocation()
{
BOOL blnValidNode;

CString csConfigFile,
		csTemplatesLocation,
		csZebraFileExtension;

CXMLFile *pXML;


   pXML	= new CXMLFile();

   csConfigFile=DEFAULTCONFIGLOCATION;
   pXML->LoadFile(DEFAULTCONFIGFILE); 
   blnValidNode=pXML->GetSingleNodeValue(DEFAULTCONFIGLOCATION,csTemplatesLocation); 

   delete pXML;

   if (!blnValidNode)
   {
		ErrorMessage("Invalid Jobs Directory Node In Configuration File");
		return FALSE;
   }
   blnValidNode =IsFileValid(csTemplatesLocation+"*.*");

   if (!blnValidNode)
   {
		ErrorMessage("Jobs Directory Not Found");
		return FALSE;
   }
	
   return  TRUE;


}
	
BOOL CUtilities::IsLogDataFileName()
{
BOOL blnValidNode;

CString csConfigFile,
		csTemplatesLocation,
		csZebraFileExtension;

CXMLFile *pXML;


   pXML	= new CXMLFile();

   csConfigFile=DEFAULTCONFIGLOCATION;
   pXML->LoadFile(DEFAULTCONFIGFILE); 
   blnValidNode=pXML->GetSingleNodeValue(LOGDATAPARAMS,m_csLogDataFileName); 

   delete pXML;

   if (!blnValidNode)
   {

		return FALSE;
   }
   return TRUE;	

}

void CUtilities::LogData (CString csLogData)
{

	CString
		csDate,
		csTime,
		csRecord;

	CStdioFile fOutputFile;

	CTime 
		ctFileTime,
		ctNow;

	struct tm* 
		LocalTime;

	char tmpbuf[20];


	int
		nYear;


	ctNow = CTime::GetCurrentTime();

	LocalTime = ctNow.GetLocalTm ( NULL );

	/* Use strftime to get the year with century. */

	strftime( tmpbuf, 20, "%Y", LocalTime );
	nYear = atoi ( tmpbuf );

	csDate.Format ( "%02d/%02d/%04d", LocalTime->tm_mon+1,
									  LocalTime->tm_mday,
									  nYear );

	csTime.Format ( "%02d:%02d:%02d", LocalTime->tm_hour,
									  LocalTime->tm_min,
									  LocalTime->tm_sec );
		
	csRecord = csLogData + "," +  csDate + "," + csTime + "\n";

	if ( !fOutputFile.Open( m_csLogDataFileName, 
			CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite ) )
	{

		return;
	}

	fOutputFile.SeekToEnd();
	fOutputFile.WriteString ( csRecord );


	fOutputFile.Close ();


}

BOOL CUtilities::ScanForBarcode_Vars(CString csTemplate, CStringArray *csaBCVars)
{
int	nLeftOffset=0,
	nRightOffset=0,
	nCount=0,
	nMaxOffset=0,
	nCount2=0;

CString csBuffer;
BOOL blnBarCodeFormatsExist=FALSE;
	
	nLeftOffset=csTemplate.Find("^B");

	if((nLeftOffset==NOTFOUND))	// No text variables
	{
		return FALSE;
	}
	nMaxOffset=csTemplate.GetLength(); 

	for(nCount=nLeftOffset;nCount<nMaxOffset	;nCount++)
	{
		csBuffer=csTemplate.Mid(nCount,2);
		if (csBuffer=="^A")
		{
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=-1)
			{
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForVars(csBuffer, csaBCVars);
				return TRUE;
			}

		}
		else if (csBuffer.Mid(0,1)=="[")
		{
			nLeftOffset=csTemplate.Find("[");
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=0)
			{
				csBuffer=csTemplate.Mid(nLeftOffset+1,nRightOffset-(nLeftOffset+1));
				csaBCVars->Add(csBuffer);
				
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForVars(csBuffer,csaBCVars);
				break;
			}

		}

	}
	return TRUE;

}

void CUtilities::ScanForVars(CString csTemplate, CStringArray *csaBCVars)
{

int	nLeftOffset=0,
	nRightOffset=0,
	nCount=0,
	nMaxOffset=0,
	nCount2=0;

CString csBuffer;
	
	nLeftOffset=csTemplate.Find("^B");

	if((nLeftOffset==NOTFOUND))	// No text variables
	{
		return;
	}
	nMaxOffset=csTemplate.GetLength(); 

	for(nCount=nLeftOffset;nCount<nMaxOffset	;nCount++)
	{
		csBuffer=csTemplate.Mid(nCount,2);
		if (csBuffer=="^A")
		{
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=-1)
			{
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForVars(csBuffer, csaBCVars);
				return ;
			}

		}
		else if (csBuffer.Mid(0,1)=="[")
		{
			nLeftOffset=csTemplate.Find("[");
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=0)
			{
				csBuffer=csTemplate.Mid(nLeftOffset+1,nRightOffset-(nLeftOffset+1));
				csaBCVars->Add(csBuffer);
				
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForVars(csBuffer,csaBCVars);
				break;
			}

		}

	}


}


BOOL CUtilities::ScanForHR_Vars(CString csTemplate, CStringArray *csaBCVars)
{
int	nLeftOffset=0,
	nRightOffset=0,
	nCount=0,
	nMaxOffset=0,
	nCount2=0;

CString csBuffer;
BOOL blnBarCodeFormatsExist=FALSE;
	
	nLeftOffset=csTemplate.Find("^A");

	if((nLeftOffset==NOTFOUND))	// No text variables
	{
		return FALSE;
	}
	nMaxOffset=csTemplate.GetLength(); 

	for(nCount=nLeftOffset;nCount<nMaxOffset	;nCount++)
	{
		csBuffer=csTemplate.Mid(nCount,2);
		if (csBuffer=="^B")
		{
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=-1)
			{
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForHR_Vars(csBuffer, csaBCVars);
				return TRUE;
			}

		}
		else if (csBuffer.Mid(0,1)=="[")
		{
			nLeftOffset=csTemplate.Find("[");
			nRightOffset=csTemplate.Find("]");
			if (nRightOffset!=0)
			{
				csBuffer=csTemplate.Mid(nLeftOffset+1,nRightOffset-(nLeftOffset+1));
				csaBCVars->Add(csBuffer);
				
				csBuffer=csTemplate.Mid(nRightOffset+1);
				ScanForHR_Vars(csBuffer,csaBCVars);
				break;
			}

		}

	}
	return TRUE;

}

int CUtilities::GetHRVars(int nTemplateID, JobInfo *pJobInfo, HR_Vars *HRVars)
{


int nVars=0;

	
	while(!pJobInfo->Templates[nTemplateID].HRVars[nVars].Name.IsEmpty())
	{
		HRVars[nVars].Name = pJobInfo->Templates[nTemplateID].HRVars[nVars].Name;
		HRVars[nVars].Prefix  = pJobInfo->Templates[nTemplateID].HRVars[nVars].Prefix;
		HRVars[nVars].Suffix  = pJobInfo->Templates[nTemplateID].HRVars[nVars].Suffix ;
		HRVars[nVars].Data  = pJobInfo->Templates[nTemplateID].HRVars[nVars].Data ;

		pJobInfo->Templates[nTemplateID].HRVars[nVars].Name="";
		pJobInfo->Templates[nTemplateID].HRVars[nVars].Prefix ="";
		pJobInfo->Templates[nTemplateID].HRVars[nVars].Suffix ="";
		pJobInfo->Templates[nTemplateID].HRVars[nVars].Data ="";


		nVars++;
	}
	return nVars-1;
	
}



//void CUtilities::ScanForHRVars(CString csTemplate, CStringArray *csaBCVars)
//{
//
//int	nLeftOffset=0,
//	nRightOffset=0,
//	nCount=0,
//	nMaxOffset=0,
//	nCount2=0;
//
//CString csBuffer;
//	
//	nLeftOffset=csTemplate.Find("^B");
//
//	if((nLeftOffset==NOTFOUND))	// No text variables
//	{
//		return;
//	}
//	nMaxOffset=csTemplate.GetLength(); 
//
//	for(nCount=nLeftOffset;nCount<nMaxOffset	;nCount++)
//	{
//		csBuffer=csTemplate.Mid(nCount,2);
//		if (csBuffer=="^A")
//		{
//			nRightOffset=csTemplate.Find("]");
//			if (nRightOffset!=-1)
//			{
//				csBuffer=csTemplate.Mid(nRightOffset+1);
//				ScanForHRVars(csBuffer, csaBCVars);
//				return ;
//			}
//
//		}
//		else if (csBuffer.Mid(0,1)=="[")
//		{
//			nLeftOffset=csTemplate.Find("[");
//			nRightOffset=csTemplate.Find("]");
//			if (nRightOffset!=0)
//			{
//				csBuffer=csTemplate.Mid(nLeftOffset+1,nRightOffset-(nLeftOffset+1));
//				csaBCVars->Add(csBuffer);
//				
//				csBuffer=csTemplate.Mid(nRightOffset+1);
//				ScanForHRVars(csBuffer,csaBCVars);
//				break;
//			}
//
//		}
//
//	}
//
//
//}







// Declare and initialize static member vars that get set only once and never change
__int64 CPerfTimer::m_Freq = 0; 
__int64 CPerfTimer::m_Adjust = 0; 


BOOL CPerfTimer::IsSupported()
{ // Returns FALSE if performance counter not supported.
  // Call after constructing at least one CPerfTimer
  return (m_Freq > 1);
}

const double CPerfTimer::Resolution()   
{ // Returns timer resolution in seconds
  return 1.0/(double)m_Freq; 
}

const double CPerfTimer::Resolutionms() 
{ // Returns timer resolution in milliseconds
  return 1000.0/(double)m_Freq; 
}

const double CPerfTimer::Resolutionus() 
{ // Returns timer resolution in microseconds
  return 1000000.0/(double)m_Freq; 
}




