// JobWizard.cpp : implementation file
//

#include "stdafx.h"
#include "JoTS.h"
#include "JobWizard.h"
#include "Utilities.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJobWizard

CJobWizard::CJobWizard()
{
}

CJobWizard::~CJobWizard()
{
}




void CJobWizard::CreateNewJob()
{

	// TODO: Add your command handler code here
	CPropertyEx  dlg("Job Wizard");
	// init variables

	dlg.Init(); 
	CAddJobStep1 page1;
	CAddJobStep2 page2;
	CDefineNumOfIndexesPge page2a;
	CAddJobStep3 page3;
	CAddJobStep4 page4;
	CAddJobStep5 page5;
	CAddJobStep6 page6;
	CAddJobStep7 page7;
	CFinishPage  page8;



	dlg.AddPage(&page1);
	dlg.AddPage(&page2);
	dlg.AddPage(&page4);
	dlg.AddPage(&page5);
	dlg.AddPage(&page2a);
	dlg.AddPage(&page3);
	dlg.AddPage(&page6);
	dlg.AddPage(&page7);
	dlg.AddPage(&page8);

	dlg.SetWizardMode();

	



	if(ID_WIZFINISH == dlg.DoModal())
	{
		 
		BuildPage2DataStruct(&page2);
		BuildPage2aDataStruct(&page2a);
		BuildDataSeries(&dlg);
		BuildLabelSeries(&dlg);
		BuildJobTemplates(&dlg);
		
		if (!m_udfJobInfo.Name.IsEmpty()) 
		{
			CXMLFile m_oXML;
			m_oXML.CreateNewFile(&m_udfJobInfo);
			SetJobName(m_udfJobInfo.Name); 
		}
		else
		{
			SetJobName(dlg.GetJobName());  
		}

	}
	else
	{
		CUtilities *pUtil = new CUtilities();
		pUtil->ErrorMessage("No Job Created");
		delete pUtil;

	}
	
;



}

/////////////////////////////////////////////////////////////////////////////
// CJobWizard message handlers


void CJobWizard::BuildPage2DataStruct(CAddJobStep2 *pDlg)
{


		m_udfJobInfo.Name					= pDlg->m_csJobName;
		m_udfJobInfo.Customer				= pDlg->m_csCustomer;
		m_udfJobInfo.ProductDescription		= pDlg->m_csProductDescription; 
		m_udfJobInfo.Reprints				= pDlg->m_csNoOfReprints;
		m_udfJobInfo.Rescans 				= pDlg->m_csNoOfRescans;
		m_udfJobInfo.NoOfLabels				= pDlg->m_csNoOfLabels;
		if (pDlg->m_blnLogData)
		{
			m_udfJobInfo.LogData = TRUE;
		}
		else
		{

			m_udfJobInfo.LogData = FALSE;
		}
		

}


void CJobWizard::BuildPage2aDataStruct(CDefineNumOfIndexesPge *pDlg)
{

	m_udfJobInfo.ExternalDataSource = pDlg->m_blnExternalDataSource;

	if (pDlg->m_nSerializedData==0)
		m_udfJobInfo.SerializedData = TRUE ;
	else
		m_udfJobInfo.SerializedData = FALSE ;


	m_udfJobInfo.NoOfDataSeries = atoi(pDlg->m_csNumberOfIndexes); 

}

void CJobWizard::BuildDataSeries(CPropertyEx  *dlg)
{
int nCount=0;

	for(nCount=0;nCount<MAXDATASERIES;nCount++)
	{
		if(dlg->SerialData[nCount].Name.IsEmpty()) break;
		m_udfJobInfo.SerialData[nCount].Name = dlg->SerialData[nCount].Name;
		m_udfJobInfo.SerialData[nCount].BaseNumberSchema = dlg->SerialData[nCount].BaseNumberSchema;
		m_udfJobInfo.SerialData[nCount].StartingSequencNumber = dlg->SerialData[nCount].StartingSequencNumber;
		m_udfJobInfo.SerialData[nCount].MaxSequenceNumber = dlg->SerialData[nCount].MaxSequenceNumber;
		m_udfJobInfo.SerialData[nCount].RollOverValue = dlg->SerialData[nCount].RollOverValue; 
		m_udfJobInfo.SerialData[nCount].FieldWidth = dlg->SerialData[nCount].FieldWidth;
		m_udfJobInfo.SerialData[nCount].CheckDigit = dlg->SerialData[nCount].CheckDigit; 
		m_udfJobInfo.SerialData[nCount].StepSize  = dlg->SerialData[nCount].StepSize ;
		m_udfJobInfo.SerialData[nCount].Static  = dlg->SerialData[nCount].Static; 

	
	}
}

void CJobWizard::BuildLabelSeries(CPropertyEx *dlg)
{
int nCount=0;

	for(nCount=0;nCount<dlg->m_nNumberOfLabels;nCount++)
	{
//		if(dlg->SerialData[nCount].Name.IsEmpty()) break;
		m_udfJobInfo.LabelInfo[nCount].PrintOrder.Format("%d",nCount+1);      //dlg->LabelData[nCount].PrintOrder;
		m_udfJobInfo.LabelInfo[nCount].TemplateName  = dlg->LabelData[nCount].TemplateName;
		m_udfJobInfo.LabelInfo[nCount].ScanLabel  = dlg->LabelData[nCount].ScanLabel;
		m_udfJobInfo.LabelInfo[nCount].VerifyLabel   = dlg->LabelData[nCount].VerifyLabel;
		m_udfJobInfo.LabelInfo[nCount].RotationAngle   = dlg->LabelData[nCount].RotationAngle;

	}



}


void CJobWizard::BuildJobTemplates(CPropertyEx *dlg)
{
int nCount=0,
	nBCVarCounter,
	nHRVarCounter;

	while(!dlg->Templates[nCount].Name.IsEmpty())
	{
		m_udfJobInfo.Templates[nCount].Name =  dlg->Templates[nCount].Name;
		nBCVarCounter=0;

		while(!dlg->Templates[nCount].BCVars[nBCVarCounter].Name.IsEmpty())
		{
			m_udfJobInfo.Templates[nCount].BCVars[nBCVarCounter].Name=dlg->Templates[nCount].BCVars[nBCVarCounter].Name;
			m_udfJobInfo.Templates[nCount].BCVars[nBCVarCounter].Prefix =dlg->Templates[nCount].BCVars[nBCVarCounter].Prefix ;
			m_udfJobInfo.Templates[nCount].BCVars[nBCVarCounter].Suffix  =dlg->Templates[nCount].BCVars[nBCVarCounter].Suffix  ;
			m_udfJobInfo.Templates[nCount].BCVars[nBCVarCounter].Data   =dlg->Templates[nCount].BCVars[nBCVarCounter].Data  ;
			nBCVarCounter++;
		}

		nHRVarCounter=0;

		while(!dlg->Templates[nCount].HRVars[nHRVarCounter].Name.IsEmpty())
		{
			m_udfJobInfo.Templates[nCount].HRVars[nHRVarCounter].Name=dlg->Templates[nCount].HRVars[nHRVarCounter].Name;
			m_udfJobInfo.Templates[nCount].HRVars[nHRVarCounter].Prefix =dlg->Templates[nCount].HRVars[nHRVarCounter].Prefix ;
			m_udfJobInfo.Templates[nCount].HRVars[nHRVarCounter].Suffix  =dlg->Templates[nCount].HRVars[nHRVarCounter].Suffix  ;
			m_udfJobInfo.Templates[nCount].HRVars[nHRVarCounter].Data   =dlg->Templates[nCount].HRVars[nHRVarCounter].Data  ;
			nHRVarCounter++;
		}


		nCount++;
	}


}

CString	CJobWizard::GetJobName()
{
	 return m_csJobName ;
}
void CJobWizard::SetJobName(CString csJobName)
{
	m_csJobName=csJobName;
}
